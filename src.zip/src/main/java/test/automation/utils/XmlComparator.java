package test.automation.utils;

import java.io.File;
import java.io.IOException;
import java.util.Iterator;

import org.apache.commons.io.FileUtils;
import org.xmlunit.builder.DiffBuilder;
import org.xmlunit.diff.Difference;


public class XmlComparator {
	
	
	public static int compareXmlFile(String GoldCopy,String TestCopy) throws IOException {
		
		String strGoldVersion= FileUtils.readFileToString(new File(GoldCopy));
		String strTestVersion= FileUtils.readFileToString(new File(TestCopy));
		
		org.xmlunit.diff.Diff myDiff = DiffBuilder
		    		.compare(strGoldVersion)
		    		.withTest(strTestVersion)
		    		.withNodeFilter(node -> !node.getNodeName().equals("lastmod"))
		    		.build();
		    
		    Iterator<Difference> iter = myDiff.getDifferences().iterator();
		    int size = 0;
		    while (iter.hasNext()) {
		        System.out.println(iter.next().toString());
		        size++;
		    }
		
		    return size;
	}
}