package test.automation.utils;

import java.util.Base64;

import org.testng.annotations.Test;

public class Base64EncodeDecode {

	//@Test
	public static String PasswordEncoder(String password2Encode) {
		Base64.Encoder encoder = Base64.getEncoder();
		byte byteArr[] = { 1, 2 };
		byte byteArr2[] = encoder.encode(byteArr);
		//System.out.println("Encoded byte array: " + byteArr2);
		byte byteArr3[] = new byte[5];
		int x = encoder.encode(byteArr, byteArr3);
		String str = encoder.encodeToString(password2Encode.getBytes());
		return str;
	}
	
	//@Test
	public static String PasswordDecoder(String password2Decode) {
		Base64.Decoder decoder = Base64.getDecoder();
		String dStr = new String(decoder.decode(password2Decode));
		System.out.println("Decoded string: " + dStr);
		return dStr;
	}
	
	
	/*
	 * public static void main(String args[]) { String Epass =
	 * PasswordEncoder("Climate@321"); System.out.println("Encoded String: "+Epass);
	 * String Epass2 = "SmFjaw=="; PasswordDecoder(Epass); }
	 */
	 
	
}
