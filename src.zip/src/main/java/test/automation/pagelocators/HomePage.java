package test.automation.pagelocators;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class HomePage extends LoginPage{
	
	public HomePage(WebDriver driver) {
		super(driver);
		
	}
	public WebDriver driver;

	/*
	 * public HomePage(WebDriver driver) { this.driver = driver;
	 * PageFactory.initElements(driver, this); }
	 */
	
	@FindBy(xpath="//input[@id='i0116']")
	public WebElement userEmail;
	@FindBy(xpath="//input[@type='submit']")
	public WebElement emailNext;
	@FindBy(xpath="//input[@id='i0118']")
	public WebElement userPassword;
	@FindBy(xpath="//input[@id='idSIButton9']")
	public WebElement userSignIn;
	
	
	public WebElement UserEmail() {
		return userEmail;
	}
	public WebElement EmailNext() {
		return emailNext;
	}
	public WebElement UserPassword() {
		return userPassword;
	}
	public WebElement UserSignIn() {
		return userSignIn;
	}
}
