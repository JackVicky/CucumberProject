package test.automation.pagelocators;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;

public class SearchResultPageConstants {
	
	public WebDriver driver;

	public SearchResultPageConstants(WebDriver driver) {
		this.driver = driver;
		PageFactory.initElements(driver, this);
	}
	
	/************************** All Result & common *****************************/
	@FindBy(how = How.XPATH, using = "//div[contains(@class,'dropdown-single-value__placeholder')]")
	public static WebElement business_unit;

	@FindBy(how = How.XPATH, using = "(//div[@class='dropdown-single-value__control css-q7irpc-control'])[1]")
	public static WebElement business_unit_filter_with_values;
	
	@FindBy(how = How.XPATH, using = "//div[contains(@class,'dropdown-single-value__menu-list')]//child::div[contains(@id,'react-select-2-option')]")
	public static WebElement business_unit_dd_values;

	@FindBy(how = How.XPATH, using = "//div[contains(@class,'dropdown-single-value__menu-list')]//child::div[contains(@class,'is-selected')]")
	public static WebElement business_unit_selected_value;

	@FindBy(how = How.XPATH, using = "//h1[@class='page-heading']")
	public static WebElement Search_page_title;

	@FindBy(how = How.XPATH, using = "//h2[contains(@class,'zero')]")
	public static WebElement Zero_result_title;

	@FindBy(how = How.XPATH, using = "//h2[contains(@class,'zero')]//following::p")
	public static WebElement Zero_result_tips;

	@FindBy(how = How.XPATH, using = "((//h2[contains(@class,'zero')]//following::p)//following-sibling::ul)//child::li[1]")
	public static WebElement Zero_result_description1;

	@FindBy(how = How.XPATH, using = "((//h2[contains(@class,'zero')]//following::p)//following-sibling::ul)//child::li[2]")
	public static WebElement Zero_result_description2;

	@FindBy(how = How.XPATH, using = "((//h2[contains(@class,'zero')]//following::p)//following-sibling::ul)//child::li[3]")
	public static WebElement Zero_result_description3;

	@FindBy(how = How.XPATH, using = "//ul[@class='pagination']")
	public static WebElement pagination;

	@FindBy(how = How.XPATH, using = "//ul[@class='pagination']//child::li[]")
	public static WebElement pagination_option;

	@FindBy(how = How.XPATH, using = "//div[@class='search-filters-group-container container-fluid']")
	public static WebElement filter_section;

	@FindBy(how = How.XPATH, using = "//div[contains(@class,'container-fluid filterable-list__body')]")
	public static WebElement Result_section;

	@FindBy(how = How.XPATH, using = "//div[@class='filterable-list__tab filterable-list__tab--active']//following-sibling::span[@class='filterable-list__tab-label']")
	public static WebElement active_filter_tab;

	@FindBy(how = How.XPATH, using = "//img[@alt='search-icon']//following-sibling::span[@class='filterable-list__tab-label']")
	public static WebElement All_result;

	@FindBy(how = How.XPATH, using = "//div[@class='list-total-count']")
	public static WebElement did_you_mean;

	@FindBy(how = How.XPATH, using = "//div[@class='list-total-count']//a")
	public static WebElement suggested_value;

	@FindBy(how = How.XPATH, using = "//span[@class='icon icon-cancel']")////div[contains(@class,'clear-filters-button')]//span
	public static WebElement clear_filter;
	
	@FindBy(how = How.XPATH, using = "//div[@class='search-filters-group-container container-fluid']/div[2]/div/span")////div[contains(@class,'clear-filters-button')]//span
	public static WebElement clear_filter_new;
	
	@FindBy(how = How.XPATH, using = "(//span[contains(@class,'icon icon-external-link')])[1]")//(//span[contains(@class,'icon icon-external-link')])[1]
	public static WebElement product_tile_extn_link;
	
	@FindBy(how = How.XPATH, using = "(//div[contains(@class,'tile__text-title')])[1]")
	public static WebElement product_tile_txt;
	
	@FindBy(how = How.XPATH, using = "//div[text()='088L9280']")
	public static WebElement product_088L9280;
	
	@FindBy(how = How.XPATH, using = "((//div[@class='container-fluid filterable-list__body']/ul/li/div)[1]/a/div)[1]")
	public static WebElement product_FirstProduct;
	
	@FindBy(how = How.XPATH, using = "(//div[contains(@class,'tile__image bordered')])[1]")
	public static WebElement product_tile_img;
	
	@FindBy(how = How.XPATH, using = "(//div[contains(@class,'tile__text-details_item')])[1]")
	public static WebElement product_tile_segment;
	
	@FindBy(how = How.XPATH, using = "(//div[contains(@class,'tile__text-description')])[1]//span")
	public static WebElement product_tile_desc;
	
	@FindBy(how = How.XPATH, using = "//div[@class='tile__text-details']/div[@class='tile__text-details_item']") //(//div[@class='tile__text'])[1]//descendant::div[contains(@class,'tile__text-details_item')]
	public static WebElement product_segment_tags;
	
	@FindBy(how = How.XPATH, using = "(//div[@class='tile__text'])[1]//p[contains(@class,'paragraph-link')]//a")
	public static WebElement product_tile_tags;
	
	@FindBy(how = How.XPATH, using = "(//div[contains(@class,'attributes')])[1]//child::table//child::td[contains(@class,'key')]")
	public static WebElement product_tile_attribute_key;
	
	@FindBy(how = How.XPATH, using = "(//div[contains(@class,'attributes')])[1]//child::table//child::td[contains(@class,'cell')][2]")
	public static WebElement product_tile_attribute_value;
	
	@FindBy(how = How.XPATH, using = "(//a[contains(@class,'show-more')])[1]")
	public static WebElement product_atrribute_show_more;
	
	
	
	@FindBy(how = How.XPATH, using = "//div[contains(@class,'dropdown-multi-values__indicators')]")
	public static WebElement Multi_select_arrowIcon;
		@FindBy(how = How.XPATH, using = "//div[@class='tabs-slider__arrow tabs-slider__arrow--next']")
	public static WebElement Rightslide_icon;
		@FindBy(how = How.XPATH, using = "//div[@class='tabs-slider__arrow tabs-slider__arrow--previous']")
	public static WebElement Leftslide_icon;
	/*************************** Products************************/

	@FindBy(how = How.XPATH, using = "//img[@alt='products-icon']//following-sibling::span[@class='filterable-list__tab-label']")
	public static WebElement products_tab;



	/***************************document******************************/

	@FindBy(how = How.XPATH, using = "//img[@alt='documents-icon']//following-sibling::span[@class='filterable-list__tab-label']")
	public static WebElement document_tab;

	@FindBy(how = How.XPATH, using = "(//div[contains(text(),'Document types')])[1]")//((//div[contains(@class,'dropdown-multi-values__value-container')])[1])//div
	public static WebElement document_type_dd;

	@FindBy(how = How.XPATH, using = "//div[contains(@class,'dropdown-multi-values__value-container')]//following::span[contains(@class,'multiselect-option-checkbox')]//following::label")
	public static WebElement document_type_chkbx;
	
	@FindBy(how = How.XPATH, using = "(//div[contains(@class,'search-dropdown')]//descendant::div[contains(@class,'dropdown-single-value__placeholder')])[2]")
	public static WebElement document_product_series_dd;

	@FindBy(how = How.XPATH, using = "//div[contains(@class,'dropdown-single-value__menu-list')]//descendant::div[contains(@class,'dropdown-single-value__option dropdown')]")
	public static WebElement document_product_series_list;

	@FindBy(how = How.XPATH, using = "(//div[contains(@class,'search-dropdown')]//descendant::div[contains(@class,'dropdown-single-value__placeholder')])[2]")
	public static WebElement document_level1_dd;
	
	@FindBy(how = How.XPATH, using = "//div[contains(@class,'search-dropdown')]//descendant::div[contains(@class,'dropdown-single-value__placeholder')][contains(text(),'Level  2')]")
	public static WebElement document_level2_dd;
	
	@FindBy(how = How.XPATH, using = "//div[contains(@class,'search-dropdown')]//descendant::div[contains(@class,'dropdown-single-value__placeholder')][contains(text(),'Level  3')]")
	public static WebElement document_level3_dd;
	
	@FindBy(how = How.XPATH, using = "//div[contains(@class,'dropdown-single-value__menu-list')]//descendant::div[contains(@class,'dropdown-single-value__option css')]")
	public static WebElement document_level1_list;

	@FindBy(how = How.XPATH, using = "(//div[contains(@class,'dropdown-single-value__control css')]//following::div[contains(@class,'dropdown-single-value__placeholder')])[2]")
	public static WebElement document_product_grp_dd;

	@FindBy(how = How.XPATH, using = "//div[contains(@class,'dropdown-single-value__menu css')]//descendant::div[contains(@class,'dropdown-single-value__option')]")
	public static WebElement document_product_grp_lst;

	@FindBy(how = How.XPATH, using = "(//div[contains(@class,'search-dropdown')]//descendant::div[contains(@class,'dropdown-single-value__placeholder')])[2]//following::div[contains(@class,'select-size')]")
	public static WebElement document_product_fmly_dd;

	@FindBy(how = How.XPATH, using = "//div[contains(@class,'dropdown-single-value__menu-list css')]//child::div")
	public static WebElement document_product_fmly_lst;

	@FindBy(how = How.XPATH, using = "(//div[contains(@class,'dropdown-single-value__control')]//descendant::div[contains(@class,'dropdown-single-value__placeholder')])[2]")
	public static WebElement document_product_type_dd;

	@FindBy(how = How.XPATH, using = "//div[contains(@class,'dropdown-single-value__menu-list css')]//child::div")
	public static WebElement document_product_type_lst;

	@FindBy(how = How.XPATH, using = "(//div[contains(@class,'dropdown-single-value__control css')]//following::div[contains(@class,'dropdown-single-value__placeholder')])")
	public static WebElement document_status_dd;

	@FindBy(how = How.XPATH, using = "//div[contains(@class,'dropdown-single-value__menu-list')]//following::div[contains(@class,'dropdown-single-value__option')]")
	public static WebElement document_status_lst;
	
	@FindBy(how = How.XPATH, using = "(//span[contains(text(),'All languages')])[1]")//(//span[@class='multiselect-dropdown-value'])[last()]
	public static WebElement document_language_filter;
	
	@FindBy(how = How.XPATH, using = "(//div[contains(@class,'dropdown-multi-values__placeholder')])[2]")
	public static WebElement document_language_container;
	
	@FindBy(how = How.XPATH, using = "//div[contains(@class,'option--is-selected')]")
	public static WebElement document_language_selectedvalue;
	
	@FindBy(how = How.XPATH, using = "//div[text()='All countries/regions']")
	public static WebElement document_Validfor_filter;
	
	@FindBy(how = How.XPATH, using = "(//div[contains(@class,'dropdown-single-value__indicators')]//span[@class='icon icon-chevron-down-small'])[2]")
	public static WebElement document_Validfor_filter1;
	
	@FindBy(how = How.XPATH, using = "(//span[@aria-live='polite']//following::div[contains(@class,'dropdown-single-value__value-container')]//child::div)[1]")
	public static WebElement document_Validfor_filter_container;
	
	@FindBy(how = How.XPATH, using = "(//div[text()='Authority'])[1]")
	public static WebElement document_Authority_filter;
	
	@FindBy(how = How.XPATH, using = "(//div[text()='BV'])[1]")
	public static WebElement document_Authority_filter_BV;
	
	
	@FindBy(how = How.XPATH, using = "//div[contains(@class,'dropdown-single-value__single')]")
	public static WebElement document_Archived_filter;
	
	@FindBy(how = How.XPATH, using = "(//span[contains(@class,'icon icon-chevron-down-small')])[2]")
	public static WebElement document_type_filter_arrowdown;
	
	@FindBy(how = How.XPATH, using = "(//span[contains(@class,'icon icon-chevron-down-small')])[2]")
	public static WebElement document_type_filter_arrowup;
	
	@FindBy(how = How.XPATH, using = "(//span[contains(@class,'icon icon-chevron-down-small')])[3]")
	public static WebElement language_type_filter_arrowup;
	
	@FindBy(how = How.XPATH, using = "(//span[contains(@class,'icon icon-chevron-down-small')])[3]")
	public static WebElement approval_type_filter_arrowup;
	
	@FindBy(how = How.XPATH, using = "(//div[@class='dropdown-single-value__indicators css-1wy0on6']/div/span)[1]")
	public static WebElement business_filter_arrowdown;
	
	@FindBy(how = How.XPATH, using = "(//div[contains(text(),'All countries/regions')])[1]")
	public static WebElement all_countries_regions;
	
	@FindBy(how = How.XPATH, using = "(//div[@class='dropdown-single-value__indicators css-1wy0on6']/div/span)[7]")
	public static WebElement hierarchy_filter_level1_arrowdown;
	
	@FindBy(how = How.XPATH, using = "(//div[@class='dropdown-single-value__indicators css-1wy0on6']/div/span)[9]")
	public static WebElement hierarchy_filter_level2_arrowdown;
	
	@FindBy(how = How.XPATH, using = "(//div[@class='dropdown-single-value__indicators css-1wy0on6']/div/span)[11]")
	public static WebElement hierarchy_filter_level3_arrowdown;
	
	
	/***************************downloads******************************/
	@FindBy(how = How.XPATH, using = "//img[@alt='downloads-icon']//following-sibling::span[@class='filterable-list__tab-label']")
	public static WebElement downloads_tab;

	@FindBy(how = How.XPATH, using = "//div[contains(@class,'dropdown-multi-values__value-container')]")
	public static WebElement downloads_type_dd;
	
	@FindBy(how = How.XPATH, using = "(//div[contains(@class,'dropdown-multi-values__value-container')])[2]")
	public static WebElement approval_type_dd;
	
	@FindBy(how = How.XPATH, using = "//img[@alt='downloads-icon']//following-sibling::span[@class='filterable-list__tab-label']")
	public static WebElement downloads_type_chkbx;

	@FindBy(how = How.XPATH, using = "(//div[@class='tile__text']//descendant::span[@class='icon icon-download'])[1]")
	public static WebElement downloads_title_Icon;
	
	@FindBy(how = How.XPATH, using = "(//div[@class='tile__text-title'])[1]")
	public static WebElement downloads_title;
	
	@FindBy(how = How.XPATH, using = "(//div[@class='tile__text-details_item'])[1]")
	public static WebElement downloads_Segment_type;
	
	@FindBy(how = How.XPATH, using = "(//div[@class='tile__text-description'])[1]")
	public static WebElement downloads_description;
	
	@FindBy(how = How.XPATH, using = "(//div[contains(@class,'dropdown-single-value__placeholder')])[2]")
	public static WebElement product_filter_lvl1;
	
	@FindBy(how = How.XPATH, using = "(//div[contains(@class,'dropdown-single-value__placeholder')])[2]")
	public static WebElement productline_filter_lvl1;
	
	@FindBy(how = How.XPATH, using = "(//div[contains(@class,'dropdown-single-value__placeholder')])[2]")
	public static WebElement product_filter_lvl2;
	
	@FindBy(how = How.XPATH, using = "(//ul[contains(@class,'tile-group  tile-group-wide  no-ktr search-results-list-items bordered-list-items ')]/li/div/a)/div[1]")
	public static WebElement software_result1;
	
	
	
	/********************************* Job filter*******************************************/
	@FindBy(how = How.XPATH, using = "//img[@alt='jobs-icon']//following-sibling::span[@class='filterable-list__tab-label']")
	public static WebElement jobs_tab;
	
	@FindBy(how = How.XPATH, using = "(//div[@class='tile__text']//descendant::span[@class='icon icon-external-link'])[1]")
	public static WebElement External_icon;
	
	@FindBy(how = How.XPATH, using = "(//div[@class='tile__text-title'])[1]")
	public static WebElement Job_title;
	
	@FindBy(how = How.XPATH, using = "(//div[@class='tile__text-details'])[1]")
	public static WebElement Job_Date_location;

	@FindBy(how = How.XPATH, using = "(//div[@class='tile__text'])[1]")
	public static WebElement Entire_tile;
	
	@FindBy(how = How.XPATH, using = "//div[text()='Job area']")
	public static WebElement Job_Area_filter;
	
	@FindBy(how = How.XPATH, using = "//div[contains(@class,'selected-value')]//child::div[contains(@class,'dropdown-single-value__single-value')]")
	public static WebElement Job_Area_filter_selected_value;
	

	@FindBy(how = How.XPATH, using = "(//div[contains(@class,'selected-value')]//child::div[contains(@class,'dropdown-single-value__single-value')])[2]")
	public static WebElement Job_Location_filter_selected_value;
	
	@FindBy(how = How.XPATH, using = "(//div[contains(text(),'Country')])[1]")
	public static WebElement Job_Country_filter1;
	
	@FindBy(how = How.XPATH, using = "(//span[@class='icon icon-chevron-down-small'])[1]")
	public static WebElement Job_Country_filter;
	
	@FindBy(how = How.XPATH, using = "(//div[contains(@class,'dropdown-single-value__placeholder')])[1]")
	public static WebElement Job_Country_filter_container;
	
	@FindBy(how = How.XPATH, using = "(//div[@class='select-size-detector'])[2]")
	public static WebElement Job_Location_filter;
	
	@FindBy(how = How.XPATH, using = "(//div[contains(@class,'dropdown-single-value__placeholder')])[2]")
	public static WebElement Job_Location_filter_container;
	
	@FindBy(how = How.XPATH, using = "(((//div[text()='Location'])[1])//ancestor::div[contains(@class,'is-disabled')])[1]")
	public static WebElement Job_Location_filter_disabled;
	
	@FindBy(how = How.XPATH, using = "//div[text()='Location']")
	public static WebElement Job_Location_filter_enabled;
	
	@FindBy(how = How.XPATH, using = "//div[text()='Position type']")
	public static WebElement Job_Position_type_filter;
	
	@FindBy(how = How.XPATH, using = "//div[text()='Experience level']")
	public static WebElement Job_Experience_level_filter;
	
	@FindBy(how = How.XPATH, using = "(//span[@class='icon icon-chevron-down-small'])[4]")
	public static WebElement Job_Experience_level_filter_arrow;
	
	/********************************* learning filter*******************************************/
	@FindBy(how = How.XPATH, using = "//img[@alt='learning-icon']//following-sibling::span[@class='filterable-list__tab-label']")
	public static WebElement learning_tab;

	@FindBy(how = How.XPATH, using = "(//div[@class='tile__text-title'])[1]")
	public static WebElement learning_title;
	
	@FindBy(how = How.XPATH, using = "(//div[@class='tile__text']//descendant::span[@class='icon icon-external-link'])[1]")
	public static WebElement Learning_External_icon;
	
	@FindBy(how = How.XPATH, using = "(//div[@class='tile__text-details_item'])[1]")
	public static WebElement learning_segment;
	
	@FindBy(how = How.XPATH, using = "(//div[@class='tile__text-description'])[1]")
	public static WebElement learning_description;
	
	@FindBy(how = How.XPATH, using = "(//div[@class='tile__text'])[1]")
	public static WebElement learning_Entire_tile;

	@FindBy(how = How.XPATH, using = "(((//div[text()='Course category'])[1])//ancestor::div[contains(@class,'is-disabled')])[1]")
	public static WebElement learning_course_category_filter_disabled; 
	
	@FindBy(how = How.XPATH, using = "(//div[text()='Course category'])[1]")
	public static WebElement learning_course_category_filter_enabled;
	//(//div[text()='Buildings - Commercial (Non-Residential)'])[1]
	@FindBy(how = How.XPATH, using = "((//div[contains(@class,'value-container')])[4]//child::div)[1]")
	public static WebElement learning_course_category_container_name;
	
	@FindBy(how = How.XPATH, using = "(//div[contains(@class,'dropdown-single-value__single-value css-1uccc91-singleValue')])[2]")
	public static WebElement learning_course_category_second;//div[contains(@class,'dropdown-single-value__placeholder')]
	
	@FindBy(how = How.XPATH, using = "//div[contains(@class,'dropdown-multi-values__placeholder')][text()='Languages']")
	public static WebElement learning_languages_filter;
	
	@FindBy(how = How.XPATH, using = "//div[contains(@class,'dropdown-multi-values__placeholder')][contains(text(),'All languages')]") 
	public static WebElement learning_languages_filter_new;
	
	@FindBy(how = How.XPATH, using = "//span[contains(@class,'multiselect-dropdown-value')][contains(text(),'All languages')]") 
	public static WebElement learning_languages_filter_new2;
	
	@FindBy(how = How.XPATH, using = "//span[@class='multiselect-dropdown-value']")
	public static WebElement learning_languages_container;
	
	
}
