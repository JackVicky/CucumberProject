package test.automation.pagelocators;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;


public class DocumentsPageconstants {
	
	public WebDriver driver;

	public DocumentsPageconstants(WebDriver driver) {
		this.driver = driver;
		PageFactory.initElements(driver, this);
	}
	
	@FindBy(how = How.XPATH, using = "(//div[@class='spot-content-container'])[3]//child::div[1]") 
	public static WebElement Manual_guides;
	
	@FindBy(how = How.XPATH, using = "//a[contains(@aria-label,'Manual')]") 
	public static WebElement Manual_guides_link;
	
	@FindBy(how = How.XPATH, using = "//h1[@class='page-heading']") 
	public static WebElement Page_heading;

	@FindBy(how = How.XPATH, using = "(//span[@class='breadcrumbs-list-item__text'])[1]") 
	public static WebElement breadcrumbs1;

	@FindBy(how = How.XPATH, using = "//div[@class='search-filters-group-container container-fluid']") 
	public static WebElement filter_section;

	@FindBy(how = How.XPATH, using = "//div[@class='clear-filters-button']//child::span")
	public static WebElement clear_filter;

	@FindBy(how = How.XPATH, using = "//span[@class='filterable-list__documents-count']") 
	public static WebElement numberofresult;

	@FindBy(how = How.XPATH, using = "//input[@placeholder='Search in results']") 
	public static WebElement Search_results;
	
	@FindBy(how = How.XPATH, using = "//span[@class='icon icon-cancel'][@aria-hidden='true']") 
	public static WebElement Search_close;
		
	@FindBy(how = How.XPATH, using = "//ul[contains(@class,'list-items')]") 
	public static WebElement List_of_result;
	
	@FindBy(how = How.XPATH, using = "//ul[@class='pagination']") 
	public static WebElement pagination;

	@FindBy(how = How.XPATH, using = "(//div[contains(@class,'dropdown')]//div[contains(@class,'placeholder')])[1]") 
	public static WebElement Business_filter;
	
	@FindBy(how = How.XPATH, using = "(//span[contains(@class,'multiselect-dropdown-value')][contains(text(),'Document types')])[last()]") 
	public static WebElement Document_type_filter;
	
	@FindBy(how = How.XPATH, using = "(//span[contains(@class,'multiselect-dropdown-value')][contains(text(),'All languages')])[last()]") 
	public static WebElement Language_filter;
	
	@FindBy(how = How.XPATH, using = "//div[contains(@class,'option--is-selected')]") 
	public static WebElement Language_selected_filter;
		
	@FindBy(how = How.XPATH, using = "(//div[contains(@class,'dropdown')]//div[contains(@class,'placeholder')])[2]") 
	public static WebElement countries_filter;
	
	@FindBy(how = How.XPATH, using = "(//input//preceding-sibling::div[contains(@class,'dropdown-single-value')])[2]") 
	public static WebElement Status_filter;
	
	@FindBy(how = How.XPATH, using = "//div[contains(@class,'option--is-selected')]") 
	public static WebElement Status_selected_filter;
	
	@FindBy(how = How.XPATH, using = "(//div[text()='Product group'])[1]") 
	public static WebElement product_group;
	
	@FindBy(how = How.XPATH, using = "(//div[text()='Product series'])[1]") 
	public static WebElement product_series;
	
	@FindBy(how = How.XPATH, using = "(//div[@class='search-filters-group-container container-fluid']//child::div[@class=''])[2]") 
	public static WebElement Second_row_filter_section;
	
	@FindBy(how = How.XPATH, using = "//span[@class='icon icon-download']") 
	public static WebElement Download_icon;
		
	@FindBy(how = How.XPATH, using = "(//ul[@class='pagination']//li//a)[3]") 
	public static WebElement Pagination_number;
	
	@FindBy(how = How.XPATH, using = "(//div[@style='display: none;']//preceding-sibling::div[@class='filters-group__heading'])[1]") 
	public static WebElement Download_filters_collapsed;

	@FindBy(how = How.XPATH, using = "(//div[@class='unselect-buttons-group']//descendant::span[@class='cta__content-text'])")
	public static WebElement Applied_filter;

	@FindBy(how = How.XPATH, using = "(//div[@class='unselect-buttons-group']//descendant::span[@class='icon icon-cancel'])")
	public static WebElement Applied_filter_close;


	@FindBy(how = How.XPATH, using = "//ul[@class='tile-group  tile-group-wide ']//child::li")
	public static WebElement Item_Tile;

	@FindBy(how = How.XPATH, using = "(//ul[@class='tile-group  tile-group-wide ']//descendant::div[@class='tile__text-title'])[1]")
	public static WebElement Tile_title;

	@FindBy(how = How.XPATH, using = "(//ul[@class='tile-group  tile-group-wide ']//descendant::a[contains(@class,'link clickable')])[1]")
	public static WebElement Tile_image;

	@FindBy(how = How.XPATH, using = "(//ul[@class='tile-group  tile-group-wide ']//descendant::div[contains(@class,'tile__text-description')])[1]")
	public static WebElement Tile_description;

	@FindBy(how = How.XPATH, using = "//span[@class='sort-icons']//following-sibling::span[@class='cta-content-text']") 
	public static WebElement sort_button;

	@FindBy(how = How.XPATH, using = "//span[@class='sort-icons']//following-sibling::span[@class='cta-content-text']//following::option[@value='default_sort']") 
	public static WebElement Default_sorting;
	@FindBy(how = How.XPATH, using = "//span[@class='sort-icons']//following-sibling::span[@class='cta-content-text']//following::option[@value='title_asc']") 
	public static WebElement sort_title_asc;

	@FindBy(how = How.XPATH, using = "//span[@class='sort-icons']//following-sibling::span[@class='cta-content-text']//following::option[@value='title_desc']") 
	public static WebElement sort_title_desc;

}
