package test.automation.pagelocators;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;

public class AboutDanfossPageConstants {

	public WebDriver driver;

	public AboutDanfossPageConstants(WebDriver driver) {
		this.driver = driver;
		PageFactory.initElements(driver, this);
	}

	@FindBy(how = How.XPATH, using = "(//li[contains(@aria-label,'Company - Click enter')]//span//span//span)[1]")
	public static WebElement Company;

	@FindBy(how = How.XPATH, using = "(//a[@href='/ru-ru/products/']/span)[1]") ////a[@href='/ru-ru/about-danfoss/company/']//span//span[text()='Компания']
	public static WebElement Russian_Company;

	@FindBy(how = How.XPATH, using = "//div[contains(@class,'desktopMenuMultipleLevelSidebar')]")
	public static WebElement Second_level_menu;

	@FindBy(how = How.XPATH, using = "//div[contains(@id,'third-level-menu')]")
	public static WebElement third_level_menu;

	@FindBy(how = How.XPATH, using = "(//span[contains(@class,'menuArrowSecondLevel')])[1]")
	public static WebElement Second_LevelMenu_arrow;

	@FindBy(how = How.XPATH, using = "//a[contains(@href,'/about-danfoss/company/')]//following-sibling::ul[contains(@class,'desktopMenuGroupList')]")
	public static WebElement Fourth_LevelMenu_Container;

	@FindBy(how = How.XPATH, using = "//a[contains(@href,'/about-danfoss/company/engineering-tomorrow')]//child::span[@class='item-caption']")
	public static WebElement Engineering_tomorrow;

	@FindBy(how = How.XPATH, using = "(//a[contains(@href,'/about-danfoss/company/foundations')]//child::span[@class='item-caption'])[1]")
	public static WebElement foundations;

	@FindBy(how = How.XPATH, using = "(//a[contains(@href,'/about-danfoss/company/sustainability')]//child::span[@class='item-caption'])[1]")
	public static WebElement sustainability;

	@FindBy(how = How.XPATH, using = "//a[contains(@href,'/about-danfoss/company/history')]//child::span[@class='item-caption']")
	public static WebElement history;

	@FindBy(how = How.XPATH, using = "(//a[contains(@href,'/about-danfoss/company/management')]//child::span[@class='item-caption'])[1]")
	public static WebElement management;

	@FindBy(how = How.XPATH, using = "(//a[contains(@href,'/about-danfoss/company/management')]//child::span[@class='item-caption'])[2]")
	public static WebElement Group_executive;

	@FindBy(how = How.XPATH, using = "(//a[contains(@href,'/about-danfoss/company/awards-and-recognitions')]//child::span[@class='item-caption'])[1]")
	public static WebElement awards_recognitions;

	@FindBy(how = How.XPATH, using = "//a[contains(@href,'/about-danfoss/company/application-development-centers')]//child::span[@class='item-caption']")
	public static WebElement application_development_centers;

	@FindBy(how = How.XPATH, using = "(//a[contains(@href,'/about-danfoss/company/financials')]//child::span[@class='item-caption'])[1]")
	public static WebElement financials;

	@FindBy(how = How.XPATH, using = "//span[contains(text(),'Financials')]")
	public static WebElement financials_new_prod;
	
	@FindBy(how = How.XPATH, using = "(//a[contains(@href,'/about-danfoss/company/procurement')]//child::span[@class='item-caption'])[1]")
	public static WebElement procurement;

	@FindBy(how = How.XPATH, using = "//a[contains(@href,'/about-danfoss/company')]//child::span[text()='Overview']")
	public static WebElement Company_overview;

	@FindBy(how = How.XPATH, using = "//button[contains(@class,'angleButton')]")
	public static WebElement Company_close;

	@FindBy(how = How.XPATH, using = "//span[contains(@class,'megaMenuItem')]//child::span[text()='Our businesses']")
	public static WebElement Our_businesses;

	@FindBy(how = How.XPATH, using = "(//a[contains(@href,'/about-danfoss/our-businesses/power-solutions')]//child::span[@class='item-caption'])[1]")
	public static WebElement Power_solutions;

	@FindBy(how = How.XPATH, using = "(//a[contains(@href,'/about-danfoss/our-businesses/heating')]//child::span[@class='item-caption'])[1]")
	public static WebElement heating;

	@FindBy(how = How.XPATH, using = "(//a[contains(@href,'/about-danfoss/our-businesses/silicon-power')]//child::span[@class='item-caption'])[1]")
	public static WebElement Silicon_Power;

	@FindBy(how = How.XPATH, using = "(//a[contains(@href,'/about-danfoss/our-businesses/cooling')]//child::span[@class='item-caption'])[1]")
	public static WebElement cooling;

	@FindBy(how = How.XPATH, using = "(//a[contains(@href,'/about-danfoss/our-businesses/drives')]//child::span[@class='item-caption'])[1]")
	public static WebElement drives;

	@FindBy(how = How.XPATH, using = "(//a[contains(@href,'/about-danfoss/our-businesses/fire-safety')]//child::span[@class='item-caption'])[1]")
	public static WebElement fire_safety;

	@FindBy(how = How.XPATH, using = "(//a[contains(@href,'/about-danfoss/our-businesses/industrial-automation')]//child::span[@class='item-caption'])[1]")
	public static WebElement industrial_automation;

	@FindBy(how = How.XPATH, using = "(//a[contains(@href,'/about-danfoss/our-businesses/emission-monitoring')]//child::span[@class='item-caption'])[1]")
	public static WebElement emission_monitoring;

	@FindBy(how = How.XPATH, using = "(//a[contains(@href,'editron')]//child::span[@class='item-caption'])[1]")
	public static WebElement editron;

	@FindBy(how = How.XPATH, using = "(//a[contains(@href,'high-pressure-pumps')]//child::span[@class='item-caption'])[1]")
	public static WebElement high_pressure_pumps;

	@FindBy(how = How.XPATH, using = "(//a[contains(@href,'product-store')]//child::span[@class='item-caption'])[1]")
	public static WebElement product_store;

	@FindBy(how = How.XPATH, using = "//a[contains(@href,'/en/about-danfoss/our-businesses/')]//child::span[text()='Our businesses']")
	public static WebElement Overview_our_businesses;

	// Russian

	public static WebElement Company() {
		return Company;
	};

	public static WebElement Russian_Company() {
		return Russian_Company;
	};

	public static WebElement Second_level_menu() {
		return Second_level_menu;
	};

	public static WebElement third_level_menu() {
		return third_level_menu;
	};

	public static WebElement Second_LevelMenu_arrow() {
		return Second_level_menu;
	};

	public static WebElement Fourth_LevelMenu_Container() {
		return Fourth_LevelMenu_Container;

	};

	public static WebElement Engineering_tomorrow() {
		return Engineering_tomorrow;
	};

	public static WebElement foundations() {
		return foundations;
	};

	public static WebElement sustainability() {
		return sustainability;
	};

	public static WebElement history() {
		return history;
	};

	public static WebElement management() {
		return history;
	};

	public static WebElement Group_executive() {
		return Group_executive;
	};

	public static WebElement awards_recognitions() {
		return awards_recognitions;
	};

	public static WebElement application_development_centers() {
		return application_development_centers;
	};

	public static WebElement financials() {
		return financials;
	};

	public static WebElement procurement() {
		return procurement;
	};

	public static WebElement Company_overview() {
		return Company_overview;
	};

	public static WebElement Company_close() {
		return Company_close;
	};

	public static WebElement Our_businesses() {
		return Our_businesses;
	};

	public static WebElement Power_solutions() {
		return Power_solutions;
	};

	public static WebElement heating() {
		return heating;
	};

	public static WebElement Silicon_Power() {
		return Silicon_Power;
	};

	public static WebElement cooling() {
		return cooling;
	};

	public static WebElement drives() {
		return drives;
	};

	public static WebElement fire_safety() {
		return fire_safety;
	};

	public static WebElement industrial_automation() {
		return industrial_automation;
	};

	public static WebElement emission_monitoring() {
		return emission_monitoring;
	};

	public static WebElement editron() {
		return editron;
	};

	public static WebElement high_pressure_pumps() {
		return high_pressure_pumps;
	};

	public static WebElement product_store() {
		return product_store;
	};

	public static WebElement Overview_our_businesses() {
		return Overview_our_businesses;
	};

}
