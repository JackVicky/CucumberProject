package test.automation.pagelocators;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;



public class HomePageconstants {

	public WebDriver driver;

	public HomePageconstants(WebDriver driver) {
		this.driver = driver;
		PageFactory.initElements(driver, this);
	}
	
	//**************************************************************WebElements*******************************************************************************

	@FindBy(how = How.XPATH, using = "//div[@class='header__primary-menu']")
	public static WebElement primary_header;
	@FindBy(how = How.XPATH, using = "//div[contains(@class,'desktopMenuContainer')]")
	public static WebElement menu_header;
	@FindBy(how = How.XPATH, using = "(//div[contains(@class,'coi-banner')]//following::button[contains(@onclick,'CookieInformation.submitAllCategories()')])[1]") // QA environment
	//@FindBy(how = How.XPATH, using ="(//div[@class='coi-banner__page']//descendant::button[contains(@onclick,'CookieInformation.submitAllCategories()')])[1]") // Staging
	
	public static WebElement acceptcookies;
	@FindBy(how = How.XPATH, using = "//img[@alt='Danfoss']")
	public static WebElement titleImage;
	@FindBy(how = How.XPATH, using = "//div[@class='header__logo__title']")
	public static WebElement Danfoss_logotitle;
	@FindBy(how = How.XPATH, using = "//div[@class='search-select__input']//child::input")
	public static WebElement Search_box;
	
	@FindBy(how = How.XPATH, using = "//div[contains(@class,'search-select__menu')]")
	public static WebElement Search_box_Autosuggest;
	
	
	@FindBy(how = How.XPATH, using = "//span[@id='header-icon-global']")
	public static WebElement Region_selection_button;
	@FindBy(how = How.XPATH, using = "//span[@class='icon-global__label']")
	public static WebElement Selected_region;
	
	@FindBy(how = How.XPATH, using = "//span[@class='icon icon-quick-link']")
	public static WebElement Quick_links_icon;
	@FindBy(how = How.XPATH, using = "//span[@class='icon-quick-link__label']")
	public static WebElement Quick_links_label;
	@FindBy(how = How.XPATH, using = "//div[contains(@class,'header__app-switcher__content')]")
	public static WebElement Quick_links_menus;
	
	@FindBy(how = How.XPATH, using = "//span[text()='Products']") //QA products have extra space at the end
	public static WebElement Products_menu;
	@FindBy(how = How.XPATH, using = "//span[text()='Products']//following-sibling::span")
	public static WebElement Products_menu_arrow;
	
	@FindBy(how = How.XPATH, using = "//span[text()='Markets we serve']")
	public static WebElement Market_we_serve;
	
	@FindBy(how = How.XPATH, using = "//span[text()='Markets we serve']//following-sibling::span")
	public static WebElement Market_we_serve_arrow;
	@FindBy(how = How.XPATH, using = "//span[text()='Service and support']")
	public static WebElement Service_support;
	
	@FindBy(how = How.XPATH, using = "//span[text()='Service and support']//following-sibling::span")
	public static WebElement Service_support_arrow;
	@FindBy(how = How.XPATH, using = "//span[text()='About Danfoss']")
	public static WebElement About_danfoss;
	@FindBy(how = How.XPATH, using = "//span[text()='About Danfoss']//following-sibling::span")
	public static WebElement About_danfoss_arrow;
	@FindBy(how = How.XPATH, using = "//span[text()='О компании']")
	public static WebElement About_danfoss_Russian;
	
	@FindBy(how = How.XPATH, using = "(//span[@class='item-caption'])[6]")
	public static WebElement Contact_us;
	
	@FindBy(how = How.XPATH, using = "(//span[@class='item-caption'])[6]") ////a[@href='/zh-cn/contact-us/']/span
	public static WebElement Contact_us_china;
	
	@FindBy(how = How.XPATH, using = "//span[text()='Contact us']//following-sibling::span")
	public static WebElement Contact_us_arrow;
	
	@FindBy(how = How.XPATH, using = "//span[text()='Read how we are Engineering Tomorrow']")
	public static WebElement Read_how;
	
	@FindBy(how = How.XPATH, using = "//span[contains(@class,'desktopMenuFirstLevelItemActive')]")
	public static WebElement Selectedmenu;
	
	@FindBy(how = How.XPATH, using = "//a[contains(@class,'ItemActive')]")
	public static WebElement Selectedmenu_noarrow;
	@FindBy(how = How.XPATH, using = "//*[local-name()='svg' and contains(@class,'ArrowIconActive')]")
	public static WebElement Selectedarrow;

	@FindBy(how = How.XPATH, using = "//div[contains(@class,'overlay')]")
	public static WebElement Overlay;
	
	@FindBy(how = How.XPATH, using = "//div[@class='link-list']")
	public static WebElement link_list_component;
	
	@FindBy(how = How.XPATH, using = "//h2[@class='card__title link-list__headline']")
	public static WebElement link_list_title;
	
	@FindBy(how = How.XPATH, using = "//ul[@class='link-list__list']")
	public static WebElement link_list_list;
	
	@FindBy(how = How.XPATH, using = "//ul[@class='link-list__list']//descendant::a[contains(@href,'case-studies')]")
	public static WebElement link_list_item_casestudies;
	
	
	@FindBy(how = How.XPATH, using = "//ul[@class='link-list__list']/li/a[contains(@href,'/en/service-and-support/case-stories/')]")
	public static WebElement link_list_item_casestudies2;
	
	@FindBy(how = How.XPATH, using = "//ul[@class='link-list__list']//descendant::a[contains(@href,'documentation')]")
	public static WebElement link_list_item_Documentation;
	@FindBy(how = How.XPATH, using = "//ul[@class='link-list__list']//descendant::a[contains(@href,'downloads')]")
	public static WebElement link_list_item_Downloads;
	@FindBy(how = How.XPATH, using = "//ul[@class='link-list__list']//descendant::a[contains(@href,'fix-and-troubleshooting')]")
	public static WebElement link_list_item_Fix_troubleshooting;	
	@FindBy(how = How.XPATH, using = "//ul[@class='link-list__list']//descendant::a[contains(@href,'learning')]")
	public static WebElement link_list_item_Learning;
	
	@FindBy(how = How.XPATH, using = "//ul[@class='link-list__list']//descendant::a[contains(@href,'case-studies')]//span")
	public static WebElement link_list_item_casestudies_icon;
	@FindBy(how = How.XPATH, using = "//ul[@class='link-list__list']//descendant::a[contains(@href,'documentation')]//span")
	public static WebElement link_list_item_Documentation_icon;
	@FindBy(how = How.XPATH, using = "//ul[@class='link-list__list']//descendant::a[contains(@href,'downloads')]//span")
	public static WebElement link_list_item_Downloads_icon;
	@FindBy(how = How.XPATH, using = "//ul[@class='link-list__list']//descendant::a[contains(@href,'fix-and-troubleshooting')]//span")
	public static WebElement link_list_item_Fix_troubleshooting_icon;	
	@FindBy(how = How.XPATH, using = "//ul[@class='link-list__list']//descendant::a[contains(@href,'learning')]//span")
	public static WebElement link_list_item_Learning_icon;
	
	@FindBy(how = How.XPATH, using = "//span[text()='Privacy policy']")
	public static WebElement privacyPolicy;
	
	@FindBy(how = How.XPATH, using = "(//a[text()='here'])[1]")
	public static WebElement privacyPolicy_Click_Here1;
	
	@FindBy(how = How.XPATH, using = "(//a[text()='here'])[2]")
	public static WebElement privacyPolicy_Click_Here2;
	
	@FindBy(how = How.XPATH, using = "//li[@class='breadcrumbs-list-item '][2]")
	public static WebElement breadcreumbs;
	
	@FindBy(how = How.XPATH, using = "(//div[text()='Danfoss Industries Pvt. Ltd.'])[1]")
	public static WebElement general_Information_Title;

	@FindBy(how = How.XPATH, using = "(//div[text()='Danfoss A/S'])[1]")
	public static WebElement general_Information_Title_local;


}
