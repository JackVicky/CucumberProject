package test.automation.pagelocators;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;


public class EventPageconstants {

	
	public WebDriver driver;

	public EventPageconstants(WebDriver driver) {
		this.driver = driver;
		PageFactory.initElements(driver, this);
	}
	
	@FindBy(how = How.XPATH, using = "(//span[@class='breadcrumbs-list-item__text'])[1]") 
	public static WebElement breadcrumbs1;

	@FindBy(how = How.XPATH, using = "(//span[@class='breadcrumbs-list-item__text'])[2]") 
	public static WebElement breadcrumbs2;

	@FindBy(how = How.XPATH, using = "//div[@class='filters']") 
	public static WebElement filter;

	@FindBy(how = How.XPATH, using = "//button[contains(@class,'reset-filter-button')]//descendant::span[@class='cta-content-text']")
	public static WebElement clear_filter;

	@FindBy(how = How.XPATH, using = "//div[@class='list-total-count']") 
	public static WebElement numberofresult;

	@FindBy(how = How.XPATH, using = "(//div[@class='filters-group__heading'])[1]") 
	public static WebElement Countries_filter;

	@FindBy(how = How.XPATH, using = "(//div[@class='filters-group__heading'])[3]") 
	public static WebElement Event_Categories_filter;

	@FindBy(how = How.XPATH, using = "(//div[@class='filters-group__heading'])[2]") 
	public static WebElement Market_filter;

	@FindBy(how = How.XPATH, using = "(//div[@class='filters-group__heading'])[4]") 
	public static WebElement Business_filter;

	@FindBy(how = How.XPATH, using = "(//div[@class='filters-group__heading'])[5]") 
	public static WebElement Megatrends_filter;



	@FindBy(how = How.XPATH, using = "(//div[@class='filters-group filters-group--collapsed']//child::div[@class='filters-group__heading'])[1]") 
	public static WebElement Countries_filters_collapsed;

	@FindBy(how = How.XPATH, using = "(//div[@class='filters-group filters-group--collapsed']//child::div[@class='filters-group__heading'])[3]") 
	public static WebElement Event_Categories_filters_collapsed;

	@FindBy(how = How.XPATH, using = "(//div[@class='filters-group filters-group--collapsed']//child::div[@class='filters-group__heading'])[2]") 
	public static WebElement Market_filters_collapsed;

	@FindBy(how = How.XPATH, using = "(//div[@class='filters-group filters-group--collapsed']//child::div[@class='filters-group__heading'])[4]") 
	public static WebElement Megatrends_filters_collapsed;

	@FindBy(how = How.XPATH, using = "(//div[@class='unselect-buttons-group']//descendant::span[@class='cta__content-text'])")
	public static WebElement Applied_filter;

	@FindBy(how = How.XPATH, using = "(//div[@class='unselect-buttons-group']//descendant::span[@class='icon icon-cancel'])")
	public static WebElement Applied_filter_close;

	@FindBy(how = How.XPATH, using = "//span[@class='sort-icons']//following-sibling::span[@class='cta-content-text']") 
	public static WebElement sort_button;

	@FindBy(how = How.XPATH, using = "//span[@class='sort-icons']//following-sibling::span[@class='cta-content-text']//following::option[@value='fromNowToFuture']") 
	public static WebElement Now_future;

	@FindBy(how = How.XPATH, using = "//span[@class='sort-icons']//following-sibling::span[@class='cta-content-text']//following::option[@value='fromFutureToNow']") 
	public static WebElement future_now;

	@FindBy(how = How.XPATH, using = "//span[@class='sort-icons']//following-sibling::span[@class='cta-content-text']//following::option[@value='pastEvents']") 
	public static WebElement Past;

	@FindBy(how = How.XPATH, using = "//span[@class='sort-icons']//following-sibling::span[@class='cta-content-text']//following::option[@value='title_asc']") 
	public static WebElement sort_title_asc;

	@FindBy(how = How.XPATH, using = "//span[@class='sort-icons']//following-sibling::span[@class='cta-content-text']//following::option[@value='title_desc']") 
	public static WebElement sort_title_desc;

	@FindBy(how = How.XPATH, using = "//ul[contains(@class,'tile-group  tile-group-wide ')]//child::li")
	public static WebElement Item_Tile;

	@FindBy(how = How.XPATH, using = "(//ul[contains(@class,'tile-group  tile-group-wide ')]//descendant::div[@class='tile__text-title'])[1]")
	public static WebElement Tile_title;

	@FindBy(how = How.XPATH, using = "(//ul[contains(@class,'tile-group  tile-group-wide ')]//descendant::a[contains(@class,'link clickable')])[1]")
	public static WebElement Tile_image;

	@FindBy(how = How.XPATH, using = "(//ul[contains(@class,'tile-group  tile-group-wide ')]//descendant::div[contains(@class,'tile__text-description')])[1]")
	public static WebElement Tile_description;

	@FindBy(how = How.XPATH, using = "(//ul[contains(@class,'tile-group  tile-group-wide ')]//descendant::div[contains(@class,'tile__text-details_item')])[1]")
	public static WebElement Tile_date;

	@FindBy(how = How.XPATH, using = "//h1[@class='page-heading']") 
	public static WebElement Page_heading;

	@FindBy(how = How.XPATH, using = "//ul[@class='pagination']") 
	public static WebElement pagination;

}
