package test.automation.pagelocators;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;



public class ProductPageconstants {

	public WebDriver driver;

	public ProductPageconstants(WebDriver driver) {
		this.driver = driver;
		PageFactory.initElements(driver, this);
	}
	//**************************************************************WebElements*******************************************************************************

	//Newsegment list along with product cat - 09/03/2021
	@FindBy(how = How.XPATH, using = "//div[contains(@class,'truncatedProductsList')]")
	public static WebElement Segment_columns_list;
	@FindBy(how = How.XPATH, using = "(//span[contains(@class,'truncatedProductsListMainRow')])[1]")
	public static WebElement Segment_columns_header;
	@FindBy(how = How.XPATH, using = "(//ul[contains(@class,'truncatedProductsListItems')])[1]")
	public static WebElement Segment_category_list;

	@FindBy(how = How.XPATH, using = "(//ul[contains(@class,'truncatedProductsListItems')])[2]//descendant::a")
	public static WebElement categories_11;

	@FindBy(how = How.XPATH, using = "//span[contains(text(),'+ more products')]")
	public static WebElement more_products;

	@FindBy(how = How.XPATH, using = "((//div[contains(@class,'desktopProductsMenu')]//descendant::a[contains(@href,'/en/products/dps/')])//span)[1]")
	public static WebElement Power_solutions_segment;
	@FindBy(how = How.XPATH, using = "((//div[contains(@class,'desktopProductsMenu')]//descendant::a[contains(@href,'/en/products/dcs/')])//span)[1]")
	public static WebElement Cooling_segment;
	@FindBy(how = How.XPATH, using = "((//div[contains(@class,'desktopProductsMenu')]//descendant::a[contains(@href,'/en/products/dhs/')])//span)[1]")
	public static WebElement Heating_segment;
	@FindBy(how = How.XPATH, using = "((//div[contains(@class,'desktopProductsMenu')]//descendant::a[contains(@href,'/en/products/dds/')])//span)[1]")
	public static WebElement Drives_segment;
	@FindBy(how = How.XPATH, using = "//div[contains(@class,'desktopProductsMenu')]//span[contains(@class,'truncatedProductsListMainRowNotClickable')]")
	public static WebElement Other_businesses_segment;
	@FindBy(how = How.XPATH, using = "//span[contains(@class,'NotClickable')]//ancestor::div[contains(@class,'truncatedProductsList')]//a")
	public static WebElement Other_businesses_segment_list;


	@FindBy(how = How.XPATH, using = "//ul[contains(@class,'desktopProductsMenuStatic')]")
	public static WebElement Static_segment;
	@FindBy(how = How.XPATH, using = "//ul[contains(@class,'desktopProductsMenuStatic')]//a[contains(@href,'/en/products/')]//span")
	public static WebElement All_Danfoss_products;
	@FindBy(how = How.XPATH, using = "//span[contains(text(),'How to buy Danfoss products?')]")
	public static WebElement Howto_buy_Danfoss_Products;
	@FindBy(how = How.XPATH, using = "(//ul[contains(@class,'desktopProductsMenuStatic')]//a[contains(@href,'/store.danfoss.com')]//span)[2]")
	public static WebElement Danfoss_product_store;
	@FindBy(how = How.XPATH, using = "//ul[contains(@class,'desktopProductsMenuStatic')]//a[contains(@href,'/en/service-and-support/document')]//span")
	public static WebElement Danfoss_Documentation;

	@FindBy(how = How.XPATH, using = "(//a[contains(@href,'/products/dps/valves')]//span)[1]")
	public static WebElement DPS_valves;
	
	@FindBy(how = How.XPATH, using = "(//a[contains(@href,'/en/products/dcs/valves')]//span)[1]")
	public static WebElement DCS_valves;
	
	@FindBy(how = How.XPATH, using = "(//span[contains(text(),'Valves')])[3]")
	public static WebElement climate_SolutionFor_Heating_Valves;
	
	@FindBy(how = How.XPATH, using = "//a[contains(@href,'/products/dhs/burner-components/')]//span")
	public static WebElement DHS_burner_component;
	
	@FindBy(how = How.XPATH, using = "//a[contains(@href,'/products/dds/ac-drives/')]//span")
	public static WebElement DDS_Ac_drives;
	
	@FindBy(how = How.XPATH, using = "//span[text()='Low-voltage drives']")
	public static WebElement DDS_Low_voltage_drive;
	
	//New product category page -- updated on 30/3/2021
	@FindBy(how = How.XPATH, using = "(//span[@class='breadcrumbs-list-item__text'])[3]") 
	public static WebElement P_C_breadcrumbs;
	
	@FindBy(how = How.XPATH, using = "//h1[@class='page-heading ']") 
	public static WebElement P_C_title;
	
	@FindBy(how = How.XPATH, using = "(//button[contains(@class,'expand-button')])[1]") 
	public static WebElement P_C_CTA_button;
	
	@FindBy(how = How.XPATH, using = "//ul[contains(@class,'tabs-list')]//li") 
	public static WebElement P_C_tab_bar;
	
	@FindBy(how = How.XPATH, using = "//li[contains(@class,'tabs__item active')]//span[text()='VACON Drives']") 
	public static WebElement P_C_active_tab;

	@FindBy(how = How.XPATH, using = "//div[contains(@class,'product-group-list tabs-content')]") 
	public static WebElement P_C_Product_list;
	
	@FindBy(how = How.XPATH, using = "//div[contains(@class,'page-content')]") 
	public static WebElement P_C_Page_content;
	
	@FindBy(how = How.XPATH, using = "//div[contains(@class,'product-group-item')]") 
	public static WebElement P_C_subcatergory_group;
		
	@FindBy(how = How.XPATH, using = "(//div[contains(@class,'product-group-item')]//h2)[1]") 
	public static WebElement P_C_subcatergory_title;
	
	@FindBy(how = How.XPATH, using = "(//div[@class='description'])[2]") 
	public static WebElement P_C_subcatergory_desc;
	
	@FindBy(how = How.XPATH, using = "(//ul[@class='tile-group tile-group-wide'])[1]") 
	public static WebElement P_C_subcatergory_tile_list;
	
	@FindBy(how = How.XPATH, using = "//h2[text()='VLT® drives']//following-sibling::ul//li") 
	public static WebElement P_C_subcatergory_list_morethan5;
	
	@FindBy(how = How.XPATH, using = "//h2[text()='VLT® drives']//following-sibling::div[contains(@class,'show-more-button')]//button") 
	public static WebElement P_C_subcatergory_show_more;
		
	@FindBy(how = How.XPATH, using = "(//div[@class='tile__text-title'])[1]") 
	public static WebElement P_C_subcatergory_product_title;
	
	@FindBy(how = How.XPATH, using = "(//div[@class='tile__text-title'])[2]") 
	public static WebElement P_C_subcatergory_product_title2;
	
	@FindBy(how = How.XPATH, using = "(//div[@class='tile__text-description'])[1]") 
	public static WebElement P_C_subcatergory_product_desc;
	
	@FindBy(how = How.XPATH, using = "(//div[contains(@class,'tile__image')])[1]") 
	public static WebElement P_C_subcatergory_product_image;
	
	@FindBy(how = How.XPATH, using = "(//li[@class='tile clearfix'])[1]") 
	public static WebElement P_C_subcatergory_whole_product_title;
	
	
	
	
	//Products page mouseover Webelements//



	@FindBy(how = How.XPATH, using = "//span[text()='AC drives']")
	public static WebElement AC_drives;
	
	@FindBy(how = How.XPATH, using = "//span[contains(text(),'Low-voltage drives')]")
	public static WebElement LowVoltage_drives;
	
	@FindBy(how = How.XPATH, using = "//span[text()='Appliance controls']")
	public static WebElement Appliance_controls;
	@FindBy(how = How.XPATH, using = "//span[text()='Burner components']")
	public static WebElement Burner_components;
	@FindBy(how = How.XPATH, using = "//span[text()='Compressors']")
	public static WebElement Compressors;
	@FindBy(how = How.XPATH, using = "//span[text()='Condensing units']")
	public static WebElement Condensing_unit;
	@FindBy(how = How.XPATH, using = "//span[text()='Differential pressure and flow controllers']")
	public static WebElement Differential_pressure_fc;
	@FindBy(how = How.XPATH, using = "//span[text()='Electronic controls']")
	public static WebElement Electronic_controls;
	@FindBy(how = How.XPATH, using = "//span[text()='Emission Monitoring']")
	public static WebElement Emission_monitoring;
	@FindBy(how = How.XPATH, using = "//span[text()='Energy metering']")
	public static WebElement Energy_metering;
	@FindBy(how = How.XPATH, using = "//span[text()='Energy recovery devices']")
	public static WebElement Energy_recovery_devices;
	@FindBy(how = How.XPATH, using = "//span[text()='Filter driers and strainers']")
	public static WebElement Filter_driers_strainers;
	@FindBy(how = How.XPATH, using = " //span[text()='Fire Safety']")
	public static WebElement Fire_safety;
	@FindBy(how = How.XPATH, using = "//span[text()='Floor heating; ice and snow melting']")
	public static WebElement Floor_heating_ice;
	@FindBy(how = How.XPATH, using = "//span[text()='Heat exchangers']")
	public static WebElement Heat_exchangers;
	@FindBy(how = How.XPATH, using = "//span[text()='Mobile electrification']")
	public static WebElement Mobile_electrification;
	@FindBy(how = How.XPATH, using = "//span[text()='Motors']")
	public static WebElement Motors;
	@FindBy(how = How.XPATH, using = "//span[text()='Power modules']")
	public static WebElement Power_modules;
	@FindBy(how = How.XPATH, using = "//span[text()='Power stacks']")
	public static WebElement Power_stacks;
	@FindBy(how = How.XPATH, using = "//span[text()='Pumps']")
	public static WebElement Pumps;
	@FindBy(how = How.XPATH, using = "//span[text()='Radiator and room thermostats']")
	public static WebElement Radiator_room_thermostats;
	@FindBy(how = How.XPATH, using = "//span[text()='Sensors and transmitters']")
	public static WebElement Sensors_transmitters;
	@FindBy(how = How.XPATH, using = "//span[text()='Sight glasses']")
	public static WebElement Sight_glasses;
	@FindBy(how = How.XPATH, using = "//span[text()='Smart heating']")
	public static WebElement Smart_heating;
	@FindBy(how = How.XPATH, using = "//span[text()='Soft starters']")
	public static WebElement Soft_starters;
	@FindBy(how = How.XPATH, using = "//span[text()='Software']")
	public static WebElement Software;
	@FindBy(how = How.XPATH, using = "//span[text()='Stations and domestic hot water']")
	public static WebElement Stations_domestic_hw;
	@FindBy(how = How.XPATH, using = "//span[text()='Steering']")
	public static WebElement Steering;
	@FindBy(how = How.XPATH, using = "//span[text()='Switches']")
	public static WebElement Switches;
	@FindBy(how = How.XPATH, using = "//span[text()='Valves']")
	public static WebElement Valves;
	@FindBy(how = How.XPATH, using = "//span[text()='All Danfoss Products']")  //in QA text()='All products' staging ='View all products'
	//
	public static WebElement View_all_products;
	@FindBy(how = How.XPATH, using = "//button[contains(@aria-label,'close')]") //QA @aria-label='Pop-up close' stag = 'Pop-up close button'
	public static WebElement Close_button;

	/*******************Product page via all product link*************************/

	@FindBy(how = How.XPATH, using = "(//span[@class='breadcrumbs-list-item__text'])[1]") 
	public static WebElement breadcrumbs;
	@FindBy(how = How.XPATH, using = "//div[@class='filters']") 
	public static WebElement filter;
	@FindBy(how = How.XPATH, using = "(//div[@class='filters-group__heading']//child::span[@class='icon icon-chevron-up-small'])[1]") 
	public static WebElement market_expandarrow;
	@FindBy(how = How.XPATH, using = "(//div[@class='filters-group__heading'])[1]") 
	public static WebElement Market_group;
	@FindBy(how = How.XPATH, using = "(//div[@class='filters-group__heading'])[2]") 
	public static WebElement Businessunit_group;
	@FindBy(how = How.XPATH, using = "(//div[@class='filters-group__heading']//child::span[@class='icon icon-chevron-up-small'])[2]") 
	public static WebElement Businessunit_expandarrow;

	@FindBy(how = How.XPATH, using = "(//div[@class='filters-group__items-wrapper'])[1]//descendant::span[@class='filters-group__item__title']") 
	public static WebElement Market_filter_list;
	@FindBy(how = How.XPATH, using = "(//div[@class='filters-group__items-wrapper'])[2]//descendant::span[@class='filters-group__item__title']") 
	public static WebElement Businessunit_filter_list;
	@FindBy(how = How.XPATH, using = "(//div[contains(@class,'product-segments')]//child::span)[2]") 
	public static WebElement product_segment_title;
	@FindBy(how = How.XPATH, using = "(//ul[contains(@class,'truncatedProductsListItems')])[1]") 
	public static WebElement product_segment_categories_list;
	@FindBy(how = How.XPATH, using = "((//div[contains(@class,'truncatedProductsList__')]//child::a[@href='/en/products/dps/'])//child::span)")
	public static WebElement All_product_Power_solutions_segment;
	@FindBy(how = How.XPATH, using = "((//div[contains(@class,'truncatedProductsList__')]//child::a[@href='/en/products/dcs/'])//child::span)")
	public static WebElement All_product_Cooling_segment;
	@FindBy(how = How.XPATH, using = "((//div[contains(@class,'truncatedProductsList__')]//child::a[@href='/en/products/dhs/'])//child::span)")
	public static WebElement All_product_Heating_segment;
	@FindBy(how = How.XPATH, using = "((//div[contains(@class,'truncatedProductsList__')]//child::a[@href='/en/products/dds/'])//child::span)")
	public static WebElement All_product_Drives_segment;
	
	@FindBy(how = How.XPATH, using = "//div[@class='page-description']//p") 
	public static WebElement product_description;
	@FindBy(how = How.XPATH, using = "//span[contains(@class,'truncatedProductsListMainRowNotClickable')]")
	public static WebElement All_product_Other_businesses_segment;
	@FindBy(how = How.XPATH, using = "(//div[contains(@class,'product-segments')]//child::img)[1]") 
	public static WebElement product_segment_image;
	
	@FindBy(how = How.XPATH, using = "//div[text()='Applications']//following::span[@class='filters-group__item__title']") 
	public static WebElement Applications_filter_list;

	@FindBy(how = How.XPATH, using = "//h1[contains(text(),'Products')]") 
	public static WebElement product_title;
	@FindBy(how = How.XPATH, using = "//div[@class='list-total-count']") 
	public static WebElement numberofresult;
	@FindBy(how = How.XPATH, using = "//h1[@class='page-heading']//following::a[contains(@href,'/products/')]") 
	public static WebElement product_list;

	/*******************************Page via selecting any product category*********/

	@FindBy(how = How.XPATH, using = "//div[@class='row breadcrumbs']") 
	public static WebElement breadcrumbs_category;
	@FindBy(how = How.XPATH, using = "//h1[@class='page-heading']") 
	public static WebElement category_title;
	@FindBy(how = How.XPATH, using = "//div[@class='list-total-count']") 
	public static WebElement category_numberofresult;
	@FindBy(how = How.XPATH, using = "//div[@class='filters']") 
	public static WebElement filter_category;
	@FindBy(how = How.XPATH, using = "//div[@class='product-segments-item col-sm-6 col-md-4']") 
	public static WebElement productcategory_numberofresult;

	@FindBy(how = How.XPATH, using = "(//div[@class='filters-group__heading'])[1]") 
	public static WebElement Market_filter;
	@FindBy(how = How.XPATH, using = "(//div[@class='filters-group__heading'])[2]") 
	public static WebElement Business_filter;

	@FindBy(how = How.XPATH, using = "(//div[@class='filters-group__heading'])[3]") 
	public static WebElement Brands_filter;

	@FindBy(how = How.XPATH, using = "(//div[@class='filters-group__heading'])[4]") 
	public static WebElement Solutions_filter;
	@FindBy(how = How.XPATH, using = "(//div[@class='filters-group__heading'])[5]") 
	public static WebElement Applications_filter;
	@FindBy(how = How.XPATH, using = "(//div[@class='filters-group__heading'])[6]") 
	public static WebElement Producttype_filter;
	//div[@class='unselect-buttons-group']
	@FindBy(how = How.XPATH, using = "//div[@style='display: none;']//preceding-sibling::div[@class='filters-group__heading']") 
	public static WebElement Market_filters_collapsed;
	@FindBy(how = How.XPATH, using = "//div[contains(@style,'display: block')]//preceding-sibling::div[@class='filters-group__heading']") 
	public static WebElement Expanded_filters_list;


	@FindBy(how = How.XPATH, using = "(//div[@class='filters-group__items-wrapper'])[n]//descendant::span[@class='filters-group__item__title']") 
	public static WebElement Market_filter_list1;
	/// index n can we used to iterate to multiple filter section
	@FindBy(how = How.XPATH, using = "//span[@class='sort-icons']//following-sibling::span[@class='cta-content-text']") 
	public static WebElement sort_button;
	@FindBy(how = How.XPATH, using = "//span[@class='sort-icons']//following-sibling::span[@class='cta-content-text']//following::option[@value='default_sort']") 
	public static WebElement Default_sorting;
	@FindBy(how = How.XPATH, using = "//span[@class='sort-icons']//following-sibling::span[@class='cta-content-text']//following::option[@value='title_asc']") 
	public static WebElement sort_title_asc;
	@FindBy(how = How.XPATH, using = "//span[@class='sort-icons']//following-sibling::span[@class='cta-content-text']//following::option[@value='title_desc']") 
	public static WebElement sort_title_desc;
	@FindBy(how = How.XPATH, using = "//div[@class='tile__text-title']") 
	public static WebElement category_list;



	@FindBy(how = How.XPATH, using = "(//div[@class='tile__text-title'])[1]") 
	public static WebElement category_title_inside;
	@FindBy(how = How.XPATH, using = "(//div[@class='tile__text-title'])[1]//following-sibling::div[@class='tile__text-description']//descendant::p") 
	public static WebElement category_description;
	@FindBy(how = How.XPATH, using = "(//img[@class='ktr lazyloaded'])[1]") 
	public static WebElement category_image;

	@FindBy(how = How.XPATH, using = "//div[@class='unselect-buttons-group']") 
	public static WebElement filter_group;
	@FindBy(how = How.XPATH, using = "(//div[contains(@class,'show-more-button-wrapper')]//descendant::span[contains(@class,'cta-content-text')])[2]")
	public static WebElement products_show_more;	
	@FindBy(how = How.XPATH, using = "(//div[contains(@class,'show-more-button-wrapper')]//following-sibling::span)[2]")
	public static WebElement products_show_more_count;

	@FindBy(how = How.XPATH, using = "//button[contains(@class,'reset-filter-button')]//descendant::span[@class='cta-content-text']")
	public static WebElement clear_filter;

	@FindBy(how = How.XPATH, using = "	(//div[@class='unselect-buttons-group']//descendant::span[@class='cta__content-text'])")
	public static WebElement Applied_filter;
	@FindBy(how = How.XPATH, using = "(//div[@class='unselect-buttons-group']//descendant::span[@class='icon icon-cancel'])")
	public static WebElement Applied_filter_close;

	//PMP 
	@FindBy(how = How.XPATH, using = "//h1[@class='page-heading ']")
	public static WebElement Product_page_title;
	@FindBy(how = How.XPATH, using = "(//div[contains(@class,'rte')])[1]")
	public static WebElement RTE_component;
	@FindBy(how = How.XPATH, using = "//div[@class='link-list']")
	public static WebElement link_list_component;
	@FindBy(how = How.XPATH, using = "(//ul[@class='link-list__list']//a)[1]")
	public static WebElement link_list_item;
	@FindBy(how = How.XPATH, using = "(//div[@class='card__cta']//a)[1]")
	public static WebElement cta_button_link;

	@FindBy(how = How.XPATH, using = "(//picture//child::img[contains(@data-src,'/media')])[1]")
	public static WebElement Media_component;
	@FindBy(how = How.XPATH, using = "//h2[text()='Features and benefits']")
	public static WebElement Features_benefits_title;
	@FindBy(how = How.XPATH, using = "//div[contains(@class,'paddings benefits')]")
	public static WebElement Benefits_section;
	@FindBy(how = How.XPATH, using = "//div[contains(@class,'benefits__text')]")
	public static WebElement Each_benefits;


	//tabs
	@FindBy(how = How.XPATH, using = "//div[@class='sticky-tabs__header-controls']")
	public static WebElement Sticky_tab_section;
	@FindBy(how = How.XPATH, using = "//span[contains(@class,'link--active')]")
	public static WebElement Active_tab;
	@FindBy(how = How.XPATH, using = "//span[@data-id='#tab-overview']")
	public static WebElement Overview_tab;
	@FindBy(how = How.XPATH, using = "//span[@data-id='#tab-documents']")
	public static WebElement Documents_tab;
	@FindBy(how = How.XPATH, using = "//span[@data-id='#tab-software']")
	public static WebElement Software_tab;
	
	@FindBy(how = How.XPATH, using = "(//a[@href='/en/products/dhs/valves/hydronic-balancing-and-control/manual-balancing-valves/'])[2]")
	public static WebElement manual_Balancing_Valves;
	@FindBy(how = How.XPATH, using = "(//div[@class='image-gallery dynamic-component']/div/div/div/div/div/div/picture/img)[1]")
	public static WebElement manual_Balancing_Valve_MSVBD;
	@FindBy(how = How.XPATH, using = "(//div[@class='image-gallery dynamic-component'])[1]")
	public static WebElement media_component_video_1;
	@FindBy(how = How.XPATH, using = "(//div[@class='image-gallery dynamic-component'])[2]")
	public static WebElement media_component_video_2;
	@FindBy(how = How.XPATH, using = "//span[contains(text(),'Electric converters and machines')]")
	public static WebElement electric_converters_machines;
	@FindBy(how = How.XPATH, using = "(//a[@href='/en/products/dps/electric-converters-and-machines/electric-converters-and-machines/electric-converters/'])[2]")
	public static WebElement electric_converters;
	@FindBy(how = How.XPATH, using = "//img[@data-src='/media/4239/applications-process-cooling-danfoss.jpg?anchor=center&mode=crop&width=1050']")
	public static WebElement mediaComponent;
	@FindBy(how = How.XPATH, using = "//img[@data-src='/media/4239/applications-process-cooling-danfoss.jpg?anchor=center&mode=crop&width=150']")
	public static WebElement mediaComponent_Thumb;
	@FindBy(how = How.XPATH, using = "(//div[@class='thumbnail-image-wrapper slide-with-reserved-height'])[1]/picture/img")
	public static WebElement media_component_video_1_thumbnail1;
	
	
	@FindBy(how = How.XPATH, using = "(//button[@class='cta cta--with-icon cta--alpha cta--play-video'])[1]")
	public static WebElement media_Play;
	@FindBy(how = How.XPATH, using = "//div[@class='main-image-wrapper slide-with-reserved-height']/picture/img")
	public static WebElement media_component_video_1_thumbImage;
	@FindBy(how = How.XPATH, using = "(//div[@class='main-image-wrapper slide-with-reserved-height']/picture/img)[2]")
	public static WebElement media_component_video_2_thumbImage;
	@FindBy(how = How.XPATH, using = "(//button[@class='cta cta--with-icon cta--alpha cta--play-video'])[2]")
	public static WebElement media_component_PlayButton_video_2;
	
	
	@FindBy(how = How.XPATH, using = "(//div[@class='slide-with-border'])[2]")
	public static WebElement media_component_video_1_thumbImageBorder;
	@FindBy(how = How.XPATH, using = "(//div[@class='grid-danf-fe-rte swiper-slide-text'])[1]")
	public static WebElement media_Component_video_1_Caption;
	@FindBy(how = How.XPATH, using = "(//div[@class='slide-with-border'])[4]")
	public static WebElement mediaComponent_Image_Border;
	@FindBy(how = How.XPATH, using = "//div[@class='slide-with-border'][1]")
	public static WebElement mediaComponent_Media_Image_Border;
	@FindBy(how = How.XPATH, using = "//div[@class='ytp-cued-thumbnail-overlay-image']")
	public static WebElement media_Image_Video;
	@FindBy(how = How.XPATH, using = "//button[@class='ytp-large-play-button ytp-button']")
	public static WebElement play_Video;
	@FindBy(how = How.XPATH, using = "//iframe[@class='videoPlayerIframe__20N8U']")
	public static WebElement play_Video_Frame;
	@FindBy(how = How.XPATH, using = "//iframe[@class='videoPlayerIframe__20N8U']")
	public static WebElement media_component_play_1_Video_2_Frame_1;
	@FindBy(how = How.XPATH, using = "(//iframe[@class='videoPlayerIframe__20N8U'])[2]")
	public static WebElement media_component_play_1_Video_2_Frame_2;
	@FindBy(how = How.XPATH, using = "//button[contains(@class,'closeButton__3Lij')]")////button[contains(@class,'closeButton__3Lij_ close animatedCloseButton__AV-vN')]
	public static WebElement close_Video;
	@FindBy(how = How.XPATH, using = "//div[@class='popup-backdrop popupBackdrop__12VOh']")////button[contains(@class,'closeButton__3Lij_ close animatedCloseButton__AV-vN')]
	public static WebElement close_Video_By_Outside_Click;
	@FindBy(how = How.XPATH, using = "//iframe[@name='cookie-information-sharinglibrary-iframe']")
	public static WebElement close_Video_Frame;
	@FindBy(how = How.XPATH, using = "//img[@data-src='/media/5503/pressure-switches-for-industrial-hydraulics-danfoss.jpg?anchor=center&mode=crop&width=1050']")
	public static WebElement Main_Product_1;
	@FindBy(how = How.XPATH, using = "(//button[@class='cta cta--with-icon cta--alpha cta--play-video'])[2]")
	public static WebElement media_component_video_2_Play_Button_1;
	@FindBy(how = How.XPATH, using = "(//button[@class='cta cta--with-icon cta--alpha cta--play-video'])[3]")
	public static WebElement media_component_video_2_Play_Button_2;
	@FindBy(how = How.XPATH, using = "(//div[@class='grid-danf-fe-rte swiper-slide-text'])[3]")
	public static WebElement Main_product_no_caption;
	@FindBy(how = How.XPATH, using = "//button[@aria-label='Play'][1]")
	public static WebElement Video_Component_1_Play;
	@FindBy(how = How.XPATH, using = "(//button[@class='ytp-large-play-button ytp-button'])[1]")
	public static WebElement Video_Component_2_Play;
	@FindBy(how = How.XPATH, using = "//div[@class='swiper-button-next']/span")
	public static WebElement next_Slide;
	
	@FindBy(how = How.XPATH, using = "//img[@data-src='/media/1072/dps_plus1-function-blocks.jpg?anchor=center&mode=crop&width=1050']")
	public static WebElement single_Component;
	@FindBy(how = How.XPATH, using = "//img[@data-src='/media/1069/dps_software-development-tools.jpg?anchor=center&mode=crop&width=1050']")
	public static WebElement single_Component_Image;
	@FindBy(how = How.XPATH, using = "//div[contains(text(),'Software Plus+1')]")
	public static WebElement single_Component_Caption;
	@FindBy(how = How.XPATH, using = "//iframe[@name='cookie-information-sharinglibrary-iframe']")
	public static WebElement single_Component_Frame;
	@FindBy(how = How.XPATH, using = "//button[@class='closeButton__3Lij_ close animatedCloseButton__AV-vN']")
	public static WebElement single_Component_Close;
	@FindBy(how = How.XPATH, using = "//div[@id='title-Katalon Studio']")
	public static WebElement ExpandCollapseComponent1;
	@FindBy(how = How.XPATH, using = "(//div[@class='expand-collapse-item expand-collapse-item--opened']//div[@aria-expanded='true'])")
	public static WebElement EC_Component_1;
	@FindBy(how = How.XPATH, using = "(//div[@class='expand-collapse-item']//div[@aria-expanded='false'])[3]")
	public static WebElement EC_Component_1_Collapsed_State;
	@FindBy(how = How.XPATH, using = "(//div[@class='expand-collapse-item']//div[@aria-expanded='false'])[4]")
	public static WebElement EC_Component_2_Collapsed_State;
	@FindBy(how = How.XPATH, using = "//picture/img[@src='/media/1327/work_functions_home_1120x747.jpg?anchor=center&mode=crop&width=640']")
	public static WebElement EC_Component_2_Expanded_Image;
	@FindBy(how = How.XPATH, using = "//div[@class='expand-collapse-item expand-collapse-item--opened']//div[@aria-expanded='true']")
	public static WebElement EC_Component_1_Expanded_State;
	@FindBy(how = How.XPATH, using = "//div[@class='expand-collapse-item expand-collapse-item--opened']//div[@aria-expanded='true']")
	public static WebElement EC_Component_2_Expanded_State;
	@FindBy(how = How.XPATH, using = "//div[@aria-expanded='true']")
	public static WebElement EC_Component_1_Arrow;
	@FindBy(how = How.XPATH, using = "//img[@src='/media/7674/ets-colibri-01.jpg?anchor=center&mode=crop&width=640']")
	public static WebElement EC_Component_2_Video;
	@FindBy(how = How.XPATH, using = "(//button[@class='cta cta--with-icon cta--alpha cta--play-video'])[7]")
	public static WebElement EC_Component_1_Video_1;
	@FindBy(how = How.XPATH, using = "//button[@class='ytp-large-play-button ytp-button']")
	public static WebElement EC_Component_2_Video_Play;
	@FindBy(how = How.XPATH, using = "(//button[@class='cta cta--with-icon cta--alpha cta--play-video'])[5]")
	public static WebElement EC_Component_1_Video_Play;
	@FindBy(how = How.XPATH, using = "//iframe[@id='qRzkiutPGv4']")
	public static WebElement EC_Component_2_Video_frame;
	@FindBy(how = How.XPATH, using = "//iframe[@class='videoPlayerIframe__20N8U']")
	public static WebElement EC_Component_1_Video_frame;
	@FindBy(how = How.XPATH, using = "//button[contains(@class,'closeButton__3Lij_ close-button popupCloseButton__S_bt0 animatedCloseButton__AV-vN')]")
	public static WebElement EC_Component_close_video;
	@FindBy(how = How.XPATH, using = "//div[@id='title-Metaverse']")
	public static WebElement FAQ_Component1;
	@FindBy(how = How.XPATH, using = "//div[@id='title-Metaverse']/div")
	public static WebElement FAQ_Component1_Title;
	@FindBy(how = How.XPATH, using = "//section[contains(text(),'How Do I Purchase A Membership ?')]")
	public static WebElement FAQ_Component2;
	@FindBy(how = How.XPATH, using = "//div[@id='title-Metaverse' and @aria-expanded='false']")
	public static WebElement FAQ_Component1_Arrow_Down;
	@FindBy(how = How.XPATH, using = "//div[@id='title-Metaverse' and @aria-expanded='true']")
	public static WebElement FAQ_Component1_Arrow_Up;
	@FindBy(how = How.XPATH, using = "//div[@id='content-Metaverse']/p")
	public static WebElement FAQ_Component1_content;
	
	@FindBy(how = How.XPATH, using = "//section[contains(text(),'Ask us anything')]")
	public static WebElement FAQ_Ask_Us_Anything;
	@FindBy(how = How.XPATH, using = "//button[@data-url='https://www.youtube.com/watch?v=RLTlcAqcFB0']")
	public static WebElement FAQ_Ask_Us_Anything_Play_button;
	@FindBy(how = How.XPATH, using = "//button[@data-url='https://youtu.be/zszCTb_GzB4']")
	public static WebElement FAQ_Metaverse_Play_Button;
	@FindBy(how = How.XPATH, using = "//iframe[@id='RLTlcAqcFB0']")
	public static WebElement play_Video_Frame_FAQ3;
	@FindBy(how = How.XPATH, using = "//button[@class='ytp-play-button ytp-button']")
	public static WebElement pause_Video_FAQ3;
	@FindBy(how = How.XPATH, using = "//iframe[@id='zszCTb_GzB4']")
	public static WebElement play_Video_Frame_FAQ_Metaverse;
	
	@FindBy(how = How.XPATH, using = "//div[@class='learning-component']")
	public static WebElement Learning_Component;
	@FindBy(how = How.XPATH, using = "//div[@class='table--nested-cell']//span[contains(text(),'Name')]")
	public static WebElement Learning_Component_Name;
	@FindBy(how = How.XPATH, using = "//div[@class='table--nested-cell']//span[contains(text(),'Language')]")
	public static WebElement Learning_Component_Language;
	@FindBy(how = How.XPATH, using = "(//div[@class='learning-table-body-cell-wrapper'])[2]/span/following::button[1]")
	public static WebElement LC_Record_Arrow;
	@FindBy(how = How.XPATH, using = "(//tr[@class='learning-table-body-main-row row-with-expand-button '])[1]/td[1]")
	public static WebElement LC_Record_Background_Colour;
	@FindBy(how = How.XPATH, using = "//span[@class='icon icon-filter active-element']")
	public static WebElement LC_Filter;
	@FindBy(how = How.XPATH, using = "(//div[@class='learning-table-body-cell-wrapper']/span)[1]")
	public static WebElement LC_Row_Record_1;
	@FindBy(how = How.XPATH, using = "(//tr[@class='learning-table-body-description-row ']/td)[1]")
	public static WebElement LC_Row_Record_1_Description;
	@FindBy(how = How.XPATH, using = "(//button[@class='cta expand-button '])[1]")
	public static WebElement LC_Row_Record_Arrow;
	@FindBy(how = How.XPATH, using = "(//a[@class='cta cta--large cta--alpha enroll-button'])[1]")
	public static WebElement LC_CTA_Button;
	@FindBy(how = How.XPATH, using = "//button[@class='cta expand-button open']/span")
	public static WebElement LC_Row_Record_Arrow_Up;
	@FindBy(how = How.XPATH, using = "(//button[@class='cta no-ktr cta--small cta--block expand-button']/span)[1]")
	public static WebElement LC_Next_Page_Arrow_Icon;
	@FindBy(how = How.XPATH, using = "//button[@class='cta no-ktr cta--small cta--block expand-button']//span[@class='icon icon-chevron-down-small']")
	public static WebElement LC_Next_Page;
	@FindBy(how = How.XPATH, using = "//div[@class='filters-group__item']//span[text()='English']")
	public static WebElement LC_Filter_English;
	@FindBy(how = How.XPATH, using = "//span[text()='Reset all filters']")
	public static WebElement LC_Filter_Reset;
	
	@FindBy(how = How.XPATH, using = "(//div[@class='half-ktr clearfix spot-two_plus_one-container '])[1]")
	public static WebElement Spot_Group_1;
	@FindBy(how = How.XPATH, using = "(//div[@class='spot spot-two_plus_one spot-two_plus_one--large col-sm-9 col-md-6 no-ktr'])[1]")
	public static WebElement Spot_Group_1_Tile1;
	@FindBy(how = How.XPATH, using = "(//div[contains(text(),'Automate anything you see')])[1]")
	public static WebElement Spot_Group_1_Tile3_Description;
	@FindBy(how = How.XPATH, using = "(//div[contains(text(),'San Francisco: Apple’s upcoming smartphone iPhone 14 Pro')])[1]")
	public static WebElement Spot_Group_1_Tile2_Description;
	@FindBy(how = How.XPATH, using = "(//span[@class='icon icon-external-link'])[1]")
	public static WebElement Spot_Group_External_Link_Exit_Icon;
	@FindBy(how = How.XPATH, using = "(//div[@class='col-sm-12 text-center spot-two_plus_one-group-link ktr']/a)[1]")
	public static WebElement Spot_Group_1_CTA_Button_1;
	@FindBy(how = How.XPATH, using = "(//div[@class='col-sm-12 text-center spot-two_plus_one-group-link ktr']/a)[2]")
	public static WebElement Spot_Group_1_CTA_Button_2;
	@FindBy(how = How.XPATH, using = "(//div[@class='spot spot-two_plus_one spot-two_plus_one--large col-sm-9 col-md-6 no-ktr'])[2]")
	public static WebElement Spot_Group_2_Tile1;
	@FindBy(how = How.XPATH, using = "(//div[contains(text(),'San Francisco: Apple’s upcoming smartphone iPhone 14 Pro')])[2]")
	public static WebElement Spot_Group_2_Tile2_Description;
	@FindBy(how = How.XPATH, using = "(//div[contains(text(),'Automate anything you see')])[2]")
	public static WebElement Spot_Group_2_Tile3_Description;		
	@FindBy(how = How.XPATH, using = "(//div[@class='col-sm-12 text-center spot-two_plus_one-group-link ktr']/a)[3]")
	public static WebElement Spot_Group_2_CTA_Button_1;
	@FindBy(how = How.XPATH, using = "(//button[@aria-label='Video play button'])[9]")
	public static WebElement Spot_Group_2_Play_Button;
	@FindBy(how = How.XPATH, using = "(//div[@class='spot-image-container '])[4]")
	public static WebElement Spot_Group_2_Clickable_Tile;
	@FindBy(how = How.XPATH, using = "(//div[contains(text(),'Introduction To Sikuli GUI Automation Tool (Automate Anything You See On Screen) – Sikuli Tutorial #1')])[3]")
	public static WebElement Spot_Group_2_Tile3;
	@FindBy(how = How.XPATH, using = "//iframe[@id='Lg3m4VnZxew']")
	public static WebElement Spot_Group_2_Play_Button_Frame;
	@FindBy(how = How.XPATH, using = "//div[@class='spot-cascade-content-container']/h2/section[contains(text(),'NASA calls off major Artemis-1 moon rocket launch over safety concerns')]")
	public static WebElement Spot_Group_Casecade_1;
	@FindBy(how = How.XPATH, using = "//button[@data-url='https://youtu.be/Te-OylBaWF0']")
	public static WebElement Spot_Group_Casecade_1_Play_Button;
	@FindBy(how = How.XPATH, using = "//button[@data-url='https://www.youtube.com/watch?v=9gAZO5rRtLo']")
	public static WebElement Spot_Group_Casecade_4_Play_Button;
	@FindBy(how = How.XPATH, using = "//div[@class='spot-cascade-content-container']//h2")
	public static WebElement Spot_Group_Casecade_1_Title;
	@FindBy(how = How.XPATH, using = "(//div[@class='col-sm-6 spot-image-container  ktr']/div[text()='TEST'])[1]")
	public static WebElement Spot_Group_Casecade_1_Caption;
	@FindBy(how = How.XPATH, using = "//button[@data-url='https://youtu.be/MSjYJ0F6gwk']")
	public static WebElement Spot_Group_Casecade_1_Link_Button;
	@FindBy(how = How.XPATH, using = "//h3[@class='spot-cascade__title']")
	public static WebElement Spot_Group_Casecade_2_Title;
	@FindBy(how = How.XPATH, using = "//h4[@class='spot-cascade__title']")
	public static WebElement Spot_Group_Casecade_3_Title;
	@FindBy(how = How.XPATH, using = "//div[@class='spot-cascade__cta']/a/span/span[2]")
	public static WebElement Spot_Group_Casecade_1_Link_Button_Exit_Icon;
	@FindBy(how = How.XPATH, using = "//iframe[@,class='videoPlayerIframe__20N8U']")
	public static WebElement Spot_Group_Casecade_1_Play_Button_Frame;
	@FindBy(how = How.XPATH, using = "//iframe[@id='9gAZO5rRtLo']")
	public static WebElement Spot_Group_Casecade_4_Play_Button_Frame;
	@FindBy(how = How.XPATH, using = "(//span[@class='cta-content'])[47]/span")
	public static WebElement Spot_Group_Casecade_4_cta_Button;
	@FindBy(how = How.XPATH, using = "(//span[@class='icon icon-external-link'])[6]")
	public static WebElement Spot_Group_MultiLink_Exit_Button;
	
	@FindBy(how = How.XPATH, using = "(//button[@data-url='https://www.youtube.com/watch?v=IdYAjPeSbEo&t=4s'])[1]")
	public static WebElement Spot_Group_MultiLink_Video_Play_Button;
	@FindBy(how = How.XPATH, using = "//iframe[@id='IdYAjPeSbEo']")
	public static WebElement Spot_Group_Multilink_Play_Button_Frame;
	@FindBy(how = How.XPATH, using = "(//a[@href='https://kubernetes.io/#tab-overview'])[2]")
	public static WebElement Spot_Group_Multilink_External_Link;
	@FindBy(how = How.XPATH, using = "//div[contains(text(),'Test Automation')]")
	public static WebElement Spot_Group_Multilink_Title;
	@FindBy(how = How.XPATH, using = "//div[@class='spot-content__description-inner']/p[contains(text(),'Test automation')]")
	public static WebElement Spot_Group_Multilink_Description;
	@FindBy(how = How.XPATH, using = "//div[contains(text(),'OnePlus 10 Pro goes')]")
	public static WebElement Spot_Group_SingleLink;
	@FindBy(how = How.XPATH, using = "(//div[@class='spot-content__title spot-content__external'])[2]/span")
	public static WebElement Spot_Group_SingleLink_External_Link_Icon;
	
	@FindBy(how = How.XPATH, using = "//div[@class='spot spot-singlelink col-sm-6  col-md-4']/a[@href='https://danfoss-webex-staging.trafficmanager.net/en/service-and-support/downloads/dhs/danfoss-installer-app/#tab-overview']")
	public static WebElement Spot_Group_SingleLink_Image;
	@FindBy(how = How.XPATH, using = "//button[@data-url='https://youtu.be/IdYAjPeSbEo']")
	public static WebElement Spot_Group_SingleLink_Play_Button;
	@FindBy(how = How.XPATH, using = "//p[contains(text(),'Samsung has once again released a new')]")
	public static WebElement Spot_Group_SingleLink_Title;
	@FindBy(how = How.XPATH, using = "//div[@class='full-bleed-image-spot--img-wrapper']")
	public static WebElement Slider_FullBleed_Img;
	@FindBy(how = How.XPATH, using = "//h2[contains(text(),'Test_Slider')]")
	public static WebElement Slider_Title;
	@FindBy(how = How.XPATH, using = "//p[contains(text(),'Portico HR allows clients to manage')]")
	public static WebElement Slider_Description;
	@FindBy(how = How.XPATH, using = "//span[text()='Play video']")
	public static WebElement Slider_Play_Video;
	@FindBy(how = How.XPATH, using = "//img[@src='/media/yfmodiia/landing-page-monterrey.jpg?anchor=center&mode=crop&width=1280&height=420']")
	public static WebElement Slider_Image;
	@FindBy(how = How.XPATH, using = "//iframe[@id='kb2fDY6dmw4']")
	public static WebElement Slider_Video_Frame;
	@FindBy(how = How.XPATH, using = "//div[@class='page-heading--wrapper']/h1")
	public static WebElement pageTitle;

	@FindBy(how = How.XPATH, using = "//span[text()='Climate Solutions for cooling']")
	public static WebElement climate_Solution_For_Cooling;
	@FindBy(how = How.XPATH, using = "//div[@class='grid-danf-fe-rte card__description page-description']/p")
	public static WebElement product_Page_Paragraph;
	@FindBy(how = How.XPATH, using = "(//span[text()='Climate Solutions for heating'])[1]")
	public static WebElement climate_Solution_For_Heating;
	@FindBy(how = How.XPATH, using = "(//span[text()='Drives'])[1]")
	public static WebElement drives;
	@FindBy(how = How.XPATH, using = "//span[text()='Keep me updated']")
	public static WebElement keepMeUpdated;
	@FindBy(how = How.XPATH, using = "//div[@class='popup-container popupContainer__20g0a']//div[@id='popup-content']")
	public static WebElement signMeUp_Form;
	@FindBy(how = How.XPATH, using = "//div[@class='rc-anchor rc-anchor-invisible rc-anchor-light  rc-anchor-invisible-hover']/div/div/div[@class='rc-anchor-logo-img rc-anchor-logo-img-large']")
	public static WebElement signMeUp_Form_Captcha;
	@FindBy(how = How.XPATH, using = "//iframe[@title='reCAPTCHA']")
	public static WebElement captcha_Iframe;
	@FindBy(how = How.XPATH, using = "//button[@class='closeButton__3Lij_ close animatedCloseButton__AV-vN']")
	public static WebElement close_SignMeUp_Form;
	@FindBy(how = How.XPATH, using = "//legend[text()='Please let us know, if you are representing a business or signing up as a private person.']")
	public static WebElement signMeUp_Form_Title;
	@FindBy(how = How.XPATH, using = "//span[text()='Representing a business']")
	public static WebElement Representing_a_business;
	@FindBy(how = How.XPATH, using = "//span[text()='Private person']")
	public static WebElement Private_Person;
	@FindBy(how = How.XPATH, using = "//label[text()='First name']")
	public static WebElement first_Name;
	@FindBy(how = How.XPATH, using = "//label[text()='First name']/span")
	public static WebElement first_Name_Star;
	@FindBy(how = How.XPATH, using = "//label[text()='Last name']")
	public static WebElement last_Name;
	@FindBy(how = How.XPATH, using = "//label[text()='Last name']/span")
	public static WebElement last_Name_Star;
	@FindBy(how = How.XPATH, using = "//label[text()='Company']")
	public static WebElement Company;
	@FindBy(how = How.XPATH, using = "//label[text()='Company']/span")
	public static WebElement Company_Star;
	@FindBy(how = How.XPATH, using = "//label[text()='Company type']")
	public static WebElement Company_Type;
	@FindBy(how = How.XPATH, using = "//label[text()='Company type']/span")
	public static WebElement Company_Type_Star;
	@FindBy(how = How.XPATH, using = "//label[text()='Choose company type']")
	public static WebElement Company_Type_Dropdown;
	@FindBy(how = How.XPATH, using = "//label[text()='Department']")
	public static WebElement Department_Name;
	@FindBy(how = How.XPATH, using = "//label[text()='Department']/span")
	public static WebElement Department_Dropdown_Star;
	@FindBy(how = How.XPATH, using = "//label[text()='Choose department']")
	public static WebElement Department_Type_Dropdown;
	@FindBy(how = How.XPATH, using = "//label[text()='Function']")
	public static WebElement Function_Name;
	@FindBy(how = How.XPATH, using = "//label[text()='Function']/span")
	public static WebElement Function_Dropdown_Star;
	@FindBy(how = How.XPATH, using = "//label[text()='Choose function']")
	public static WebElement Function_Type_Dropdown;
	@FindBy(how = How.XPATH, using = "//label[text()='Email']")
	public static WebElement Email_Name;
	@FindBy(how = How.XPATH, using = "//label[text()='Email']/span")
	public static WebElement Email_Star;
	@FindBy(how = How.XPATH, using = "//label[text()='Country/region']")
	public static WebElement Country_region_Name;
	@FindBy(how = How.XPATH, using = "//label[text()='Country/region']/span")
	public static WebElement Country_region_Dropdown_Star;
	@FindBy(how = How.XPATH, using = "//label[text()='Choose country/region']")
	public static WebElement Country_region_Type_Dropdown;
	@FindBy(how = How.XPATH, using = "//a[@href='/en/terms/subscription-terms/']")
	public static WebElement Subscription_Terms_And_Condition;
	@FindBy(how = How.XPATH, using = "(//a[@href='/en/terms/privacy/'])[2]")
	public static WebElement Privacy_Policy;
	
	
	
}
