package test.automation.pagelocators;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class DIPLogin  {

	public WebDriver driver;

	public DIPLogin(WebDriver driver) {
		this.driver = driver;
		PageFactory.initElements(driver, this);
	}
	
	@FindBy(xpath = "//div[@id='coiPage-1']//button[text()='Accept all']")
	public static WebElement acceptCookie;

	@FindBy(xpath="//span[text()='Log in']")
	public static WebElement loginLink;

	@FindBy(xpath = "//input[@id='email']")
	public static WebElement emailId;

	@FindBy(xpath = "//input[@id='password']")
	public static WebElement password;

	@FindBy(xpath ="//button[@type='submit']")
	public static WebElement loginButton;

	@FindBy(xpath = "//div/p[text()='Hello Asha']")
	public static WebElement helloText;

}
