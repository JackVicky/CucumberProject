package test.automation.pagelocators;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;

public class RegionSelectionPageConstants {
	
	public WebDriver driver;

	public RegionSelectionPageConstants(WebDriver driver) {
		this.driver = driver;
		PageFactory.initElements(driver, this);
	}
	
	@FindBy(how = How.XPATH, using = "(//span[@class='breadcrumbs-list-item__text'])[1]")
	public static WebElement breadcrumbs;
	
	@FindBy(how = How.XPATH, using = "(//div[contains(@class,'current-country')]//span)[2]")
	public static WebElement Current_selection;

	@FindBy(how = How.XPATH, using = "//span[contains(@class,'global-country-label')]")
	public static WebElement Global_English;
	
	@FindBy(how = How.XPATH, using = "(//img[contains(@src,'/europe')]//following::span[contains(@class,'region-item-title')])[1]")
	public static WebElement Europe_region;
		
	@FindBy(how = How.XPATH, using = "(//img[contains(@src,'/north_america')]//following::span[contains(@class,'region-item-title')])[1]")
	public static WebElement NAmerica_region;
	
	@FindBy(how = How.XPATH, using = "(//img[contains(@src,'/south_america')]//following::span[contains(@class,'region-item-title')])[1]")
	public static WebElement SAmerica_region;
	
	@FindBy(how = How.XPATH, using = "(//img[contains(@src,'/africa')]//following::span[contains(@class,'region-item-title')])[1]")
	public static WebElement Africa_region;
	
	@FindBy(how = How.XPATH, using = "(//img[contains(@src,'/asia')]//following::span[contains(@class,'region-item-title')])[1]")
	public static WebElement Asia_region;
	
	@FindBy(how = How.XPATH, using = "(//img[contains(@src,'/russian')]//following::span[contains(@class,'region-item-title')])[1]")
	public static WebElement Russian_region;
	
	@FindBy(how = How.XPATH, using = "(//a[contains(text(),'United States of America')])")
	public static WebElement USA;
	
	@FindBy(how = How.XPATH, using = "(//a[contains(text(),'India')])")
	public static WebElement India;
	
	@FindBy(how = How.XPATH, using = "(//a[@class='country-item__link'])[2]")
	public static WebElement china;
	
	@FindBy(how = How.XPATH, using = "//div[@aria-label='Canada']//child::a")
	public static WebElement Canada;
	
	@FindBy(how = How.XPATH, using = "//div[@aria-label='United Kingdom']//child::a")
	public static WebElement UK;
	
	@FindBy(how = How.XPATH, using = "//div[@aria-label='France']//child::a")
	public static WebElement France;
	
	@FindBy(how = How.XPATH, using = "//a[contains(text(),'Ukraine (Ukrainian)')]")
	public static WebElement Ukraine;
	
	@FindBy(how = How.XPATH, using = "//div[@aria-label='Taiwan, China']//child::a")
	public static WebElement Taiwan;
	
	@FindBy(how = How.XPATH, using = "//div[@aria-label='Australia']//child::a")
	public static WebElement Australia;
	
	@FindBy(how = How.XPATH, using = "//div[@class='country-list-wrapper']")
	public static WebElement country_section;
	
	@FindBy(how = How.XPATH, using = "//a[@class='country-item__link']")
	public static WebElement country_list;

	
	
}
