package test.automation.pagelocators;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;

public class ContactusPageConstants {

	public WebDriver driver;

	public ContactusPageConstants(WebDriver driver) {
		this.driver = driver;
		PageFactory.initElements(driver, this);
	}
	
	@FindBy(how = How.XPATH, using = "//a[contains(@href,'factory')]//child::span[@class='item-caption']")
	public static WebElement Danfoss_factories;

	@FindBy(how = How.XPATH, using = "//a[contains(@href,'hq')]//child::span[@class='item-caption']")
	public static WebElement Danfoss_headquarters;
	@FindBy(how = How.XPATH, using = "(//div[contains(@class,'spot spot-singlelink')])[1]")
	//@FindBy(how = How.XPATH, using = "//a[contains(@href,'sales-service')]//child::span[@class='item-caption']")
	public static WebElement Danfoss_sales_services;

	@FindBy(how = How.XPATH, using = "(//a[contains(@href,'sales-service-center')]//span[@class='link-block'])[1]")
	public static WebElement Danfoss_sales_services_tile;

	@FindBy(how = How.XPATH, using = "(//a[contains(@href,'sales-service-center')]//span[@class='link-block'])[2]")
	public static WebElement Danfoss_Customer_service_center_tile;

	@FindBy(how = How.XPATH, using = "(//a[contains(@href,'service-partner')]//span[@class='link-block'])[1]")
	public static WebElement Danfoss_Distributors_service_partners_tile;

	@FindBy(how = How.XPATH, using = "(//div[contains(@class,'spot spot-singlelink')])[3]")
	//@FindBy(how = How.XPATH, using = "(//a[contains(@href,'/contact-us/contacts-list/')]//child::span[@class='item-caption'])[4]")
	public static WebElement Distributors;
	
	@FindBy(how = How.XPATH, using = "//img[contains(@src,'/media/fw5czu1h/distributors-ss1945899484.jpg?anchor=center&mode=crop&width=410')]")
	public static WebElement LookingForDistributors;
	
	@FindBy(how = How.XPATH, using = "((//a[contains(@href,'zh-cn/contact-us/contacts-list/?filter=type%3Adistributor')])//parent::div)[1]")
	public static WebElement Distributors_zh_cn;

	@FindBy(how = How.XPATH, using = "(//div[contains(@class,'spot-singlelink')])[1]")
	public static WebElement sales_service_zh_cn;

	@FindBy(how = How.XPATH, using = "//a[contains(@href,'service-partner')]//child::span[@class='item-caption']")
	public static WebElement Service_partners;

	@FindBy(how = How.XPATH, using = "//button[contains(@class,'angleButton')]")
	public static WebElement close_button;

	@FindBy(how = How.XPATH, using = "(//a[contains(@class,'overviewLink')]//child::span)[1]")
	public static WebElement overview_link;

	@FindBy(how = How.XPATH, using = "(//span[@class='breadcrumbs-list-item__text'])[1]")
	public static WebElement breadcrumbs_homepage;

	@FindBy(how = How.XPATH, using = "(//span[@class='breadcrumbs-list-item__text'])[2]")
	public static WebElement breadcrumbs_contactus;

	@FindBy(how = How.XPATH, using = "//h1[contains(@class,'description-section__heading page-heading')]")
	public static WebElement Static_description;

	@FindBy(how = How.XPATH, using = "//div[@class='contacts-list-desktop-filters']")
	public static WebElement filter_section;

	@FindBy(how = How.XPATH, using = "//div[@class='dropdown-multi-values__value-container dropdown-multi-values__value-container--is-multi css-1hwfws3']")
	public static WebElement Business_unit_filter;
	@FindBy(how = How.XPATH, using = "(//span[contains(text(),'Business')]//following::span[contains(@class,'down-small')])[1]")
	public static WebElement Business_unit_filter2;

	@FindBy(how = How.XPATH, using = "(//span[@class='icon icon-chevron-down-small'])[1]")
	public static WebElement Business_unit_filter_arrow;

	//(//div[contains(@class,'contacts-list-desktop-filters')]//descendant::div[contains(@class,'dropdown-multi-values__placeholder')])[1]
	
	@FindBy(how = How.XPATH, using = "//div[contains(text(),'Type')]")//(//span[contains(text(),'Type')])[4]
	public static WebElement contact_type_fiter;
	
	@FindBy(how = How.XPATH, using = "//div[@class='dropdown-multiple-values  has-selected-value css-2b097c-container']")//(//div[@class='dropdown-multi-values__control css-q7irpc-control']/div)[3]
	public static WebElement contact_type_fiter_with_Values; 
	
	@FindBy(how = How.XPATH, using = "(//div[@class='dropdown-multi-values__control css-q7irpc-control'])[1]")
	public static WebElement Business_unit_filter_with_Values;
	
	@FindBy(how = How.XPATH, using = "(//div[contains(@class,'contacts-list-desktop')]//span[contains(@class,'icon icon-chevron-down-small')])[2]")
	public static WebElement contact_type_fiter1;
	//(((//div[contains(@class,'contacts-list-desktop-filters')])[3])//descendant::div[contains(@class,'dropdown-multi-values')])[3]
	@FindBy(how = How.XPATH, using = "//div[contains(@class,'contacts-list-desktop-container ')]")
	public static WebElement contact_list_section;

	@FindBy(how = How.XPATH, using = "(//*[contains(text(),'Type')])//following::span[contains(@class,'down-small')][2]")
	public static WebElement contact_list_filter_arrow;

	@FindBy(how = How.XPATH, using = "//label//ancestor::div[contains(@class,'is-disabled')]")
	public static WebElement disabled_filter_option;


	@FindBy(how = How.XPATH, using = "(//div[contains(text(),'Business')]//following::span[contains(@class,'down-small')])[1]")
	public static WebElement Business_filter_arrow;
	
	@FindBy(how = How.XPATH, using = "(//span[contains(text(),'Business')]//following::span[contains(@class,'down-small')])[1]")
	public static WebElement Business_filter_arrow_2;
	

	@FindBy(how = How.XPATH, using = "(//div[contains(@class,'dropdown-multi-values__menu')]//descendant::label)[1]")
	public static WebElement contact_type_reset;

	@FindBy(how = How.XPATH, using = "(//*[contains(text(),'Business unit')]//following::label)[1]")
	public static WebElement Business_filter_reset;

	@FindBy(how = How.XPATH, using = "//div[contains(@class,'option--is-selected')]")
	public static WebElement Selected_value;

	@FindBy(how = How.XPATH, using = "//div[@class='contacts-list-map ']")
	public static WebElement google_map;

	@FindBy(how = How.XPATH, using = "//input[@placeholder='Enter location']")
	public static WebElement Location_inputbox;

	@FindBy(how = How.XPATH, using = "//input[@class='location-finder__input']")
	public static WebElement Location_inputbox_zh_cn;

	@FindBy(how = How.XPATH, using = "//input[@placeholder='Enter location']//child::*")
	public static WebElement Location_inputbox_autosuggestion;

	@FindBy(how = How.XPATH, using = "(//span[@class='multiselect-option-checkbox'])[1]")
	public static WebElement Multiple_selection;

	@FindBy(how = How.XPATH, using = "//span[contains(@class,'multiselect-dropdown-value')]")
	public static WebElement contact_type_selected_filter;

	@FindBy(how = How.XPATH, using = "(//img[contains(@src,'maps.googleapis')])[1]")
	public static WebElement Google_map_api;

	@FindBy(how = How.XPATH, using = "//div[@id='baidu-map']")
	public static WebElement Baidu_map;

	@FindBy(how = How.XPATH, using = "//img[contains(@src,'maps.gstatic')]")//img[contains(@src,'/google-pin')]
	public static WebElement Google_map_pins;

	@FindBy(how = How.XPATH, using = "(//div[contains(@class,'contacts-list-map ')]//descendant::span[@aria-hidden='true'])")
	public static WebElement Consolidated_pin_map;

	@FindBy(how = How.XPATH, using = "//button[@title='Zoom in']")
	public static WebElement Map_zoomin;

	@FindBy(how = How.XPATH, using = "//button[@title='Zoom out']")
	public static WebElement Map_zoomout;

	@FindBy(how = How.XPATH, using = "//div[@class='contact']")
	public static WebElement contact_list;

	@FindBy(how = How.XPATH, using = "(//span[contains(text(),'View details')])[1]")//(//div[@class='contact']//child::span[@class='cta-content-text'])[1]
	public static WebElement View_details;
	
	@FindBy(how = How.XPATH, using = "//div[text()='Danfoss Industries Pvt. Ltd.']//following-sibling::button//span[contains(text(),'View details')]")//(//div[@class='contact']//child::span[@class='cta-content-text'])[1]
	public static WebElement View_details2;
	
	@FindBy(how = How.XPATH, using = "(//div[@class='contact']//child::span[@class='cta-content-text'])[3]")
	public static WebElement View_details_CNN; //(//span[contains(text(),'View details')])[3]
	
	
	@FindBy(how = How.XPATH, using = "(//div[@class='contact__distance'])[1]")
	public static WebElement contact_Distance;

	@FindBy(how = How.XPATH, using = "(//div[@class='contact__type'])[1]")
	public static WebElement contact_type;

	@FindBy(how = How.XPATH, using = "(//div[@class='contact__company-name'])[1]")
	public static WebElement contact_name;

	@FindBy(how = How.XPATH, using = "//div[@class='contact-details__company-name']")
	public static WebElement contact_name_detailview;

	@FindBy(how = How.XPATH, using = "//table[contains(@class,'contact-details__table')]")
	public static WebElement contact_detailview_attributelist;

	@FindBy(how = How.XPATH, using = "//span[contains(@class,'contact-details__read-more-label')]")
	public static WebElement contact_detail_view_showmore;

	@FindBy(how = How.XPATH, using = "//span[contains(@class,'contact-details__read-less-label')]")
	public static WebElement contact_detail_view_showless;

	@FindBy(how = How.XPATH, using = "(//td[contains(@class,'contact-details__value-cell')])[2]")
	public static WebElement contact_detailview_contacttype;

	@FindBy(how = How.XPATH, using = "(//div[@class='contact-details '])[1]")
	public static WebElement contact_details_view;

	@FindBy(how = How.XPATH, using = "//button[contains(@class,'contact-details')]//span[contains(@class,'icon-cancel')]")
	public static WebElement contact_details_view_close;

	@FindBy(how = How.XPATH, using = "(//td[contains(@class,'contact-details__value-cell')])[1]")
	public static WebElement contact_details_view_distance;

	@FindBy(how = How.XPATH, using = "(//td[contains(@class,'contact-details__value-cell')])[3]")
	public static WebElement contact_details_view_Bunit;

	@FindBy(how = How.XPATH, using = "//td[contains(@class,'contact-details__key-cell')]")
	public static WebElement contact_details_key_cell;

	@FindBy(how = How.XPATH, using = "//td[contains(@class,'contact-details__value-cell')]")
	public static WebElement contact_details_value_cell;

	@FindBy(how = How.XPATH, using = "//button[contains(@class,'contact-details__contact-form')]//span[contains(@class,'cta-content-text')]")
	public static WebElement contact_Us_form;

	@FindBy(how = How.XPATH, using = "(//img[contains(@style,'height: 42px;')])[1]")//
	public static WebElement Highlighted_pin;

	@FindBy(how = How.XPATH, using = "//a[contains(@href,'tel:')]")
	public static WebElement Contact_Telephone_numbers;

	@FindBy(how = How.XPATH, using = "//td//child::a[contains(@href,'https://www')]")
	public static WebElement Contact_Website;

	//form

	@FindBy(how = How.XPATH, using = "//div[@id='popup-content']") 
	public static WebElement Contact_form_popup; //div[@class='modal-content']

	@FindBy(how = How.XPATH, using = "//div[contains(@aria-label,'Contact form')]//button[contains(@aria-label,'close button')]")
	public static WebElement Contact_form_close;

	@FindBy(how = How.NAME, using = "//iframe[@id='_hjRemoteVarsFrame']")
	public static WebElement Contact_form_iframe;
	
	@FindBy(how = How.XPATH, using = "//p[contains(text(),'distributor')]")
	public static WebElement Contact_form_pp_distributor;
	@FindBy(how = How.XPATH, using = "//div[contains(@class,'consent-field-wrapper')]//child::label[text()='Understood']")
	public static WebElement Contact_form_distributor_consent;

	@FindBy(how = How.XPATH, using = "//p[contains(text(),'distributor')]")
	public static WebElement Contact_form_pp_distributordps;
	@FindBy(how = How.XPATH, using = "//div[contains(@class,'consent-field-wrapper')]//child::label[contains(text(),'I give my consent to Danfoss')]")
	public static WebElement Contact_form_distributordps_consent;

	@FindBy(how = How.XPATH, using = "//label[contains(text(),'Please select a reason')]")
	public static WebElement Contact_form_servicecloud_selectreason;
	@FindBy(how = How.XPATH, using = "//label[contains(text(),'Please select a sub-reason')]")
	public static WebElement Contact_form_servicecloud_selectsubreason;

	@FindBy(how = How.XPATH, using = "(//label[text()='Please select a reason']//following::div[contains(@class,'fs-info-icon infoIcon')])[1]")
	public static WebElement Contact_form_servicecloud_selectreason_tooltip;
	@FindBy(how = How.XPATH, using = "//label[text()='Please select a sub-reason']/span[2]")
	public static WebElement Contact_form_servicecloud_selectsubreason_tooltip;
	@FindBy(how = How.XPATH, using = "//label[text()='Please select a reason']//child::span[text()=' *']")
	public static WebElement C_F_SC_selectreason_req;
	@FindBy(how = How.XPATH, using = "//label[text()='Please select a sub-reason']//child::span[text()=' *']")
	public static WebElement C_F_SC_selectsubreason_req;
	
	@FindBy(how = How.XPATH, using = "(//label[text()='Please select a sub-reason']//following::span[contains(@class,'fs-field-error-message')])[1]")
	public static WebElement C_F_SC_selectsubreason_error_msg;

	@FindBy(how = How.XPATH, using = "(//label[text()='Please select a reason']//following::select//following::label)[1]")
	public static WebElement C_F_select_reason_dd;
	@FindBy(how = How.XPATH, using = "(//label[text()='Please select a sub-reason']//following::select//following::label)[1]")
	public static WebElement C_F_select_subreason_dd;
	@FindBy(how = How.XPATH, using = "//p[contains(text(),'Please read our ')]")
	public static WebElement Contact_form_pp_servicecloud;
	@FindBy(how = How.XPATH, using = "//div[contains(@class,'consent-field-wrapper')]//child::label[text()='I have read, understood and consent to the Danfoss privacy policy.']")
	public static WebElement Contact_form_servicecloud_consent;

	@FindBy(how = How.XPATH, using = "//p[contains(text(),'Please read our ')]")
	public static WebElement Contact_form_pp_pardot;
	@FindBy(how = How.XPATH, using = "//div[contains(@class,'consent-field-wrapper')]//child::label[text()='I have read, understood and consent to the Danfoss privacy policy.']")
	public static WebElement Contact_form_pardot_consent;

	/////form fields
	@FindBy(how = How.XPATH, using = "//label[text()='First name']")
	public static WebElement C_F_first_name;
	@FindBy(how = How.XPATH, using = "//label[text()='First name']//child::span[text()=' *']")
	public static WebElement C_F_first_name_req;
	@FindBy(how = How.XPATH, using = "//label[text()='First name']//following::input[1]")
	public static WebElement C_F_first_name_txtbx;
	@FindBy(how = How.XPATH, using = "(//label[text()='First name']//following::div[contains(@class,'fs-info-icon infoIcon')])[1]")
	public static WebElement C_F_first_name_tooltip_icon;
	@FindBy(how = How.XPATH, using = "//label[text()='First name']//descendant::span[contains(@class,'fs-screen-reader')]")
	public static WebElement C_F_first_name_tooltip;
	@FindBy(how = How.XPATH, using = "(//label[text()='First name']//following::span[contains(@class,'fs-field-error-message')])[1]")
	public static WebElement C_F_first_error_msg;



	@FindBy(how = How.XPATH, using = "//label[text()='Last name']")
	public static WebElement C_F_last_name;
	@FindBy(how = How.XPATH, using = "//label[text()='Last name']//child::span[text()=' *']")
	public static WebElement C_F_last_name_req;
	@FindBy(how = How.XPATH, using = "//label[text()='Last name']//following::input[1]")
	public static WebElement C_F_last_name_txtbx;
	@FindBy(how = How.XPATH, using = "(//label[text()='Last name']//following::div[contains(@class,'fs-info-icon infoIcon')])[1]")
	public static WebElement C_F_last_name_tooltip_icon;
	@FindBy(how = How.XPATH, using = "//label[text()='Last name']//descendant::span[contains(@class,'fs-screen-reader')]")
	public static WebElement C_F_last_name_tooltip;
	@FindBy(how = How.XPATH, using = "(//label[text()='Last name']//following::span[contains(@class,'fs-field-error-message')])[1]")
	public static WebElement C_F_last_error_msg;



	@FindBy(how = How.XPATH, using = "//label[text()='Email']")
	public static WebElement C_F_Email;
	@FindBy(how = How.XPATH, using = "//label[text()='Email']//child::span[text()=' *']")
	public static WebElement C_F_Email_req;
	@FindBy(how = How.XPATH, using = "//label[text()='Email']//following::input[1]")
	public static WebElement C_F_Email_txtbx;
	@FindBy(how = How.XPATH, using = "(//label[text()='Email']//following::div[contains(@class,'fs-info-icon infoIcon')])[1]")
	public static WebElement C_F_Email_tooltip_icon;
	@FindBy(how = How.XPATH, using = "//label[text()='Email']//descendant::span[contains(@class,'fs-screen-reader')]")
	public static WebElement C_F_Email_tooltip;
	@FindBy(how = How.XPATH, using = "(//label[text()='Email']//following::span[contains(@class,'fs-field-error-message')])[1]")
	public static WebElement C_F_Email_error_msg;
	
	@FindBy(how = How.XPATH, using = "//label[text()='Phone']")
	public static WebElement C_F_Phone;
	@FindBy(how = How.XPATH, using = "//label[text()='Phone']//child::span[text()=' *']")
	public static WebElement C_F_Phone_req;
	@FindBy(how = How.XPATH, using = "//label[text()='Phone']//following::input[1]")
	public static WebElement C_F_Phone_txtbx;
	@FindBy(how = How.XPATH, using = "(//label[text()='Phone']//following::div[contains(@class,'fs-info-icon infoIcon')])[1]")
	public static WebElement C_F_Phone_tooltip_icon;
	@FindBy(how = How.XPATH, using = "//label[text()='Phone']//descendant::span[contains(@class,'fs-screen-reader')]")
	public static WebElement C_F_Phone_tooltip;
	@FindBy(how = How.XPATH, using = "(//label[text()='Phone']//following::span[contains(@class,'fs-field-error-message')])[1]")
	public static WebElement C_F_Phone_error_msg;


	@FindBy(how = How.XPATH, using = "//label[text()='Company']")
	public static WebElement C_F_Company;
	@FindBy(how = How.XPATH, using = "//label[text()='Company']//child::span[text()=' *']")
	public static WebElement C_F_Company_req;
	@FindBy(how = How.XPATH, using = "//label[text()='Company']//following::input[1]")
	public static WebElement C_F_Company_textbx;
	@FindBy(how = How.XPATH, using = "(//label[text()='Company']//following::div[contains(@class,'fs-info-icon infoIcon')])[1]")
	public static WebElement C_F_Company_tooltip_icon;
	@FindBy(how = How.XPATH, using = "//label[text()='Company']//descendant::span[contains(@class,'fs-screen-reader')]")
	public static WebElement C_F_Company_tooltip;
	@FindBy(how = How.XPATH, using = "(//label[text()='Company']//following::span[contains(@class,'fs-field-error-message')])[1]")
	public static WebElement C_F_Company_error_msg;


	@FindBy(how = How.XPATH, using = "//label[text()='Country/region']")
	public static WebElement C_F_Country_region;
	@FindBy(how = How.XPATH, using = "//label[text()='Country/region']//child::span[text()=' *']")
	public static WebElement C_F_Country_region_req;
	@FindBy(how = How.XPATH, using = "//select[@name='Country']//child::option[text()='Choose country/region']")
	public static WebElement C_F_Country_region_dd;
	@FindBy(how = How.XPATH, using = "(//label[text()='Country/region']//following::div[contains(@class,'fs-info-icon infoIcon')])[1]")
	public static WebElement C_F_Country_tooltip_icon;
	@FindBy(how = How.XPATH, using = "//label[text()='Country/region']//descendant::span[contains(@class,'fs-screen-reader')]")
	public static WebElement C_F_Country_tooltip;
	@FindBy(how = How.XPATH, using = "(//label[text()='Country/region']//following::span[contains(@class,'fs-field-error-message')])[1]")
	public static WebElement C_F_Country_error_msg;


	@FindBy(how = How.XPATH, using = "//label[text()='State/province']")
	public static WebElement C_F_State_province;
	@FindBy(how = How.XPATH, using = "//select[@name='State / Province']//child::option[text()='Choose state']")
	public static WebElement C_F_state_province_dd;

	@FindBy(how = How.XPATH, using = "//label[text()='Zip code']")
	public static WebElement C_F_Zip_code;
	@FindBy(how = How.XPATH, using = "//label[text()='Zip code']//child::span[text()=' *']")
	public static WebElement C_F_Zip_code_req;
	@FindBy(how = How.XPATH, using = "//label[text()='Zip code']//following::input[1]")
	public static WebElement C_F_Zipcode_textbx;
	@FindBy(how = How.XPATH, using = "(//label[text()='Zip code']//following::div[contains(@class,'fs-info-icon infoIcon')])[1]")
	public static WebElement C_F_Zip_code_tooltip_icon;
	@FindBy(how = How.XPATH, using = "//label[text()='Zip code']//descendant::span[contains(@class,'fs-screen-reader')]")
	public static WebElement C_F_Zip_code_tooltip;
	@FindBy(how = How.XPATH, using = "(//label[text()='Zip code']//following::span[contains(@class,'fs-field-error-message')])[1]")
	public static WebElement C_F_Zip_code_error_msg;

	@FindBy(how = How.XPATH, using = "//label[text()='City']")
	public static WebElement C_F_City;
	@FindBy(how = How.XPATH, using = "//label[text()='City']//child::span[text()=' *']")
	public static WebElement C_F_City_req;
	@FindBy(how = How.XPATH, using = "//label[text()='City']//following::input[1]")
	public static WebElement C_F_City_textbx;
	@FindBy(how = How.XPATH, using = "(//label[text()='City']//following::div[contains(@class,'fs-info-icon infoIcon')])[1]")
	public static WebElement C_F_City_tooltip_icon;
	@FindBy(how = How.XPATH, using = "//label[text()='City']//descendant::span[contains(@class,'fs-screen-reader')]")
	public static WebElement C_F_City_tooltip;
	@FindBy(how = How.XPATH, using = "(//label[text()='City']//following::span[contains(@class,'fs-field-error-message')])[1]")
	public static WebElement C_F_City_error_msg;

	@FindBy(how = How.XPATH, using = "//label[text()='Address']")
	public static WebElement C_F_Address;
	@FindBy(how = How.XPATH, using = "//label[text()='Address']//child::span[text()=' *']")
	public static WebElement C_F_Address_req;
	@FindBy(how = How.XPATH, using = "//label[text()='Address']//following::input[1]")
	public static WebElement C_F_Address_textbx;
	@FindBy(how = How.XPATH, using = "(//label[text()='Address']//following::div[contains(@class,'fs-info-icon infoIcon')])[1]")
	public static WebElement C_F_Address_tooltip_icon;
	@FindBy(how = How.XPATH, using = "//label[text()='Address']//descendant::span[contains(@class,'fs-screen-reader')]")
	public static WebElement C_F_Address_tooltip;
	@FindBy(how = How.XPATH, using = "(//label[text()='Address']//following::span[contains(@class,'fs-field-error-message')])[1]")
	public static WebElement C_F_Address_error_msg;

	@FindBy(how = How.XPATH, using = "//label[text()='Message']")
	public static WebElement C_F_Message;
	@FindBy(how = How.XPATH, using = "//label[text()='Message']//child::span[text()=' *']")
	public static WebElement C_F_Message_req;
	@FindBy(how = How.XPATH, using = "//label[text()='Message']//following::textarea[1]")
	public static WebElement C_F_Message_textbx;
	@FindBy(how = How.XPATH, using = "(//label[text()='Message']//following::div[contains(@class,'fs-info-icon infoIcon')])[1]")
	public static WebElement C_F_Message_tooltip_icon;
	@FindBy(how = How.XPATH, using = "//label[text()='Message']//descendant::span[contains(@class,'fs-screen-reader')]")
	public static WebElement C_F_Message_tooltip;
	@FindBy(how = How.XPATH, using = "(//label[text()='Message']//following::span[contains(@class,'fs-field-error-message')])[1]")
	public static WebElement C_F_Message_error_msg;


	@FindBy(how = How.XPATH, using = "//div[contains(@class,'fs-text-wrapper wrapper')]//child::p")
	public static WebElement C_F_consent;

	@FindBy(how = How.XPATH, using = "//label[text()='Understood']")
	public static WebElement C_F_Understand;

	@FindBy(how = How.XPATH, using = "//label[text()='I have read and understood how Danfoss is saving and processing my data.']")
	public static WebElement C_F_Understand_DPS;
	//label[text()='I give my consent to Danfoss saving and processing my personal data as stated above.']
	
	@FindBy(how = How.XPATH, using = "//label[text()='I have read, understood and consent to the Danfoss privacy policy.']")
	public static WebElement C_F_Understand_SC;
	@FindBy(how = How.XPATH, using = "//label[text()='I have read and understood the Danfoss privacy policy.']")
	public static WebElement C_F_Understand_PD;
	@FindBy(how = How.XPATH, using = "//label[text()='Understood']//preceding-sibling::span[contains(@class,'checkbox-control')]")
	public static WebElement C_F_Understand_chkbx;
	@FindBy(how = How.XPATH, using = "//label[text()='I have read and understood how Danfoss is saving and processing my data.']//preceding-sibling::span[contains(@class,'checkbox-control')]")
	public static WebElement C_F_Understand_chkbx_dps;

	@FindBy(how = How.XPATH, using = "//label[text()='I have read, understood and consent to the Danfoss privacy policy.']//preceding-sibling::span[contains(@class,'checkbox-control')]")
	public static WebElement C_F_Understand_chkbx_SC;
	@FindBy(how = How.XPATH, using = "//label[text()='I have read and understood the Danfoss privacy policy.']//preceding-sibling::span[contains(@class,'checkbox-control')]")
	public static WebElement C_F_Understand_chkbx_PD;
	@FindBy(how = How.XPATH, using = "//label[text()='Understood']//following::div[contains(@class,'fs-field-error-message')]")
	public static WebElement C_F_Understand_error_msg;
	@FindBy(how = How.XPATH, using = "//label[text()='I have read and understood how Danfoss is saving and processing my data.']//following::div[contains(@class,'fs-field-error-message')]")
	public static WebElement C_F_Understand_Dps_error_msg;
	@FindBy(how = How.XPATH, using = "//label[text()='I have read, understood and consent to the Danfoss privacy policy.']//following::div[contains(@class,'fs-field-error-message')]")
	public static WebElement C_F_Understand_SC_error_msg;
	@FindBy(how = How.XPATH, using = "//label[text()='I have read and understood the Danfoss privacy policy.']//following::div[contains(@class,'fs-field-error-message')]")
	public static WebElement C_F_Understand_PD_error_msg;


	@FindBy(how = How.XPATH, using = "//span[contains(@class,'fs-submit-button-text')]")
	public static WebElement C_F_Submit_button;
	@FindBy(how = How.XPATH, using = "//div[@class='popup-header']/button[contains(@class,'closeButton__3Lij_ close animatedCloseButton__AV-vN')]")
	public static WebElement C_F_Close_button;
	
	
	@FindBy(how = How.XPATH, using = "//button[@aria-hidden='true'][@type='submit']")
	public static WebElement C_F_Submit_button_disabled;
	@FindBy(how = How.XPATH, using = "//div[@class='grecaptcha-logo']")
	public static WebElement C_F_Recaptcha;
	
	@FindBy(how = How.XPATH, using = "//select[@class='select-1-3-6']")
	public static WebElement choose_Reason;
	


}

