package test.automation.pagelocators;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;

public class Loginconstants {

	public WebDriver driver;

	public Loginconstants(WebDriver driver) {
		this.driver = driver;
		PageFactory.initElements(driver, this);
	}
	
//**************************************************************WebElements*******************************************************************************
	
	//login Webelements
	@FindBy(xpath = "//button[contains(text(),'Advanced')]")
	public static WebElement advanceXpath;
	@FindBy(xpath = "//input[@id='tokenInput']")
	public static WebElement tokenInput;
	@FindBy(xpath = "//a[@id='proceed-link']")
	public static WebElement proceedlink;
	@FindBy(how = How.XPATH, using = "//button[@onclick='login()']")
	public static WebElement loginClick;
	@FindBy(how = How.XPATH, using = "//button[@onclick='applyAccessToken()']")
	public static WebElement accessLoginButton;
	@FindBy(how = How.XPATH, using = "//input[@name='username']")
	public static WebElement username;
	@FindBy(how = How.XPATH, using = "//form[@name='loginForm']/div/input[@placeholder='Enter your password']")
	public static WebElement password;
	@FindBy(how = How.XPATH, using = "//button[@title='Log in using your Active Directory account']")
	public static WebElement loginButton;
	@FindBy(how = How.XPATH, using = "//input[@name='loginfmt' and @type='email']")
	public static WebElement microsoftLogin;
	@FindBy(how = How.XPATH, using = "//input[@type='submit']")
	public static WebElement microsoftSignIn;
	@FindBy(how = How.XPATH, using = "//input[@name='passwd' and @type='password']")
	public static WebElement microsoftPassword;
	@FindBy(how = How.XPATH, using = "//button[@class='coi-accept-btn']")
	public static WebElement acceptcookies;

	//valid token for login
	public final static String loginToken ="Beu66sob7AX5JwmmNM7iT8p8eOEtXp2gKqKn8AUcwRcXc";
	
	
	//UMBRACO
	@FindBy(how = How.XPATH, using = "//button[@class='btn btn-block btn-social btn-microsoft']")
	public static WebElement signIn;
	@FindBy(how = How.XPATH, using = "//input[@id='umb-username']")
	public static WebElement Umb_Username;
	@FindBy(how = How.XPATH, using = "//input[@id='umb-passwordTwo']")
	public static WebElement Umb_Password;
	@FindBy(how = How.XPATH, using = "//button[@class='btn umb-button__button btn-success umb-button--m umb-outline']")
	public static WebElement Umb_Login;
	
}
