package test.automation.pagelocators;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;

public class LoginPage {

	
	public WebDriver driver;

	public LoginPage(WebDriver driver) {
		this.driver = driver;
		PageFactory.initElements(driver, this);
	}
	
	@FindBy(xpath = "//button[contains(text(),'Advanced')]")
	public static WebElement advanceXpath;
	@FindBy(xpath = "//input[@id='tokenInput']")
	public static WebElement tokenInput;
	@FindBy(xpath = "//a[@id='proceed-link']")
	public static WebElement proceedlink;
	@FindBy(how = How.XPATH, using = "//button[@onclick='login()']")
	public static WebElement loginClick;
	@FindBy(how = How.XPATH, using = "//button[@onclick='applyAccessToken()']")
	public static WebElement accessLoginButton;
	@FindBy(how = How.XPATH, using = "//input[@name='username']")
	public static WebElement username;
	@FindBy(how = How.XPATH, using = "//form[@name='loginForm']/div/input[@placeholder='Enter your password']")
	public static WebElement password;
	@FindBy(how = How.XPATH, using = "//button[@title='Log in using your Active Directory account']")
	public static WebElement loginButton;
	@FindBy(how = How.XPATH, using = "//input[@name='loginfmt' and @type='email']")
	public static WebElement microsoftLogin;
	@FindBy(how = How.XPATH, using = "//input[@type='submit']")
	public static WebElement microsoftSignIn;
	@FindBy(how = How.XPATH, using = "//input[@name='passwd' and @type='password']")
	public static WebElement microsoftPassword;
	@FindBy(how = How.XPATH, using = "//button[@class='coi-accept-btn']")
	public static WebElement acceptcookies;

	public static WebElement AdvanceXpath() {
		return advanceXpath;
	}
	public static WebElement TokenInput() {
		return tokenInput;
	}
	public static WebElement ProceedLink() {
		return proceedlink;
	}
	public static WebElement LoginClick() {
		return loginClick;
	}
	public static WebElement AccessLoginButton() {
		return accessLoginButton;
	}
	public static WebElement UserName() {
		return username;
	}
	public static WebElement Password() {
		return password;
	}
	public static WebElement LoginButton() {
		return loginButton;
	}
	public static WebElement MicrosoftLogin() {
		return microsoftLogin;
	}
	public static WebElement MicrosoftPassword() {
		return microsoftPassword;
	}
	public static WebElement AcceptCookies() {
		return acceptcookies;
	}
}
