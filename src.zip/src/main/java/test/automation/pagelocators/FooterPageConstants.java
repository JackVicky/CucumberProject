package test.automation.pagelocators;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;

public class FooterPageConstants {


	public WebDriver driver;

	public FooterPageConstants(WebDriver driver) {
		this.driver = driver;
		PageFactory.initElements(driver, this);
	}

	/********************** Follow our global channels****************************************************/


	@FindBy(how = How.XPATH, using = "//div[contains(@class,'social__links__title')]")
	public static WebElement Social_media_title;
	@FindBy(how = How.XPATH, using = "//button[contains(@class,'cta cta--small')]//preceding::div[contains(@class,'social__links col')]")
	public static WebElement Social_media_section;
	@FindBy(how = How.XPATH, using = "//a[contains(@href,'linkedin.com/company/danfoss')]")
	public static WebElement linkedin;
	@FindBy(how = How.XPATH, using = "(//a[contains(@href,'twitter.com')])[3]")//"//a[contains(@href,'twitter.com/Danfoss')]")
	public static WebElement twitter;
	@FindBy(how = How.XPATH, using = "//a[contains(@href,'facebook.com/danfoss')]")
	public static WebElement facebook;
	@FindBy(how = How.XPATH, using = "//a[contains(@href,'youtube.com/')]")
	public static WebElement youtube;

	@FindBy(how = How.XPATH, using = "//div[contains(@class,'newsletter-signup')]")
	public static WebElement Newsletter_signup;
	@FindBy(how = How.XPATH, using = "//div[contains(@class,'newsletter-signup')]//descendant::span[@class='cta-content-text']")
	public static WebElement Keep_me_updated;
	@FindBy(how = How.XPATH, using = "//div[contains(@class,'popup-content')]")
	public static WebElement Newsletter_form_popup;
	@FindBy(how = How.XPATH, using = "//h4[contains(@class,'popup-title')]")
	public static WebElement Newsletter_signup_title;
	@FindBy(how = How.XPATH, using = "//form")
	public static WebElement Newsletter_signup_form;
	

	/*////////////////////////////////FOOTER///////////////////////////////////////////////////////////////*/
	@FindBy(how = How.XPATH, using = "//div[@class='footer__primary']")
	public static WebElement Ftr_primary_footer;
	@FindBy(how = How.XPATH, using = "//div[@class='footer__secondary']")
	public static WebElement Ftr_secondary_footer;

	@FindBy(how = How.XPATH, using = "(//div[@class='footer__primary']//descendant::ul)[1]")
	public static WebElement Ftr_primary1_market_we_serve;
	@FindBy(how = How.XPATH, using = "(//div[@class='footer__primary']//descendant::ul)[2]")
	public static WebElement Ftr_primary2_service_support;
	@FindBy(how = How.XPATH, using = "(//div[@class='footer__primary']//descendant::ul)[3]")
	public static WebElement Ftr_primary3_our_businesses;
	@FindBy(how = How.XPATH, using = "(//div[@class='footer__primary']//descendant::ul)[4]")
	public static WebElement Ftr_primary4_about_danfoss;
	@FindBy(how = How.XPATH, using = "(//div[@class='footer__primary']//descendant::li[@class='primary__list-item primary__list-item--header'])//child::a[contains(@href,'/markets/')]")
	public static WebElement Ftr_Market_we_serve;
	@FindBy(how = How.XPATH, using = "(//div[@class='footer__primary']//descendant::li[@class='primary__list-item primary__list-item--header'])//child::a[contains(@href,'/service-and-support/')]")
	public static WebElement Ftr_Service_support;
	@FindBy(how = How.XPATH, using = "(//div[@class='footer__primary']//descendant::li[@class='primary__list-item primary__list-item--header'])//child::a[contains(@href,'/about-danfoss/our-business')]")
	public static WebElement Ftr_Our_Businesses;
	@FindBy(how = How.XPATH, using = "((//div[@class='footer__primary']//descendant::li[@class='primary__list-item primary__list-item--header'])//child::a[contains(@href,'/about-danfoss/')])[2]")
	public static WebElement Ftr_About_danfoss;

	/*#####################****************** Market we serve ************************###############************/
	@FindBy(how = How.XPATH, using = "(//div[@class='footer__primary']//descendant::a[contains(@href,'/markets/')])//following::a[contains(@href,'/markets/automotive/')]")
	public static WebElement Ftr_Automotive;
	@FindBy(how = How.XPATH, using = "(//div[@class='footer__primary']//descendant::a[contains(@href,'/markets/')])//following::a[contains(@href,'/markets/buildings-commercial/')]")
	public static WebElement Ftr_buildings_commercial;
	@FindBy(how = How.XPATH, using = "(//div[@class='footer__primary']//descendant::a[contains(@href,'/markets/')])//following::a[contains(@href,'/markets/buildings-residential/')]")
	public static WebElement Ftr_buildings_residential;
	@FindBy(how = How.XPATH, using = "(//div[@class='footer__primary']//descendant::a[contains(@href,'/markets/')])//following::a[contains(@href,'/markets/district-energy/')]")
	public static WebElement Ftr_district_energy;
	@FindBy(how = How.XPATH, using = "(//div[@class='footer__primary']//descendant::a[contains(@href,'/markets/')])//following::a[contains(@href,'/markets/energy-and-natural-resources/')]")
	public static WebElement Ftr_energy_and_natural;
	@FindBy(how = How.XPATH, using = "(//div[@class='footer__primary']//descendant::a[contains(@href,'/markets/')])//following::a[contains(@href,'/markets/food-and-beverage')]")
	public static WebElement Ftr_food_beverage;
	@FindBy(how = How.XPATH, using = "(//div[@class='footer__primary']//descendant::a[contains(@href,'/markets/')])//following::a[contains(@href,'/markets/industry')]")
	public static WebElement Ftr_industry;
	@FindBy(how = How.XPATH, using = "(//div[@class='footer__primary']//descendant::a[contains(@href,'/markets/')])//following::a[contains(@href,'/markets/marine-and-offshore')]")
	public static WebElement Ftr_marine_offshore;
	@FindBy(how = How.XPATH, using = "(//div[@class='footer__primary']//descendant::a[contains(@href,'/markets/')])//following::a[contains(@href,'/markets/mobile-hydraulics')]")
	public static WebElement Ftr_mobile_hydraulics;
	@FindBy(how = How.XPATH, using = "(//div[@class='footer__primary']//descendant::a[contains(@href,'/markets/')])//following::a[contains(@href,'/markets/refrigeration-and-air-conditioning')]")
	public static WebElement Ftr_refrigeration_airconditioning;
	@FindBy(how = How.XPATH, using = "(//div[@class='footer__primary']//descendant::a[contains(@href,'/markets/')])//following::a[contains(@href,'/markets/water-and-wastewater')]")
	public static WebElement Ftr_water_wastewater;

	/*#####################****************** service-and-support ************************###############************/
	@FindBy(how = How.XPATH, using = "(//div[@class='footer__primary']//descendant::li[@class='primary__list-item'])//child::a[contains(@href,'/service-and-support/documentation/')]")
	public static WebElement Ftr_documentation;
	@FindBy(how = How.XPATH, using = "(//div[@class='footer__primary']//descendant::li[@class='primary__list-item'])//child::a[contains(@href,'/service-and-support/downloads/')]")
	public static WebElement Ftr_downloads;
	@FindBy(how = How.XPATH, using = "(//div[@class='footer__primary']//descendant::li[@class='primary__list-item'])//child::a[contains(@href,'/service-and-support/case-stories/')]")
	public static WebElement Ftr_case_studies;
	@FindBy(how = How.XPATH, using = "(//div[@class='footer__primary']//descendant::li[@class='primary__list-item'])//child::a[contains(@href,'/service-and-support/fix-and-troubleshooting/')]")
	public static WebElement Ftr_fix_troubleshooting;
	@FindBy(how = How.XPATH, using = "(//div[@class='footer__primary']//descendant::li[@class='primary__list-item'])//child::a[contains(@href,'/contact-us/')]")
	public static WebElement Ftr_contact_us;
	@FindBy(how = How.XPATH, using = "(//div[@class='footer__primary']//descendant::li[@class='primary__list-item'])//child::a[contains(@href,'/service-and-support/learning/')]")
	public static WebElement Ftr_learning;

	/*#####################****************** Our-Businesses ************************###############************/
	
	@FindBy(how = How.XPATH, using = "(//div[@class='footer__primary']//descendant::li[@class='primary__list-item'])//child::a[contains(@href,'/about-danfoss/our-businesses/climate-solutions/')]")
	public static WebElement Ftr_climate_solution;
	@FindBy(how = How.XPATH, using = "(//div[@class='footer__primary']//descendant::li[@class='primary__list-item'])//child::a[contains(@href,'/about-danfoss/our-businesses/cooling/')]")
	public static WebElement Ftr_cooling;
	@FindBy(how = How.XPATH, using = "(//div[@class='footer__primary']//descendant::li[@class='primary__list-item'])//child::a[contains(@href,'/about-danfoss/our-businesses/drives/')]")
	public static WebElement Ftr_drives;
	@FindBy(how = How.XPATH, using = "//a[contains(text(),'Editron')]")
	public static WebElement Ftr_editron;
	@FindBy(how = How.XPATH, using = "//a[contains(text(),'Emission monitoring')]")
	public static WebElement Ftr_emission_monitoring;
	@FindBy(how = How.XPATH, using = "(//div[@class='footer__primary']//descendant::li[@class='primary__list-item'])//child::a[contains(@href,'/about-danfoss/our-businesses/fire-safety/')]")
	public static WebElement Ftr_fire_safety;
	@FindBy(how = How.XPATH, using = "(//div[@class='footer__primary']//descendant::li[@class='primary__list-item'])//child::a[contains(@href,'/about-danfoss/our-businesses/heating/')]")
	public static WebElement Ftr_heating;
	@FindBy(how = How.XPATH, using = "(//div[@class='footer__primary']//descendant::li[@class='primary__list-item'])//child::a[contains(@href,'/about-danfoss/our-businesses/high-pressure-pumps/')]")
	public static WebElement Ftr_high;
	@FindBy(how = How.XPATH, using = "(//div[@class='footer__primary']//descendant::li[@class='primary__list-item'])//child::a[contains(@href,'/about-danfoss/our-businesses/sensing-solutions/')]")
	public static WebElement Ftr_sensing_solutions;
	@FindBy(how = How.XPATH, using = "//div[@class='footer__primary']//descendant::a[contains(@href,'/about-danfoss/our-businesses/power-solutions/')]//following::a[contains(@href,'/about-danfoss/our-businesses/power-solutions/')]")
	public static WebElement Ftr_power_solutions;
	@FindBy(how = How.XPATH, using = "(//div[@class='footer__primary']//descendant::li[@class='primary__list-item'])//child::a[contains(@href,'/about-danfoss/our-businesses/silicon-power/')]")
	public static WebElement Ftr_silicon_power;
	@FindBy(how = How.XPATH, using = "(//div[@class='footer__primary']//descendant::li[@class='primary__list-item'])//child::a[contains(@href,'/about-danfoss/our-businesses/product-store/')]")
	public static WebElement Ftr_product_store;

	/*#####################******************* About Danfoss************************###############************/
	@FindBy(how = How.XPATH, using = "((//div[@class='footer__primary']//descendant::li[@class='primary__list-item'])//child::a[contains(@href,'/about-danfoss/company/')])[1]")
	public static WebElement Ftr_company;
	@FindBy(how = How.XPATH, using = "(//div[@class='footer__primary']//descendant::li[@class='primary__list-item'])//child::a[contains(@href,'/about-danfoss/news-and-events/')]")
	public static WebElement Ftr_news_events;
	@FindBy(how = How.XPATH, using = "//a[contains(text(),'Insights for tomorrow')]")
	public static WebElement Ftr_insights_tomorrow;
	@FindBy(how = How.XPATH, using = "(//div[@class='footer__primary']//descendant::li[@class='primary__list-item'])//child::a[contains(@href,'/about-danfoss/company/sustainability/')]")
	public static WebElement Ftr_sustainability;
	@FindBy(how = How.XPATH, using = "(//div[@class='footer__primary']//descendant::li[@class='primary__list-item'])//child::a[contains(@href,'/about-danfoss/company/financial-information/')]")
	public static WebElement Ftr_financials;
	@FindBy(how = How.XPATH, using = "(//div[@class='footer__primary']//descendant::li[@class='primary__list-item'])//child::a[contains(@href,'/about-danfoss/careers/')]")
	public static WebElement Ftr_careers;

	/*#####################******************* Secondary Footer ************************###############************/
	@FindBy(how = How.XPATH, using = "//div[@class='footer__secondary']//descendant::li[@class='secondary__list-item']//child::a[contains(@href,'/terms/privacy/')]")
	public static WebElement Ftr_privacy;
	@FindBy(how = How.XPATH, using = "(//div[@class='footer__secondary']//descendant::li[@class='secondary__list-item']//child::a[contains(@href,'/terms/')])[2]")
	public static WebElement Ftr_terms_use;
	@FindBy(how = How.XPATH, using = "//div[@class='footer__secondary']//descendant::li[@class='secondary__list-item']//child::a[contains(@href,'/terms/generalinformation/')]")
	public static WebElement Ftr_general_information;
	@FindBy(how = How.XPATH, using = "//div[@class='footer__secondary']//descendant::li[@class='secondary__list-item']//child::a[contains(@href,'javascript:CookieConsent.show()')]")
	public static WebElement Ftr_Cookie;
	@FindBy(how = How.XPATH, using = "//div[@class='footer__secondary']//descendant::div[@class='secondary__global']//child::a[contains(@href,'/choose-region')]")
	public static WebElement Ftr_choose_region;
	
	@FindBy(how = How.XPATH, using = "//span[contains(text(),'Terms of use')]")
	public static WebElement Ftr_terms_of_use;
	@FindBy(how = How.XPATH, using = "//li[@class='breadcrumbs-list-item ']")
	public static WebElement Ftr_terms_breadcrums;
	@FindBy(how = How.XPATH, using = "//div[@class='grid-danf-fe-rte rte-default col-sm-10 col-sm-offset-1 col-no-paddings']/p[1]")
	public static WebElement ftr_Terms_content;
	@FindBy(how = How.XPATH, using = "//div[@class='general-information-page']")
	public static WebElement contact_GeneralInfoPage;
	





}
