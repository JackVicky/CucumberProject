package test.automation.pagelocators;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;

public class Service_SupportConstants {
	
	public WebDriver driver;

	public Service_SupportConstants(WebDriver driver) {
		this.driver = driver;
		PageFactory.initElements(driver, this);
	}
	
	@FindBy(how = How.XPATH, using = "//span[text()='Documentation']")
	public static WebElement Documentation;
	
	@FindBy(how = How.XPATH, using = "//span[text()='Downloads']")
	public static WebElement Downloads;
	
	@FindBy(how = How.XPATH, using = "//span[text()='Case stories']")
	public static WebElement Case_studies;
	
	@FindBy(how = How.XPATH, using = "//span[text()='Fix and troubleshooting']")
	public static WebElement Fix_troubleshooting;
	
	@FindBy(how = How.XPATH, using = "//span[text()='Danfoss learning']")
	public static WebElement Danfoss_learning;
	
	@FindBy(how = How.XPATH, using = "//span[text()='Newsletter/coolselector']")
	public static WebElement Newsletter_coolselector;
	
	@FindBy(how = How.XPATH, using = "//span[text()='Media']")
	public static WebElement Media;
	
	@FindBy(how = How.XPATH, using = "//span[text()='Media with video']")
	public static WebElement Media_video;
	
	@FindBy(how = How.XPATH, using = "//span[text()='One slide media']")
	public static WebElement One_slide_media;
	
	@FindBy(how = How.XPATH, using = "//button[contains(@class,'angleButton')]")
	public static WebElement close_button;

	@FindBy(how = How.XPATH, using = "//a[contains(@class,'overviewLink')]")
	public static WebElement overview_link;
}
