package test.automation.pagelocators;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class Uniqueconstants {
	
	public WebDriver driver;

	public Uniqueconstants(WebDriver driver) {
		this.driver = driver;
		PageFactory.initElements(driver, this);
	}
	
//**************************************************************WebElements*******************************************************************************
	
	//Home Webelements-yet to devlop
	@FindBy(xpath = "//*[@class='error-code']")
	public static WebElement errorCode;
	@FindBy(xpath = "//*[@class= 'error-page']")
	public static WebElement errorPage;
	@FindBy(xpath = "//*[@class='error-messages']")
	public static WebElement errorMessages;


}
