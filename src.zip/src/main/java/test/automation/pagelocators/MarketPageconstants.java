package test.automation.pagelocators;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;

public class MarketPageconstants {

	public WebDriver driver;

	public MarketPageconstants(WebDriver driver) {
		this.driver = driver;
		PageFactory.initElements(driver, this);
	}
	
	@FindBy(how = How.XPATH, using = "//span[text()='Automotive']")
	public static WebElement Automotive;

	@FindBy(how = How.XPATH, using = "//span[text()='Buildings - commercial']")
	public static WebElement Buildings_commercial;

	@FindBy(how = How.XPATH, using = "//span[text()='Buildings – residential']")
	public static WebElement Buildings_residential;
	
	@FindBy(how = How.XPATH, using = "//span[text()='District energy']")
	public static WebElement District_energy;
	
	@FindBy(how = How.XPATH, using = "//span[text()='Energy and natural resources']")
	public static WebElement Energy_natural_resources;
		
	@FindBy(how = How.XPATH, using = "//span[text()='Food and beverage']")
	public static WebElement Food_beverage;
	
	@FindBy(how = How.XPATH, using = "//span[text()='Industry']")
	public static WebElement Industry;
	
	@FindBy(how = How.XPATH, using = "//span[text()='Mobile hydraulics']")
	public static WebElement Mobile_hydraulics;
	
	@FindBy(how = How.XPATH, using = "//span[text()='Refrigeration and air conditioning']")
	public static WebElement Refrigeration_airconditioning;
	
	@FindBy(how = How.XPATH, using = "//span[text()='Marine and offshore']")
	public static WebElement Marine_offshore;
	
	@FindBy(how = How.XPATH, using = "//span[text()='Water and wastewater']")
	public static WebElement Water_wastewater;
	
	@FindBy(how = How.XPATH, using = "//span[text()='All markets']")
	public static WebElement All_markets;
	
	@FindBy(how = How.XPATH, using = "//button[contains(@class,'angleButton')]")
	public static WebElement close_button;
}
