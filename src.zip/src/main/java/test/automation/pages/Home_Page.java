package test.automation.pages;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.Dimension;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebElement;

import org.openqa.selenium.support.PageFactory;

import com.aventstack.extentreports.Status;

import test.automation.globalfunctionality.TestCaseInitiator;
import test.automation.pagelocators.HomePageconstants;
import test.automation.pagelocators.ProductPageconstants;


public class Home_Page extends TestCaseInitiator{

	public Home_Page() {
		PageFactory.initElements(driver, HomePageconstants.class);
	}

	public Home_Page AcceptCookies() throws InterruptedException {
		
		  if(verifyElementDisplayedForEdge(HomePageconstants.acceptcookies)) {
		  clickWebElement(HomePageconstants.acceptcookies); } else
		  if(VerifyElementIsClickable(HomePageconstants.acceptcookies)){
		  clickWebElement(HomePageconstants.acceptcookies); } else {
		  logger("INFO: Accept cookie pop-up is not appear" , Status.INFO); }
		 
		return this;
	}

	public Product_Menu_Page ClickProducts() {
		clickWithScreenshot(HomePageconstants.Products_menu);
		return new Product_Menu_Page();
	}

	public Product_Menu_Page SelectProductmenu() {
		SelectAnyMenu(HomePageconstants.Products_menu);	
		return new Product_Menu_Page();
	}


	public Market_Page SelectMarketmenu() {
		SelectAnyMenu(HomePageconstants.Market_we_serve); 
		return new Market_Page();
	}

	public Service_Support_Page Select_Service_support() {
		SelectAnyMenu(HomePageconstants.Service_support); 
		return new Service_Support_Page();
	}


	public void SelectAnyMenu(WebElement ele) {
		clickWithScreenshot(ele);
		if (verifyElementDisplayed(HomePageconstants.Overlay)) {
			logger("Verification: Other contents in the Page got Grayed out", Status.PASS);
		}

		if (verifyElementDisplayed(HomePageconstants.Selectedmenu)) {
			logger("Element is highlighted and underlined", Status.PASS);
		}

		if (verifyElementDisplayed(HomePageconstants.Selectedarrow)) {
			logger("Arrow Icon is rotated upward and highlighted", Status.PASS);
		}

	}

	public void SelectAnyMenu_NoArrow(WebElement ele) throws InterruptedException {

		Thread.sleep(2000);
		VerifyElementIsHighlighted(ele);
		Thread.sleep(2000);
		clickWithScreenshot(ele);
		if (verifyElementDisplayed(ele)) {
			logger("Element is underlined" , Status.PASS);
		}

	}

	public About_Danfoss_Page Select_About_Danfoss() throws InterruptedException {
		SelectAnyMenu(HomePageconstants.About_danfoss);
		return new About_Danfoss_Page();

	}

	public Home_Page Select_About_Danfoss_with_NoArrow() throws InterruptedException {
		SelectAnyMenu_NoArrow(HomePageconstants.About_danfoss);
		return this;

	}

	public Home_Page Select_ContactUs_with_NoArrow() throws InterruptedException {
		SelectAnyMenu_NoArrow(HomePageconstants.Contact_us);
		return this;

	}

	public Home_Page Select_Service_Support_with_NoArrow() throws InterruptedException {
		SelectAnyMenu_NoArrow(HomePageconstants.Service_support);
		return this;

	}

	public Home_Page Select_Market_we_serve_with_NoArrow() throws InterruptedException {
		SelectAnyMenu_NoArrow(HomePageconstants.Market_we_serve);
		return this;

	}

	public Home_Page Select_Products_with_NoArrow() throws InterruptedException {
		SelectAnyMenu_NoArrow(HomePageconstants.Products_menu);
		return this;

	}

	public About_Danfoss_Page Select_About_Danfoss_Russian() {
		SelectAnyMenu(HomePageconstants.About_danfoss_Russian);
		return new About_Danfoss_Page(); 

	}
	/// Need to create new page for about Contact us
	public Contact_Us_Page Select_Contact_us() throws InterruptedException {
		
		SelectAnyMenu_NoArrow(HomePageconstants.Contact_us);
		
		return new Contact_Us_Page();

	}
	
	public Contact_Us_Page Select_Contact_us_China() throws InterruptedException {
		
		SelectAnyMenu_NoArrow(HomePageconstants.Contact_us_china);
		
		return new Contact_Us_Page();

	}

	public Home_Page VerifyProduct_Menu() {
		verifyElementDisplayed(HomePageconstants.Products_menu);
		if (HomePageconstants.Products_menu_arrow.isDisplayed())
		{
			logger("Verification: Arrow Icon is available in Products and pointing downwards", Status.PASS);
		}
		return this;
	}

	public Home_Page VerifyMarket_We_Serve_Menu() {
		verifyElementDisplayed(HomePageconstants.Market_we_serve);

		if (HomePageconstants.Market_we_serve_arrow.isDisplayed())
		{
			logger("Verification: Arrow Icon is available in Market we serve and pointing downwards", Status.PASS);
		}
		return this;
	}

	public Home_Page VerifyService_Support_Menu() {
		verifyElementDisplayed(HomePageconstants.Service_support);

		if (HomePageconstants.Service_support_arrow.isDisplayed())
		{
			logger("Verification: Arrow Icon is available in Service support and pointing downwards", Status.PASS);
		}
		return this;
	}

	public Home_Page VerifyAbout_Danfoss_Menu() {
		verifyElementDisplayed(HomePageconstants.About_danfoss);
		if (HomePageconstants.About_danfoss_arrow.isDisplayed())
		{
			logger("Verification: Arrow Icon is available in About danfoss and pointing downwards", Status.PASS);
		}
		return this;
	}

	public Home_Page VerifyContact_US_Menu() {
		verifyElementDisplayed(HomePageconstants.Contact_us);
		if (HomePageconstants.Contact_us_arrow.isDisplayed())
		{
			logger("Verification: Arrow Icon is available in Contact us and pointing downwards", Status.PASS);
		}
		return this;
	}
	
	public Home_Page VerifyContact_US_Menu_without_arrow() {
		verifyElementDisplayed(HomePageconstants.Contact_us);
		
		return this;
	}

	public Home_Page VerifyStickyHeader() throws InterruptedException {
		if (HomePageconstants.primary_header.isDisplayed()) {
			logger("Verification: Header is available in HomeScreen", Status.PASS);
		}
		HomePageconstants.Region_selection_button.click();
		Thread.sleep(1000);
		if (HomePageconstants.primary_header.isDisplayed()) {
			logger("Verification: Header is available in Regionselection screen", Status.PASS);
		}
		Thread.sleep(1000);
		HomePageconstants.Products_menu.click();

		if (HomePageconstants.primary_header.isDisplayed()) {
			logger("Verification: Header is available in Product menu screen", Status.PASS);
		}
		HomePageconstants.titleImage.click();
		return this;
	}

	public Home_Page Verify_Primary_Header_section() throws InterruptedException {
		if (HomePageconstants.primary_header.isDisplayed()) {
			logger("Verification: primary Header is displayed", Status.PASS);
		}
		return this;
	}

	public Home_Page Verify_Menu_Header_section() throws InterruptedException {
		if (HomePageconstants.menu_header.isDisplayed()) {
			logger("Verification: Menu Header is displayed", Status.PASS);
		}
		return this;
	}


	public Home_Page verifyPrimaryHeadersChangeSizeonScrolling() throws InterruptedException {
		Dimension size1 = HomePageconstants.primary_header.getSize();

		int height1 = size1.height;

		scrollBottomOfPageJS();
		Thread.sleep(2000);
		Dimension size2 = HomePageconstants.primary_header.getSize();

		int height2 = size2.height;

		if(height1>height2)
		{
			logger("On Scrolling down primary header size is reduced",Status.PASS);
		}else {
			logger("On Scrolling down primary header size is not reduced",Status.FAIL);
		}

		return this;
	}

	public Home_Page verifyMenuHeadersChangeSizeonScrolling() throws InterruptedException {
		scrollTopOfPageJS();
		Thread.sleep(2000);
		Dimension size3 = HomePageconstants.menu_header.getSize();
		String Font_size1 = HomePageconstants.Products_menu.getCssValue("font-size");
		int height3 = size3.height;
		scrollBottomOfPageJS();
		Thread.sleep(2000);

		Dimension size4 = HomePageconstants.menu_header.getSize();
		String Font_size2 = HomePageconstants.Products_menu.getCssValue("font-size");
		int height4 = size4.height;
		if(height3>height4)
		{
			logger("On Scrolling down menu header size is reduced",Status.PASS);
		}else {
			logger("On Scrolling down menu header size is not reduced",Status.FAIL);
		}
		if(Font_size1.equals(Font_size2))
		{
			logger("On Scrolling down font size is not reduced",Status.FAIL);
		}else {
			logger("On Scrolling down font size is reduced",Status.PASS);
		}
		return this;
	}


	public  Region_Selection_Page Click_Globe() throws InterruptedException {
		Thread.sleep(2000);
		HomePageconstants.Region_selection_button.click();
		logger("Verification: Region_Selection Button is clicked", Status.PASS);
		return new Region_Selection_Page();
	}

	public  Region_Selection_Page Click_Selected_Region() {
		clickWebElement(HomePageconstants.Selected_region);
		return new Region_Selection_Page();
	}

	public Home_Page Verify_Danfoss_logo() {
		if(HomePageconstants.titleImage.isDisplayed())

		{

			logger("Verification: Danfoss logo is displayed", Status.PASS);
		}
		return this; 

	}

	public Home_Page Verify_Danfoss_Motto() {
		verifyElementDisplayed(HomePageconstants.Danfoss_logotitle);
		return this; 

	}

	public Home_Page Verify_Search_TextBox() {
		implicitWaiting(5);
		if(HomePageconstants.Search_box.isDisplayed())
		{
			logger("Verification: SearchBox is displayed", Status.PASS);
		}
		return this; 

	}

	public SearchResult_Page EnterText_Search(String text) {
		
		enterText(HomePageconstants.Search_box, text);
		try {
			Thread.sleep(3000);
			HomePageconstants.Search_box.sendKeys(Keys.ENTER);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			logger(e.toString(), Status.INFO);
		}
		return new SearchResult_Page();

	}



	public Home_Page EnterText_Search_ForAutosuggestion(String text) throws InterruptedException {

		enterText(HomePageconstants.Search_box, text);
		Thread.sleep(2000);
		return this;

	}

	public Home_Page Verify_Autosuggestion() {
		
		if(HomePageconstants.Search_box_Autosuggest.isDisplayed())

		{
			logger("Verfication: AutoSuggestion are displayed for Searchbox", Status.PASS);
		}
		return this; 

	}

	public Home_Page Verify_NoAutosuggestion() {

		List<WebElement> suggestions = driver.findElements(By.xpath("//div[contains(@class,'search-select__menu')]"));
		if(suggestions.size()==0)
		{
			logger("Verfication: No AutoSuggestion are displayed for Searchbox", Status.PASS);
		}
		return this; 

	}

	public Home_Page Verify_count_Autosuggestion() {

		List<WebElement> suggestions = driver.findElements(By.xpath("//div[contains(@class,'search-select__menu')]//div[@role='option']"));
		if(suggestions.size()==6)
		{
			logger("Verfication: AutoSuggestion are displayed with 7 options", Status.PASS);

		}
		for (int i = 0; i < suggestions.size(); i++) {
			HomePageconstants.Search_box.sendKeys(Keys.DOWN);

		} logger("Verfication: Able to navigate in the Autosuggestions", Status.PASS);
		return this; 

	}

	public SearchResult_Page Select_valueIn_Autosuggestion() {

		HomePageconstants.Search_box.sendKeys(Keys.DOWN);
		HomePageconstants.Search_box.sendKeys(Keys.ENTER);

		logger("Verfication: Able to navigate in Autosuggestion and select one option", Status.PASS);
		return new SearchResult_Page(); 

	}

	public Home_Page Verify_ChooseRegion_Button() {

		if(HomePageconstants.Region_selection_button.isDisplayed())

		{
			logger("Verfication: Region selection button is displayed", Status.PASS);
		}
		return this; 

	}

	public Home_Page Verify_SelectedRegion() {
		verifyElementDisplayed(HomePageconstants.Selected_region);
		return this; 

	}

	public Home_Page Verify_App_switcher_Icon() {
		if(HomePageconstants.Quick_links_icon.isDisplayed())

		{
			logger("Verfication: Quick Link Icon is displayed", Status.PASS);
		}
		return this; 

	}

	public Home_Page Verify_App_switcher_Label() {
		verifyElementDisplayed(HomePageconstants.Quick_links_label);
		return this; 

	}


	public Home_Page Click_AppSwitcher_Icon() {
		clickWithScreenshot(HomePageconstants.Quick_links_icon);
		verifyElementDisplayed(HomePageconstants.Quick_links_menus);
		HomePageconstants.Quick_links_icon.click();
		return this; 

	}

	public Home_Page Click_AppSwitcher_Label() throws InterruptedException {
		clickWebElement(HomePageconstants.Quick_links_label);
		Thread.sleep(1000);
		verifyElementDisplayed(HomePageconstants.Quick_links_menus);
		return this; 

	}

	public Home_Page Verify_Region_USA() {
		verifyTextMatch(HomePageconstants.Selected_region, "United States of America");
		return this; 

	}

	public Home_Page Move_to_linklist() {
		MoveToElement(HomePageconstants.link_list_component);
		return this; 

	}

	public Home_Page Verify_Link_list_Component() {
		try {
			if(HomePageconstants.link_list_component.isDisplayed())
			{
				logger("Verfication: link list component is displayed", Status.PASS);
			}
			if(HomePageconstants.link_list_list.isDisplayed())
			{
				logger("Verfication: linklist list container is displayed", Status.PASS);
			}
		} catch (Exception e) {
			logger("Verfication: Issue in  linklist component", Status.FAIL);
		}

		return this; 
	}


	public Home_Page Verify_Link_list_title(String etxt) {
		String atext = HomePageconstants.link_list_title.getText();
		if(atext.equalsIgnoreCase(etxt))
		{
			logger("Verfication: linklist title is matching with expected value: "+etxt, Status.PASS);
		} else {
			logger("Verfication: linklist title is not matching with expected value: "+etxt, Status.FAIL);
		}

		return this; 
	}

	public Home_Page Verify_Link_list_CaseStudies() {
		try {
			verifyElementDisplayed(HomePageconstants.link_list_item_casestudies2);
			VerifyElementIsHighlighted(HomePageconstants.link_list_item_casestudies2);
			if(HomePageconstants.link_list_item_casestudies2.isDisplayed())
			{
				logger("Verification: Right arrow Icon is displayed for casestudies", Status.PASS);
			}
		} catch (Exception e) {
			logger("Verification: issue with casestudies", Status.FAIL);
		}

		return this; 
	}

	public Home_Page Verify_Link_list_Documentation() {
		try {
			verifyElementDisplayed(HomePageconstants.link_list_item_Documentation);
			VerifyElementIsHighlighted(HomePageconstants.link_list_item_Documentation);
			if(HomePageconstants.link_list_item_Documentation_icon.isDisplayed())
			{
				logger("Verification: Right arrow Icon is displayed for documentation", Status.PASS);
			}
		} catch (Exception e) {
			logger("Verification: issue with documentation", Status.FAIL);
		}

		return this; 
	}

	public Home_Page Verify_Link_list_Downloads() {
		try {
			verifyElementDisplayed(HomePageconstants.link_list_item_Downloads);
			VerifyElementIsHighlighted(HomePageconstants.link_list_item_Downloads);
			if(HomePageconstants.link_list_item_Downloads_icon.isDisplayed())
			{
				logger("Verification: Right arrow Icon is displayed for Downloads", Status.PASS);
			}
		} catch (Exception e) {
			logger("Verification: issue with Downloads", Status.FAIL);
		}

		return this; 
	}
	
	public Home_Page Verify_Link_list_Fix_troubleshooting() {
		try {
			verifyElementDisplayed(HomePageconstants.link_list_item_Fix_troubleshooting);
			VerifyElementIsHighlighted(HomePageconstants.link_list_item_Fix_troubleshooting);
			if(HomePageconstants.link_list_item_Fix_troubleshooting_icon.isDisplayed())
			{
				logger("Verification: Right arrow Icon is displayed for Fix_troubleshooting", Status.PASS);
			}
		} catch (Exception e) {
			logger("Verification: issue with Fix_troubleshooting", Status.FAIL);
		}

		return this; 
	}
	
	public Home_Page Verify_Link_list_learning() {
		try {
			verifyElementDisplayed(HomePageconstants.link_list_item_Learning);
			VerifyElementIsHighlighted(HomePageconstants.link_list_item_Learning);
			if(HomePageconstants.link_list_item_Learning_icon.isDisplayed())
			{
				logger("Verification: Right arrow Icon is displayed for learning", Status.PASS);
			}
		} catch (Exception e) {
			logger("Verification: issue with learning", Status.FAIL);
		}

		return this; 
	}


	public Casestudies_Page Click_Link_list_casestudies() {
		clickWebElement(driver.findElement(By.xpath("//a[@href='/en/service-and-support/case-stories/']/span")));
		return new Casestudies_Page(); 
	}


	public  Footer_Page Navigate_To_Footer() throws InterruptedException {
		scrollBottomOfPageJS();
		return new Footer_Page();
	}

	public Home_Page Wait() throws InterruptedException {
		Thread.sleep(5000);
		return this;
	}
	
	public  Product_Menu_Page Open_Umbraco_Saved_published_Page(){
		String url = driver.getCurrentUrl();
		String newurl = url.replace("?accessKey=Beu66sob7AX5JwmmNM7iT8p8eOEtXp2gKqKn8AUcwRcXc", "test/");
		driver.get(newurl);
		return new Product_Menu_Page();
	}
	
	public  Product_Menu_Page Open_Umbraco_Saved_published_Page_English(){
		String url = driver.getCurrentUrl();
		String newurl = url.replace("/en/?accessKey=Beu66sob7AX5JwmmNM7iT8p8eOEtXp2gKqKn8AUcwRcXc", "/en/test");
		driver.get(newurl);
		return new Product_Menu_Page();
	}
	
	public Home_Page Script_Pass_Logger(){
		logger("Script Pass Successfully",Status.PASS);
		return this;
	}
}
