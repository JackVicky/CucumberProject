package test.automation.pages;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.Dimension;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.PageFactory;

import com.aventstack.extentreports.Status;

import test.automation.globalfunctionality.TestCaseInitiator;
import test.automation.pagelocators.ProductPageconstants;


public class OLD_Product_Category_List_Page extends TestCaseInitiator {

	public OLD_Product_Category_List_Page() {
		PageFactory.initElements(driver, ProductPageconstants.class);
	}

	public  OLD_Product_Category_List_Page VerifyProductCpagetitle() throws InterruptedException {
		verifyPageTitle("Products | Danfoss");
		return this;
	} 

	public  OLD_Product_Category_List_Page Click_Market_filter(String str) throws InterruptedException {
		dynamicElementselector("(//div[@class='filters-group__items-wrapper'])[1]//descendant::span[@class='filters-group__item__title']", str);
		return this;
	}

	public  OLD_Product_Category_List_Page Click_Business_filter(String str) throws InterruptedException {
		dynamicElementselector("(//div[@class='filters-group__items-wrapper'])[2]//descendant::span[@class='filters-group__item__title']", str);
		return this;
	}
	
	
	public  OLD_Product_Category_List_Page Verify_Productcategory_Count() throws InterruptedException {
		Thread.sleep(2000);
		VerifyTheSizeOfTheLocator(By.xpath("//div[@class='product-segments-item col-sm-6 col-md-4']"));
		return this;
	}
	
	public  OLD_Product_Category_List_Page Verify_Productcategory_Count_Withdetails() throws InterruptedException {
		Thread.sleep(2000);
		String text = ProductPageconstants.category_numberofresult.getText();

		logger("Information:  "+text , Status.INFO);
		logger("Verification: Based on the selected filter option, result are reduced and no error in the page", Status.PASS);
		return this;
	}
	
	public  OLD_Product_Category_List_Page Verify_Productcategory_list() throws InterruptedException {
		
		 if(driver.findElement(By.xpath("//div[@class='filterable-list__items row product-categories-items']")).isDisplayed())
		 {
			 
			 List<WebElement> listOfElement = ListOfElement("xpath", "//div[@class='filterable-list__items row product-categories-items']//descendant::a");
			 for (int i = 0; i < listOfElement.size(); i++) {
				 if(listOfElement.get(i).isDisplayed())
				 {
					 loggerWithScreenshot("Verification: Category list with links is displayed", "", Status.PASS, true);
				 }
			}
			
		 } else
			 logger("Verification: Product category is not displayed", Status.FAIL);


		
		return this;
	}
	
	
	public  OLD_Product_Category_List_Page Verify_Alphaticalorder_Productcategory_list() throws InterruptedException {
		Verify_Alphabatic_Order("//div[@class='filterable-list__items row product-categories-items']//descendant::a");

		return this;
	}

	public OLD_Product_Category_List_Page Verify_Productcategories_Highlighted() throws InterruptedException {
		List<WebElement> country = ListOfElement("xpath", "//div[@class='filterable-list__items row product-categories-items']//descendant::a");
		for (int i = 0; i < country.size(); i++) {
			VerifyElementIsHighlighted(country.get(i));
		}
		return this;
	}
	
	public  OLD_Product_Category_List_Page Verify_Url(String str1) throws InterruptedException {
		Thread.sleep(1000);
		System.out.println(str1);
		if(driver.getCurrentUrl().contains(str1))
		{
			logger("Verification: Selected Filter is updated in the URL" , Status.PASS);
		}
		else
		{
			logger("Verification: URL does not contain filters" , Status.FAIL);
		}
		return this;
	}

	public  OLD_Product_Category_List_Page Verify_Url_NoFilter(String str1) throws InterruptedException {
		Thread.sleep(1000);
		if(!driver.getCurrentUrl().contains(str1))
		{
			logger("Verification: Filter are not available in updated URL" , Status.PASS);
		}
		else
		{
			logger("Verification: Filter are  available in updated URL" , Status.FAIL);
		}
		return this;
	}


	public  OLD_Product_Category_List_Page Verify_clear_filter() throws InterruptedException {
		verifyElementDisplayed(ProductPageconstants.clear_filter);
		return this;
	}

	public  OLD_Product_Category_List_Page Click_Clear_filter() throws InterruptedException {
		clickWebElement(ProductPageconstants.clear_filter);
		return this;
	}
	public  OLD_Product_Category_List_Page Verify_No_clear_filter() throws InterruptedException {
		verifyElementNotDisplayed("//button[contains(@class,'reset-filter-button')]//descendant::span[@class='cta-content-text']");
		return this;
	}

	public  OLD_Product_Category_List_Page Open_Url_NewTab() throws InterruptedException {

		openLinkInNewTab(driver.getCurrentUrl());
		loggerWithScreenshot("Verfication: URL is opened in new Window with same filters", "", Status.PASS, true);
		return this;
	}

	public  OLD_Product_Category_List_Page Verify_Filter_Section() throws InterruptedException {
		if(ProductPageconstants.filter_category.isDisplayed())
		{
			logger("Verification: Filter section is displayed", Status.PASS);
		}
		else
		{
			logger("Verification: Filter section is not displayed", Status.FAIL);
		}
		return this;
	}

	public  OLD_Product_Category_List_Page Verify_Breadcrumbs() throws InterruptedException {
		if(ProductPageconstants.breadcrumbs_category.isDisplayed())
		{
			logger("Verification: Breadcrumnb is displayed", Status.PASS);
		}
		else
		{
			logger("Verification: Breadcrumnb is not displayed", Status.FAIL);
		}
		return this;
	}

	public  OLD_Product_Category_List_Page Verify_Markets_filter() throws InterruptedException {
		verifyElementDisplayed(ProductPageconstants.Market_filter);
		if(driver.findElement(By.xpath("(//span[@class='icon icon-chevron-up-small']//ancestor::div[@class='filters-group '])[1]")).isDisplayed())
		{
			logger("Verification: Market filter is expanded by default and Arrow is pointed up", Status.PASS);
		}
		else
		{
			logger("Verification: Market filter is not Expanded ", Status.FAIL);
		}
		return this;
	}



	public  OLD_Product_Category_List_Page Verify_Business_filter() throws InterruptedException {
		verifyElementDisplayed(ProductPageconstants.Business_filter);
		if(driver.findElement(By.xpath("(//span[@class='icon icon-chevron-up-small']//ancestor::div[@class='filters-group '])[2]")).isDisplayed())
		{
			logger("Verification: Business filter is expanded by default and Arrow is pointed up", Status.PASS);
		}
		else
		{
			logger("Verification: Business filter is not expanded ", Status.FAIL);
		}
		return this;
	}


	public  OLD_Product_Category_List_Page Verify_Alphaticalorder_MarketFilter() throws InterruptedException {
		Verify_Alphabatic_Order("(//div[@class='filters-group__items-wrapper'])[1]//descendant::span[@class='filters-group__item__title']");

		return this;
	}

	public  OLD_Product_Category_List_Page Verify_Alphaticalorder_BusinessFilter() throws InterruptedException {
		Verify_Alphabatic_Order("(//div[@class='filters-group__items-wrapper'])[2]//descendant::span[@class='filters-group__item__title']");

		return this;
	}

	public  OLD_Product_Category_List_Page Verify_Highlighted_filterValues() throws InterruptedException {
		WebElement ele = driver.findElement(By.xpath("((//div[@class='filters-group__items-wrapper'])[1]//descendant::span[@class='filters-group__item__title'])[1]"));
		VerifyElementIsHighlighted(ele);
		return this;
	}

	public  OLD_Product_Category_List_Page Verify_FilterisSelected(String str) throws InterruptedException {
		if(dynamicElementDisplayed("//span[contains(@class,'checked-true')]//following-sibling::span[@class='filters-group__item__title']", str));
		{
			logger("Verification: "+str+ " is selected", Status.PASS);

		}
		return this;
	}


	public  OLD_Product_Category_List_Page Verify_SelectedFilter_In_Applied(String str) throws InterruptedException {
		
		String text = driver.findElement(By.xpath("(//div[@class='unselect-buttons-group']//descendant::span[@class='cta__content-text'])[1]")).getText();
		if(text.contains(str))
		
		//if(dynamicElementDisplayed("(//div[@class='unselect-buttons-group']//descendant::span[@class='cta__content-text'])", str))
		{
			logger("Verification: "+str+ " is added in the applied filter section", Status.PASS);

			if(ProductPageconstants.Applied_filter_close.isDisplayed())
			{
				logger("Verification: "+str+ " contains close button", Status.PASS);

			}
			else {

				logger("Verification: "+str+ " not contains close button", Status.FAIL);
			}
		}
		else {

			logger("Verification: "+str+ "is not added in the applied filter section", Status.FAIL);

		}



		return this;
	}

	public  OLD_Product_Category_List_Page Verify_Highlighted_AppliedFilter() throws InterruptedException {
		WebElement ele = driver.findElement(By.xpath("(//div[@class='unselect-buttons-group']//descendant::span[@class='cta__content-text'])[1]"));
		VerifyElementIsHighlighted(ele);
		return this;
	}

	public  OLD_Product_Category_List_Page Deselect_Filters() throws InterruptedException {
		try {
			List<WebElement> findElementsByXPath = driver.findElements(By.xpath("//div[@class='unselect-buttons-group']//descendant::span[@class='icon icon-cancel']"));
			for (int i = 0; i < findElementsByXPath.size(); i++) {
				findElementsByXPath.get(i).click();
			}
			Thread.sleep(2000);
			loggerWithScreenshot("Verification: Filters are removed in applied filter and also it filter section", "", Status.PASS, true);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		return this;
	}

	public OLD_Product_Category_List_Page Click_Category(String text) throws InterruptedException {
		Thread.sleep(2000);
		try {
			dynamicElementselector("//div[@class='filterable-list__items row product-categories-items']//descendant::a", text);
		
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return this;
	}

}