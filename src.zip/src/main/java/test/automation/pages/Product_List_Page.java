package test.automation.pages;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;

import com.aventstack.extentreports.Status;

import test.automation.globalfunctionality.TestCaseInitiator;
import test.automation.pagelocators.HomePageconstants;
import test.automation.pagelocators.ProductPageconstants;

public class Product_List_Page extends TestCaseInitiator {

	public Product_List_Page() {
		PageFactory.initElements(driver, ProductPageconstants.class);
	}

	public  Product_List_Page VerifyProductpagetitle() throws InterruptedException {
		verifyPageTitle("AC drives | Danfoss");
		return this;
	}

	public Home_Page Navigate_homepage() {

		HomePageconstants.titleImage.click();
		return new Home_Page();

	}

	public  Product_List_Page Click_Business_filter(String str) throws InterruptedException {
		dynamicElementselector("(//div[@class='filters-group__items-wrapper'])[2]//descendant::span[@class='filters-group__item__title']", str);
		return this;
	}

	public  Product_List_Page Click_Application_filter(String str) throws InterruptedException {
		dynamicElementselector("//div[text()='Applications']//following::span[@class='filters-group__item__title']", str);
		return this;
	}

	public  Product_List_Page Click_Market_Filter() throws InterruptedException {
		clickWebElement(ProductPageconstants.Market_filter);
		return this;
	}


	public  Product_List_Page Click_Market_filtervalue(String str) throws InterruptedException {
		Thread.sleep(1000);
		dynamicElementselector("//div[text()='Market']//following::span[@class='filters-group__item__title']", str);
		return this;
	}

	public  Product_List_Page Verify_Url(String str1) throws InterruptedException {
		Thread.sleep(1000);
		if(driver.getCurrentUrl().contains(str1))
		{
			logger("Verification: Selected Filter is updated in the URL" , Status.PASS);
		}
		else
		{
			logger("Verification: URL does not contain filters" , Status.FAIL);
		}
		return this;
	}

	public  Product_List_Page Verify_Url_NoFilter(String str1) throws InterruptedException {
		Thread.sleep(1000);
		if(!driver.getCurrentUrl().contains(str1))
		{
			logger("Verification: Filter are not available in updated URL" , Status.PASS);
		}
		else
		{
			logger("Verification: Filter are  available in updated URL" , Status.FAIL);
		}
		return this;
	}

	public  Product_List_Page Verify_clear_filter() throws InterruptedException {
		verifyElementDisplayed(ProductPageconstants.clear_filter);
		return this;
	}

	public  Product_List_Page Click_Clear_filter() throws InterruptedException {
		clickWebElement(ProductPageconstants.clear_filter);
		return this;
	}
	public  Product_List_Page Verify_No_clear_filter() throws InterruptedException {
		verifyElementNotDisplayed("//button[contains(@class,'reset-filter-button')]//descendant::span[@class='cta-content-text']");
		return this;
	}

	public  Product_List_Page Verify_product_Count() throws InterruptedException {
		Thread.sleep(2000);
		String text = ProductPageconstants.numberofresult.getText();
		//String substring = text.substring(text.indexOf(':'), text.lastIndexOf(text)-1);
		logger("Information:  "+text , Status.INFO);
		return this;
	}

	public  Product_List_Page Open_Url_NewTab() throws InterruptedException {

		openLinkInNewTab(driver.getCurrentUrl());
		loggerWithScreenshot("Verfication: URL is opened in new Window with same filters", "", Status.PASS, true);
		return this;
	}

	public  Product_List_Page Verify_Filter_Section() throws InterruptedException {
		if(ProductPageconstants.filter.isDisplayed())
		{
			logger("Verification: Filter section is displayed", Status.PASS);
		}
		else
		{
			logger("Verification: Filter section is not displayed", Status.FAIL);
		}
		return this;
	}

	public  Product_List_Page Verify_Breadcrumbs() throws InterruptedException {
		if(ProductPageconstants.breadcrumbs.isDisplayed())
		{
			logger("Verification: Breadcrumnb is displayed", Status.PASS);
		}
		else
		{
			logger("Verification: Breadcrumnb is not displayed", Status.FAIL);
		}
		return this;
	}
	public  Product_List_Page Verify_Markets_filter() throws InterruptedException {
		verifyElementDisplayed(ProductPageconstants.Market_filter);
		if(ProductPageconstants.Market_filters_collapsed.isDisplayed())
		{
			logger("Verification: Market filter is collapsed by default and Arrow is pointed down", Status.PASS);
		}
		else
		{
			logger("Verification: Market filter is not collapsed ", Status.FAIL);
		}
		return this;
	}

	public  Product_List_Page Verify_Business_filter() throws InterruptedException {

		if(dynamicElementDisplayed("//div[contains(@style,'display: block')]//preceding-sibling::div[@class='filters-group__heading']", "Business unit"))

		{
			logger("Verification: Business filter is expanded by default and Arrow is pointed up", Status.PASS);
		}
		else
		{
			logger("Verification: Business filter is not expanded ", Status.FAIL);
		}
		return this;
	}

	public  Product_List_Page Verify_Brands_filter() throws InterruptedException {

		if(dynamicElementDisplayed("//div[contains(@style,'display: block')]//preceding-sibling::div[@class='filters-group__heading']", "Brands"))

		{
			logger("Verification: Brand filter is expanded by default and Arrow is pointed up", Status.PASS);
		}
		else
		{
			logger("Verification: Brand filter is not expanded ", Status.FAIL);
		}
		return this;
	}

	public  Product_List_Page Verify_Applications_filter() throws InterruptedException {

		if(dynamicElementDisplayed("//div[contains(@style,'display: block')]//preceding-sibling::div[@class='filters-group__heading']", "Applications"))

		{
			logger("Verification: Applications is expanded by default and Arrow is pointed up", Status.PASS);
		}
		else
		{
			logger("Verification: Applications filter is not expanded ", Status.FAIL);
		}
		return this;
	}

	public  Product_List_Page Verify_ProductType_filter() throws InterruptedException {

		if(dynamicElementDisplayed("//div[contains(@style,'display: block')]//preceding-sibling::div[@class='filters-group__heading']", "Product types"))

		{
			logger("Verification: Product types is expanded by default and Arrow is pointed up", Status.PASS);
		}
		else
		{
			logger("Verification: Product types filter is not expanded ", Status.FAIL);
		}
		return this;
	}

	public  Product_List_Page Verify_Alphaticalorder_Filteroptions() throws InterruptedException {
		logger("Below steps will check filter values in each filters are arranged in alphabatical order", Status.INFO);
		Verify_Alphabatic_Order("(//div[@class='filters-group__items-wrapper'])[1]//descendant::span[@class='filters-group__item__title']");
		Verify_Alphabatic_Order("(//div[@class='filters-group__items-wrapper'])[2]//descendant::span[@class='filters-group__item__title']");
		Verify_Alphabatic_Order("(//div[@class='filters-group__items-wrapper'])[3]//descendant::span[@class='filters-group__item__title']");
		Verify_Alphabatic_Order("(//div[@class='filters-group__items-wrapper'])[4]//descendant::span[@class='filters-group__item__title']");
		Verify_Alphabatic_Order("(//div[@class='filters-group__items-wrapper'])[5]//descendant::span[@class='filters-group__item__title']");
		Verify_Alphabatic_Order("(//div[@class='filters-group__items-wrapper'])[6]//descendant::span[@class='filters-group__item__title']");
		return this;

	}

	public  Product_List_Page Verify_FilterisSelected(String str) throws InterruptedException {
		if(dynamicElementDisplayed("//span[contains(@class,'checked-true')]//following-sibling::span[@class='filters-group__item__title']", str));
		{
			logger("Verification: "+str+ " is selected", Status.PASS);

		}
		return this;
	}


	public  Product_List_Page Verify_Highlighted_filterValues() throws InterruptedException {
		WebElement ele = driver.findElement(By.xpath("((//div[@class='filters-group__items-wrapper'])[2]//descendant::span[@class='filters-group__item__title'])[1]"));
		VerifyElementIsHighlighted(ele);
		return this;
	}

	public  Product_List_Page Verify_SelectedFilter_In_Applied(String str) throws InterruptedException {

		String text = driver.findElement(By.xpath("(//div[@class='unselect-buttons-group']//descendant::span[@class='cta__content-text'])[1]")).getText();
		if(text.contains(str))

		{
			logger("Verification: "+str+ " is added in the applied filter section", Status.PASS);

			if(ProductPageconstants.Applied_filter_close.isDisplayed())
			{
				logger("Verification: "+str+ " contains close button", Status.PASS);

			}
			else {

				logger("Verification: "+str+ " not contains close button", Status.FAIL);
			}
		}
		else {

			logger("Verification: "+str+ "is not added in the applied filter section", Status.FAIL);

		}

		return this;
	}


	public  Product_List_Page Verify_Highlighted_AppliedFilter() throws InterruptedException {
		WebElement ele = driver.findElement(By.xpath("(//div[@class='unselect-buttons-group']//descendant::span[@class='cta__content-text'])[1]"));
		VerifyElementIsHighlighted(ele);
		return this;
	}


	public  Product_List_Page Deselect_Filters() throws InterruptedException {
		try {
			List<WebElement> findElementsByXPath = driver.findElements(By.xpath("//div[@class='unselect-buttons-group']//descendant::span[@class='icon icon-cancel']"));
			for (int i = 0; i < findElementsByXPath.size(); i++) {
				findElementsByXPath.get(i).click();
			}
			Thread.sleep(2000);
			loggerWithScreenshot("Verification: Filters are removed in applied filter and also it filter section", "", Status.PASS, true);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		return this;
	}

	public  Product_List_Page Verify_SortButton_withoptions() throws InterruptedException {
		verifyElementDisplayed(ProductPageconstants.sort_button);
		Thread.sleep(2000);
		driver.findElement(By.xpath("//select[@class='sort-select cta cta--small cta--block']")).click();
		verifyElementDisplayed(ProductPageconstants.Default_sorting);
		verifyElementDisplayed(ProductPageconstants.sort_title_asc);
		verifyElementDisplayed(ProductPageconstants.sort_title_desc);

		return this;
	}

	public  Product_List_Page Verify_items_AscendingOrder()

	{

		clickWebElement(ProductPageconstants.sort_title_asc);
		Verify_Alphabatic_Order("//div[@class='tile__text-title']");
		return this;

	}

	public  Product_List_Page Verify_Show_More_button() throws InterruptedException

	{
		Thread.sleep(2000);
		verifyElementDisplayed(ProductPageconstants.products_show_more);
		verifyElementDisplayed(ProductPageconstants.products_show_more_count);
		return this;

	}

	public  Product_List_Page Click_Show_More_button()

	{
		clickWebElement(ProductPageconstants.products_show_more);
		return this;

	}

	public  Product_List_Page Verify_Show_less_button()

	{
		if(verifyElementDisplayed(ProductPageconstants.products_show_more))
		{
			logger("Verification: All filter options are expanded", Status.PASS);
		}

		return this;

	}

	public  Product_List_Page Click_Show_lessbutton()

	{
		try {
			clickWebElement(ProductPageconstants.products_show_more);

			logger("verification: All filter are collapsed to two rows", Status.PASS);
			verifyElementDisplayed(ProductPageconstants.products_show_more);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		return this;

	}

	public  Product_List_Page Click_Product()
	{
		clickWebElement(ProductPageconstants.category_title_inside);

		return this;
	}

	public Product_List_Page Verify_FandB_Title()
	{
		MoveToElement(ProductPageconstants.Features_benefits_title);
		verifyElementDisplayed(ProductPageconstants.Features_benefits_title);
		return this;
	}

	public Product_List_Page Verify_FandB_section()
	{
		try {
			if(ProductPageconstants.Benefits_section.isDisplayed())
			{
				logger("Verification: Benefit section is displayed", Status.PASS);
			}
			List<WebElement> benefits = driver.findElements(By.xpath("//div[contains(@class,'benefits__text')]"));
			logger("Verification: Following benefits are available", Status.PASS);
			for (int i = 0; i < benefits.size(); i++) {
				logger("verification: "+benefits.get(i).getText(), Status.INFO);
			}

		} catch (Exception e) {
			logger("Verification: Issue in Benefit section", Status.FAIL);
		}

		return this;
	}


	public Product_List_Page Verify_Stickytab_section() throws InterruptedException
	{	
		Thread.sleep(2000);
		try {
			if(ProductPageconstants.Sticky_tab_section.isDisplayed())
			{
				logger("Verification: Tab_section is displayed", Status.PASS);
			}
			scrollBottomOfPageJS();
			
			if(ProductPageconstants.Sticky_tab_section.isDisplayed())
			{
				logger("Verification: While scrolling down, Tab is sticky in header section", Status.PASS);
			}
			Thread.sleep(2000);
			scrollTopOfPageJS();
		} catch (Exception e) {
			logger("Verification: issue with Tab_section", Status.FAIL);
		}

		return this;
	}

	public  Product_List_Page Click_OverView_tab() throws InterruptedException{
		clickWebElement(ProductPageconstants.Overview_tab);
		Thread.sleep(3000);
		return this;
	}

	public Product_List_Page Verify_Active_tab(String etext) throws InterruptedException
	{	
			Thread.sleep(6000);
			String atext = ProductPageconstants.Active_tab.getText();
			if(atext.equalsIgnoreCase(etext))
			{
				logger("Verification: Active tab is: "+atext, Status.PASS);
			}
			else
			{
				logger("Verification: Active tab is present as: "+atext+" instead of: "+etext, Status.FAIL);
			}

		return this;
	}
	
	
	

	public Product_List_Page Click_product_tab(String etext)
	{
		try {
			dynamicElementselector("//li[contains(@class,'tabs__item')]//child::span", etext);


		} catch (Exception e) {
			logger("Verification: issue in clicking tab "+etext , Status.FAIL);
		}

		return this;
	}

	public Product_List_Page Verify_tab_inURL(String etext)
	{
		try {
			if(driver.getCurrentUrl().contains("#tab-"+etext))
			{
				logger("Verification: URL is updated with tab: "+etext , Status.PASS);
			} else
			{
				logger("Verification: issue in URL" , Status.FAIL);
			}

		} catch (Exception e) {
			logger("Verification: issue in URL" , Status.FAIL);
		}

		return this;
	}

	public Product_List_Page CopyURL_to_Newtab()
	{
		try {
			String currentUrl = driver.getCurrentUrl();

			openLinkInNewTab(currentUrl);

			logger("Verification: URL is copied to new URL" , Status.PASS);


		} catch (Exception e) {
			logger("Verification: issue in opening url in new tab" , Status.FAIL);
		}

		return this;
	}
	
	
	public Product_List_Page Verify_Productpage_title(String etext)
	{
		try {
			if(ProductPageconstants.Product_page_title.getText().equalsIgnoreCase(etext))
			{
				logger("Verification: Product page title matches with the expected value "+etext , Status.PASS);
			}

		} catch (Exception e) {
			logger("Verification: issue in URL" , Status.FAIL);
		}

		return this;
	}
	
	public Product_List_Page Verify_Productpage_components()
	{
		try {
			if(ProductPageconstants.RTE_component.isDisplayed())
			{
				logger("Verification: RTE component is displayed" , Status.PASS);
			}
			if(ProductPageconstants.link_list_component.isDisplayed())
			{
				logger("Verification: link_list_component is displayed" , Status.PASS);
			}
			if(ProductPageconstants.link_list_item.isDisplayed())
			{
				logger("Verification: link_list_item is displayed" , Status.PASS);
			}
			if(ProductPageconstants.cta_button_link.isDisplayed())
			{
				logger("Verification: cta_button_link is displayed" , Status.PASS);
			}
		} catch (Exception e) {
			logger("Verification: issue with product page components" , Status.FAIL);
		}

		return this;
	}
	
	
	
	public  Product_List_Page Click_P_C_product_forstickytab()   {
		WebElement ele = driver.findElement(By.xpath("//div[text()='VACON® 20 Cold Plate']"));
		clickWebElement(ele);
		return this;
	}

	public Product_List_Page Wait(int timeunit) throws InterruptedException {
		Thread.sleep(timeunit);
		return this;
	}
	
	@FindBy(how = How.XPATH, using = "(//div[contains(@class,'rte')])[1]")
	public static WebElement RTE_component;
	@FindBy(how = How.XPATH, using = "//div[@class='link-list']")
	public static WebElement link_list_component;
	@FindBy(how = How.XPATH, using = "(//ul[@class='link-list__list']//a)[1]")
	public static WebElement link_list_item;
	@FindBy(how = How.XPATH, using = "(//div[@class='card__cta']//a)[1]")
	public static WebElement cta_button_link;
	
	public Product_List_Page Click_Documents_tab() throws InterruptedException{
		clickWebElement(ProductPageconstants.Documents_tab);
		Thread.sleep(3000);
		return this;
	}

}