package test.automation.pages;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.PageFactory;

import com.aventstack.extentreports.Status;

import test.automation.globalfunctionality.TestCaseInitiator;
import test.automation.pagelocators.DownloadsPageconstants;
import test.automation.pagelocators.HomePageconstants;

public class Downloads_Page extends TestCaseInitiator {

	public Downloads_Page() {
		PageFactory.initElements(driver, DownloadsPageconstants.class);
	}

	public  Downloads_Page verify_DownloadsTitle() throws InterruptedException {
		verifyPageTitle("Downloads | Danfoss");
		return this;
	}


	public  Home_Page Navigate_homepage() {
		clickWebElement(HomePageconstants.titleImage);
		return new Home_Page();
	}

	public  Downloads_Page Click_Business_filter(String str) throws InterruptedException {
		Thread.sleep(2000);
		//dynamicElementselector("(//div[@class='filters-group__items-wrapper'])[2]//descendant::span[@class='filters-group__item__title']", str);
		dynamicElementselector("//div[@class='filters-group ']//span[@class='filters-group__item__title']", str);
		return this;
	}

	public  Downloads_Page Verify_Business_filtervalue(String str) throws InterruptedException {
		Thread.sleep(1000);
		dynamicElementDisplayed("(//div[@class='filters-group__item'])//descendant::span[@class='filters-group__item__title']", str);

		return this;
	}

	public  Downloads_Page Click_DownloadType_filter(String str) throws InterruptedException {

		dynamicElementselector("(//div[@class='filters-group__items-wrapper'])[1]//descendant::span[@class='filters-group__item__title']", str);
		return this;
	}

	public  Downloads_Page Verify_Url(String str1) throws InterruptedException {
		Thread.sleep(1000);
		if(driver.getCurrentUrl().contains(str1))
		{
			logger("Verification: Selected Filter is updated in the URL" , Status.PASS);
		}
		else
		{
			logger("Verification: URL does not contain filters" , Status.FAIL);
		}
		return this;
	}

	public  Downloads_Page Verify_Url_NoFilter(String str1) throws InterruptedException {
		Thread.sleep(1000);
		if(!driver.getCurrentUrl().contains(str1))
		{
			logger("Verification: Filter are not available in updated URL" , Status.PASS);
		}
		else
		{
			logger("Verification: Filter are  available in updated URL" , Status.FAIL);
		}
		return this;
	}

	public  Downloads_Page Verify_Page_heading() throws InterruptedException {
		Thread.sleep(2000);
		if(verifyElementDisplayed(DownloadsPageconstants.Page_heading))
		{
			logger("Verification: Page title is displayed in H1 format in top of the page", Status.PASS);
		}

		else
		{
			logger("\"Verification: Page title is not displayed in H1 format in top of the page", Status.FAIL);
		}
		return this;

	}

	public  Downloads_Page Verify_clear_filter() throws InterruptedException {
		verifyElementDisplayed(DownloadsPageconstants.clear_filter);
		return this;
	}

	public  Downloads_Page Click_Clear_filter() throws InterruptedException {
		clickWebElement(DownloadsPageconstants.clear_filter);
		return this;
	}
	public  Downloads_Page Verify_No_clear_filter() throws InterruptedException {
		verifyElementNotDisplayed("//button[contains(@class,'reset-filter-button')]//descendant::span[@class='cta-content-text']");
		return this;
	}

	public  Downloads_Page Verify_Item_Count() throws InterruptedException {
		Thread.sleep(2000);
		String text = DownloadsPageconstants.numberofresult.getText();
		//String substring = text.substring(text.indexOf(':'), text.lastIndexOf(text)-1);
		logger("Information:  "+text , Status.INFO);
		return this;
	}

	public  Downloads_Page Verify_Filter_Section() throws InterruptedException {
		if(DownloadsPageconstants.filter.isDisplayed())
		{
			logger("Verification: Filter section is displayed", Status.PASS);
		}
		else
		{
			logger("Verification: Filter section is not displayed", Status.FAIL);
		}
		return this;
	}

	public  Downloads_Page Verify_Breadcrumbs() throws InterruptedException {
		if(DownloadsPageconstants.breadcrumbs1.isDisplayed() && DownloadsPageconstants.breadcrumbs2.isDisplayed())
		{
			logger("Verification: Breadcrumnb is displayed", Status.PASS);
		}
		else
		{
			logger("Verification: Breadcrumnb is not displayed", Status.FAIL);
		}
		return this;
	}
	public  Downloads_Page Verify_DownloadType_filter() throws InterruptedException {
		verifyElementDisplayed(DownloadsPageconstants.Download_filter);
		if(DownloadsPageconstants.Download_filters_collapsed.isDisplayed())
		{
			logger("Verification: Download Type filter is collapsed by default and Arrow is pointed down", Status.PASS);
		}
		else
		{
			logger("Verification: Download Type filter is not collapsed ", Status.FAIL);
		}
		return this;
	}

	public  Downloads_Page Click_DownloadType_filter() throws InterruptedException {
		driver.findElement(By.xpath("(//div[@class='filters-group__heading'])[1]//child::span")).click();
		Thread.sleep(2000);
		return this;
	}


	public  Downloads_Page Verify_Business_filter() throws InterruptedException {

		if(dynamicElementDisplayed("//div[contains(@class,'filters-group__items-wrapper_expanded')]//preceding-sibling::div[@class='filters-group__heading']", "Business unit"))

		{
			logger("Verification: Business filter is expanded by default and Arrow is pointed up", Status.PASS);
		}
		else
		{
			logger("Verification: Business filter is not expanded ", Status.FAIL);
		}
		return this;
	}


	public  Downloads_Page Verify_Alphaticalorder_Filteroptions() throws InterruptedException {
		logger("Below steps will check filter values in each filters are arranged in alphabatical order", Status.INFO);
		//Verify_Alphabatic_Order("(//div[@class='filters-group__items-wrapper'])[1]//descendant::span[@class='filters-group__item__title']");
		Verify_Alphabatic_Order("(//ul[@class='filters-group__items'])[1]//descendant::span[@class='filters-group__item__title']");
		//Verify_Alphabatic_Order("(//div[@class='filters-group__items-wrapper'])[2]//descendant::span[@class='filters-group__item__title']");
		Verify_Alphabatic_Order("(//ul[@class='filters-group__items'])[2]//descendant::span[@class='filters-group__item__title']");

		return this;

	}

	public  Downloads_Page Verify_FilterisSelected(String str) throws InterruptedException {
		//if(dynamicElementDisplayed("//span[contains(@class,'checked-true')]//following-sibling::span[@class='filters-group__item__title']", str));
		if(dynamicElementDisplayed("//div[@class='filters-group ']//span[@class='filters-group__item__title']", str));
		{
			logger("Verification: "+str+ " is selected", Status.PASS);

		}
		return this;
	}


	public  Downloads_Page Verify_Highlighted_filterValues() throws InterruptedException {
		WebElement ele= driver.findElement(By.xpath("((//ul[@class='filters-group__items'])[2]//descendant::span[@class='filters-group__item__title'])[1]"));
				//"((//div[@class='filters-group__items-wrapper'])[2]//descendant::span[@class='filters-group__item__title'])[1]"
		VerifyElementIsHighlighted(ele);
		return this;
	}

	public  Downloads_Page Verify_SelectedFilter_In_Applied(String str) throws InterruptedException {

		//String text = driver.findElement(By.xpath("(//div[@class='unselect-buttons-group']//descendant::span[@class='cta__content-text'])[1]")).getText();
		WebElement ele = driver.findElement(By.xpath("(//div[@class='filters-group ']//span[@class='filters-group__item__title'])[1]"));
		String text = ele.getText();
		if(text.contains(str))
		{
			logger("Verification: "+str+ " is added in the applied filter section", Status.PASS);
			if(verifyElementDisplayed(DownloadsPageconstants.CheckBox_ClimateSolution_BusinessUnitFilter)) {
				logger("Verification: BusinessUnit Climate Solution for Cooling is already clicked", Status.INFO);
			}else{
				clickWebElement(ele);
			}
			Thread.sleep(2000);
			if(DownloadsPageconstants.Applied_filter_close.isDisplayed())
			{
				logger("Verification: "+str+ " contains close button", Status.PASS);

			}
			else {

				logger("Verification: "+str+ " not contains close button", Status.FAIL);
			}
		}
		else {

			logger("Verification: "+str+ "is not added in the applied filter section", Status.FAIL);

		}

		return this;
	}


	public  Downloads_Page Verify_Highlighted_AppliedFilter() throws InterruptedException {
		WebElement ele = driver.findElement(By.xpath("(//div[@class='unselect-buttons-group']//descendant::span[@class='cta__content-text'])[1]"));
		VerifyElementIsHighlighted(ele);
		return this;
	}


	public  Downloads_Page Deselect_Filters() throws InterruptedException {
		try {
			List<WebElement> findElementsByXPath = driver.findElements(By.xpath("//div[@class='unselect-buttons-group']//descendant::span[@class='icon icon-cancel']"));
			for (int i = 0; i < findElementsByXPath.size(); i++) {
				findElementsByXPath.get(i).click();
			}
			Thread.sleep(2000);
			loggerWithScreenshot("Verification: Filters are removed in applied filter and also it filter section", "", Status.PASS, true);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		return this;
	}

	public  Downloads_Page Verify_SortButton_withoptions() throws InterruptedException {
		verifyElementDisplayed(DownloadsPageconstants.sort_button);
		Thread.sleep(2000);
		driver.findElement(By.xpath("//select[@class='sort-select cta cta--small cta--block']")).click();
		verifyElementDisplayed(DownloadsPageconstants.Default_sorting);
		verifyElementDisplayed(DownloadsPageconstants.sort_title_asc);
		verifyElementDisplayed(DownloadsPageconstants.sort_title_desc);

		return this;
	}




	public  Downloads_Page Verify_items_AscendingOrder()

	{

		clickWebElement(DownloadsPageconstants.sort_title_asc);
		Verify_Alphabatic_Order("//div[@class='tile__text-title']");
		return this;

	}

	public  Downloads_Page Verify_Result_Tile() throws InterruptedException {
		if(DownloadsPageconstants.Item_Tile.isDisplayed())
		{
			logger("Verification: Tites are displayed", Status.PASS);
		}
		else {
			logger("Verification: Tiles are not displayed", Status.FAIL);
		}
		return this;
	}

	public  Downloads_Page Verify_Result_Tile_Content() throws InterruptedException {
		if(DownloadsPageconstants.Tile_title.isDisplayed())
		{
			logger("Verification: Tile Title is displayed", Status.PASS);

			if(DownloadsPageconstants.Tile_image.isDisplayed())
			{ 
				logger("Verification: Tile image is displayed", Status.PASS);


				if(DownloadsPageconstants.Tile_description.isDisplayed())
				{ 
					logger("Verification: Tile description is displayed", Status.PASS);

				}
			}
		}

		else 
		{
			loggerWithScreenshot("Verification: Issue with tiles", "", Status.FAIL, true);
		}

		return this;
	}


	public  Downloads_Page Verify_wholeItemClickable()
	{
		VerifyElementIsClickable("(//li[@class='tile  clearfix  '])[1]");
		return this;

	}
	
	public  Downloads_Page Click_Downloaditem()
	{
		WebElement downloaditem = driver.findElement(By.xpath("(//li[@class='tile  clearfix  '])[1]"));
		clickWebElement(downloaditem);
		return this;

	}
	
	public  Downloads_Page Verify_Pagination() throws InterruptedException {
		if(DownloadsPageconstants.pagination.isDisplayed())
		{
			logger("Verification: Pagination are displayed", Status.PASS);
		}

		else {
			logger("Verification: Pagination are not displayed", Status.FAIL);
		}
		return this;
	}

}
