package test.automation.pages;

import java.io.IOException;

import org.openqa.selenium.support.PageFactory;

import com.aventstack.extentreports.Status;

import test.automation.globalfunctionality.TestCaseInitiator;
import test.automation.pagelocators.Loginconstants;
import test.automation.umbraco.pagelocators.UmbracoPageConstants;
import test.automation.umbraco.pages.UmbracoPage;

public class Login_Page extends TestCaseInitiator {
	
	

	public Login_Page() {
		PageFactory.initElements(driver, Loginconstants.class);
	}
	
	/** Secure Login Danoss.com with Access Token
	 * @param token
	 * @return 
	 * @return 
	 * @return
	 * @throws InterruptedException
	 * @throws IOException
	 */
	
	public Login_Page Clickadvance() {
		clickWithScreenshot(Loginconstants.advanceXpath);
		return this;
	}
	
	public  Login_Page ClickProceed() {
		clickWithScreenshot(Loginconstants.proceedlink);
		return this;
	}
	
	public  Login_Page EnterToken(String token) {
		
		  if(url.equalsIgnoreCase("https://danfoss-webex-staging.trafficmanager.net/"))
		  { enterText(Loginconstants.tokenInput, token); } else {
		  logger("Info: Enter Token page is not appear, script is running in "
		  +url+" url", Status.INFO); }
		 
		return this;
	}
	
	public Home_Page ClickApplyAccess() {
		
		  if(url.equalsIgnoreCase("https://danfoss-webex-staging.trafficmanager.net/"))
		  { clickWebElement(Loginconstants.accessLoginButton); }
		 
		return new Home_Page();
		
	}
	
	public UmbracoPage Click_SignIn_Umbraco() {
		clickWebElement(Loginconstants.signIn);
		return new UmbracoPage();
	}
	
	public UmbracoPage Enter_Username_Umbraco() {
		enterText(Loginconstants.Umb_Username, "vigneshselvam");
		return new UmbracoPage();
	}
	
		
}


