package test.automation.pages;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.PageFactory;

import com.aventstack.extentreports.Status;

import test.automation.pages.Casestudies_Page;
import test.automation.globalfunctionality.TestCaseInitiator;
import test.automation.pagelocators.CaseStudiesPageconstants;
import test.automation.pagelocators.HomePageconstants;
import test.automation.pagelocators.NewsPageconstants;


public class Casestudies_Page extends TestCaseInitiator {

	public Casestudies_Page() {
		PageFactory.initElements(driver, CaseStudiesPageconstants.class);
	}

	public  Casestudies_Page VerifyCasestudiestitle() throws InterruptedException {
		verifyPageTitle("Case stories | Danfoss");
		return this;
	}


	public Home_Page Navigate_homepage() {

		HomePageconstants.titleImage.click();
		return new Home_Page();

	}

	public  Casestudies_Page Click_Business_filter(String str) throws InterruptedException {
		dynamicElementselector("((//div[contains(@class,'filters-group__items-wrapper ')])[2]//descendant::span[@class='filters-group__item__title'])", str);
		return this;
	}
	
	public  Casestudies_Page Verify_Business_filtervalue(String str) throws InterruptedException {
		dynamicElementDisplayed("(//div[@class='filters-group__items-wrapper'])[2]//descendant::span[@class='filters-group__item__title']", str);
		
		return this;
	}
	
	public  Casestudies_Page Click_Market_Filter() throws InterruptedException {
		clickWebElement(CaseStudiesPageconstants.Market_filter);
		return this;
	}
	
	public  Casestudies_Page Click_Market_filtervalue(String str) throws InterruptedException {
		Thread.sleep(3000);
		dynamicElementselector("(//div[@class='filters-group '])[2]//descendant::span[@class='filters-group__item__title']", str);
		return this;
	}

	public  Casestudies_Page Click_Application_filter(String str) throws InterruptedException {

		dynamicElementselector("//div[text()='Applications']//following::span[@class='filters-group__item__title']", str);
		return this;
	}

	public  Casestudies_Page Verify_Url(String str1) throws InterruptedException {
		verifyElementEnabled(CaseStudiesPageconstants.clear_filter);
		if(driver.getCurrentUrl().contains(str1))
		{
			logger("Verification: Selected Filter is updated in the URL" , Status.PASS);
		}
		else
		{
			logger("Verification: URL does not contain filters" , Status.FAIL);
		}
		return this;
	}

	public  Casestudies_Page Verify_Url_NoFilter(String str1) throws InterruptedException {
		Thread.sleep(6000);
		if(!driver.getCurrentUrl().contains(str1))
		{
			logger("Verification: Filter are not available in updated URL" , Status.PASS);
		}
		else
		{
			logger("Verification: Filter are available in updated URL" , Status.FAIL);
		}
		return this;
	}

	public  Casestudies_Page Verify_clear_filter() throws InterruptedException {
		verifyElementDisplayed(CaseStudiesPageconstants.clear_filter);
		return this;
	}

	public  Casestudies_Page Click_Clear_filter() throws InterruptedException {
		MoveToElement(CaseStudiesPageconstants.clear_filter);
		clickWebElement(CaseStudiesPageconstants.clear_filter);
		return this;
	}
	public  Casestudies_Page Verify_No_clear_filter() throws InterruptedException {
		verifyElementNotDisplayed("//button[contains(@class,'reset-filter-button')]//descendant::span[@class='cta-content-text']");
		return this;
	}

	public  Casestudies_Page Verify_product_Count() throws InterruptedException {
		Thread.sleep(2000);
		String text = CaseStudiesPageconstants.numberofresult.getText();
		//String substring = text.substring(text.indexOf(':'), text.lastIndexOf(text)-1);
		logger("Information:  "+text , Status.INFO);
		return this;
	}

	public  Casestudies_Page Open_Url_NewTab() throws InterruptedException {

		openLinkInNewTab(driver.getCurrentUrl());
		loggerWithScreenshot("Verfication: URL is opened in new Window with same filters", "", Status.PASS, true);
		return this;
	}

	public  Casestudies_Page Verify_Filter_Section() throws InterruptedException {
		if(CaseStudiesPageconstants.filter.isDisplayed())
		{
			logger("Verification: Filter section is displayed", Status.PASS);
		}
		else
		{
			logger("Verification: Filter section is not displayed", Status.FAIL);
		}
		return this;
	}

	public  Casestudies_Page Verify_Breadcrumbs() throws InterruptedException {
		if(CaseStudiesPageconstants.breadcrumbs.isDisplayed())
		{
			logger("Verification: Breadcrumnb is displayed", Status.PASS);
		}
		else
		{
			logger("Verification: Breadcrumnb is not displayed", Status.FAIL);
		}
		return this;
	}

	public  Casestudies_Page Verify_Page_heading() throws InterruptedException {
		if(verifyElementDisplayed(CaseStudiesPageconstants.Page_heading))
		{
			logger("Verification: Page title is displayed in H1 format in top of the page", Status.PASS);
		}

		else
		{
			logger("\"Verification: Page title is not displayed in H1 format in top of the page", Status.FAIL);
		}
		return this;

	}


	public  Casestudies_Page Verify_Result_Tile() throws InterruptedException {
		if(CaseStudiesPageconstants.Item_Tile.isDisplayed())
		{
			logger("Verification: Tites are displayed", Status.PASS);
		}

		else {
			logger("Verification: Tiles are not displayed", Status.FAIL);
		}
		return this;
	}

	public  Casestudies_Page Verify_Result_Tile_Content() throws InterruptedException {
		if(CaseStudiesPageconstants.Tile_title.isDisplayed())
		{
			logger("Verification: Tile Title is displayed", Status.PASS);

			if(CaseStudiesPageconstants.Tile_image.isDisplayed())
			{ 
				logger("Verification: Tile image is displayed", Status.PASS);


				if(CaseStudiesPageconstants.Tile_description.isDisplayed())
				{ 
					logger("Verification: Tile description is displayed", Status.PASS);


					if(CaseStudiesPageconstants.Tile_date.isDisplayed())
					{ 
						logger("Verification: Tile date is displayed", Status.PASS);

					}
				}
			}
		}
		
		else 
		{
			loggerWithScreenshot("Verification: Issue with tiles", "", Status.FAIL, true);
		}

		return this;
	}


	public  Casestudies_Page Verify_Pagination() throws InterruptedException {
		if(CaseStudiesPageconstants.pagination.isDisplayed())
		{
			logger("Verification: Pagination are displayed", Status.PASS);
		}

		else {
			logger("Verification: Pagination are not displayed", Status.FAIL);
		}
		return this;
	}
	public  Casestudies_Page Verify_Markets_filter() throws InterruptedException {
		verifyElementDisplayed(CaseStudiesPageconstants.Market_filter);
		if(CaseStudiesPageconstants.Market_filters_collapsed.isDisplayed())
		{
			logger("Verification: Market filter is collapsed by default and Arrow is pointed down", Status.PASS);
		}
		else
		{
			logger("Verification: Market filter is not collapsed ", Status.FAIL);
		}
		return this;
	}
	
	
	public  Casestudies_Page Click_Application_filter() throws InterruptedException {
		driver.findElement(By.xpath("(//div[@class='filters-group__heading'])[4]//child::span")).click();
		Thread.sleep(2000);
		return this;
	}


	public  Casestudies_Page Verify_Business_filter() throws InterruptedException {

		if(dynamicElementDisplayed("(//div[@class='filters-group__heading'])[1]", "Business unit"))

		{
			logger("Verification: Business filter is expanded by default and Arrow is pointed up", Status.PASS);
		}
		else
		{
			logger("Verification: Business filter is not expanded ", Status.FAIL);
		}
		return this;
	}

	public  Casestudies_Page Verify_Solutions_filter() throws InterruptedException {
		verifyElementDisplayed(CaseStudiesPageconstants.Solutions_filter);
		if(CaseStudiesPageconstants.Solution_filters_collapsed.isDisplayed())
		{
			logger("Verification: Solutions filter is collapsed by default and Arrow is pointed down", Status.PASS);
		}
		else
		{
			logger("Verification: Solutions filter is not collapsed ", Status.FAIL);
		}
		return this;
	}

	public  Casestudies_Page Verify_Applications_filter() throws InterruptedException {
		verifyElementDisplayed(CaseStudiesPageconstants.Applications_filter);
		if(CaseStudiesPageconstants.Application_filters_collapsed.isDisplayed())
		{
			logger("Verification: Applications filter is collapsed by default and Arrow is pointed down", Status.PASS);
		}
		else
		{
			logger("Verification: Applications filter is not collapsed ", Status.FAIL);
		}
		return this;
	}

	public  Casestudies_Page Verify_Megatrends_filter() throws InterruptedException {
		verifyElementDisplayed(CaseStudiesPageconstants.Megatrends_filter);
		if(CaseStudiesPageconstants.Market_filters_collapsed.isDisplayed())
		{
			logger("Verification: Applications filter is collapsed by default and Arrow is pointed down", Status.PASS);
		}
		else
		{
			logger("Verification: Applications filter is not collapsed ", Status.FAIL);
		}
		return this;
	}
	public  Casestudies_Page Verify_Alphaticalorder_Filteroptions() throws InterruptedException {
		logger("Below steps will check filter values in each filters are arranged in alphabatical order", Status.INFO);
		Verify_Alphabatic_Order("(//div[contains(@class,'filters-group__items-wrapper')])[1]//descendant::span[@class='filters-group__item__title']");
		Verify_Alphabatic_Order("(//div[contains(@class,'filters-group__items-wrapper')])[2]//descendant::span[@class='filters-group__item__title']");
		Verify_Alphabatic_Order("(//div[contains(@class,'filters-group__items-wrapper')])[3]//descendant::span[@class='filters-group__item__title']");
		Verify_Alphabatic_Order("(//div[contains(@class,'filters-group__items-wrapper')])[4]//descendant::span[@class='filters-group__item__title']");
		Verify_Alphabatic_Order("(//div[contains(@class,'filters-group__items-wrapper')])[5]//descendant::span[@class='filters-group__item__title']");

		return this;

	}

	public  Casestudies_Page Verify_FilterisSelected(String str) throws InterruptedException {
		if(dynamicElementDisplayed("//span[contains(text(),'Climate Solutions for cooling')]", str));
		{
			logger("Verification: "+str+ " is selected", Status.PASS);

		}
		return this;
	}


	public  Casestudies_Page Verify_Highlighted_filterValues() throws InterruptedException {
		WebElement element = driver.findElement(By.xpath("((//div[contains(@class,'filters-group__items-wrapper ')])[2]//descendant::span[@class='filters-group__item__title'])[1]"));
		VerifyElementIsHighlighted(element);
		return this;
	}

	public  Casestudies_Page Verify_SelectedFilter_In_Applied(String str) throws InterruptedException {
	
		WebElement ele = driver.findElement(By.xpath("//span[contains(text(),'Climate Solutions for cooling')]"));
		String text = ele.getText();
		if(text.contains(str))

		{
			logger("Verification: "+str+ " is added in the applied filter section", Status.PASS);
			ele.click();
			if(CaseStudiesPageconstants.Applied_filter_close.isDisplayed())
			{
				logger("Verification: "+str+ " contains close button", Status.PASS);

			}
			else {
				logger("Verification: "+str+ " not contains close button", Status.FAIL);
			}
		}
		else {

			logger("Verification: "+str+ "is not added in the applied filter section", Status.FAIL);

		}

		return this;
	}


	public  Casestudies_Page Verify_Highlighted_AppliedFilter() throws InterruptedException {
		WebElement ele = driver.findElement(By.xpath("(//div[@class='unselect-buttons-group']//descendant::span[@class='cta__content-text'])[1]"));
		VerifyElementIsHighlighted(ele);
		return this;
	}


	public  Casestudies_Page Deselect_Filters() throws InterruptedException {
		try {
			List<WebElement> findElementsByXPath = driver.findElements(By.xpath("//div[@class='unselect-buttons-group']//descendant::span[@class='icon icon-cancel']"));
			for (int i = 0; i < findElementsByXPath.size(); i++) {
				findElementsByXPath.get(i).click();
			}
			Thread.sleep(2000);
			loggerWithScreenshot("Verification: Filters are removed in applied filter and also it filter section", "", Status.PASS, true);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		return this;
	}

	public  Casestudies_Page Verify_SortButton_withoptions() throws InterruptedException {
		verifyElementDisplayed(CaseStudiesPageconstants.sort_button);
		Thread.sleep(2000);
		scrollTopOfPageJS();
		driver.findElement(By.xpath("//select[@class='sort-select cta cta--small cta--block']")).click();
		verifyElementDisplayed(CaseStudiesPageconstants.sort_startdate_asc);
		if(CaseStudiesPageconstants.sort_startdate_desc.isDisplayed())
		{
			loggerWithScreenshot("Verification: The element Date (old first) is displayed and it is Default value", "", Status.PASS, true);
		}
		verifyElementDisplayed(CaseStudiesPageconstants.sort_title_asc);
		verifyElementDisplayed(CaseStudiesPageconstants.sort_title_desc);

		return this;
	}

	public  Casestudies_Page Verify_items_AscendingOrder()

	{
		clickWebElement(CaseStudiesPageconstants.sort_title_asc);
		Verify_Alphabatic_Order("//div[@class='tile__text-title']");
		return this;

	}
	
	
	public  Casestudies_Page Verify_Show_More_button()

	{
		verifyElementDisplayed(CaseStudiesPageconstants.products_show_more);
		verifyElementDisplayed(CaseStudiesPageconstants.products_show_more_count);
		return this;

	}
	
	public  Casestudies_Page Click_Show_More_button()

	{
		clickWebElement(CaseStudiesPageconstants.products_show_more);
		return this;

	}
	
	public  Casestudies_Page Verify_Show_less_button()

	{
		if(verifyElementDisplayed(CaseStudiesPageconstants.products_show_more))
		{
			logger("Verification: All filter options are expanded", Status.PASS);
		}
		
		return this;

	}
	
	public  Casestudies_Page Click_Show_lessbutton()

	{
		try {
			clickWebElement(CaseStudiesPageconstants.products_show_more);
			
			logger("verification: All filter are collapsed to two rows", Status.PASS);
			verifyElementDisplayed(CaseStudiesPageconstants.products_show_more);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		return this;

	}
}