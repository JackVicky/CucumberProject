package test.automation.pages;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;

import org.openqa.selenium.WebElement;

import org.openqa.selenium.support.PageFactory;

import com.aventstack.extentreports.Status;

import test.automation.functions.PageActions;
import test.automation.globalfunctionality.TestCaseInitiator;
import test.automation.pagelocators.ContactusPageConstants;
import test.automation.pagelocators.HomePageconstants;


public class Contact_Us_Page extends TestCaseInitiator {

	public Contact_Us_Page() {
		PageFactory.initElements(driver, ContactusPageConstants.class);
	}

	public Home_Page Click_CloseButton() {
		ContactusPageConstants.close_button.click();
		return new Home_Page();
	}

	public Contact_Us_Page Click_CloseButton_Details() throws InterruptedException {
		Thread.sleep(3000);
		ContactusPageConstants.contact_details_view_close.click();
		return this;
	}

	public Contact_Us_Page Verify_Danfoss_sales_services_title() {
		verifyElementDisplayed(ContactusPageConstants.Danfoss_sales_services_tile);
		return this;
	}

	public Contact_Us_Page Click_Danfoss_sales_services_title() {
		clickWebElement(ContactusPageConstants.Danfoss_sales_services_tile);
		return this;
	}

	public Contact_Us_Page Verify_Danfoss_customer_service_center_tile() {
		verifyElementDisplayed(ContactusPageConstants.Danfoss_Customer_service_center_tile);
		return this;
	}

	public Contact_Us_Page Click_Danfoss_customer_service_center_tile() {
		clickWebElement(ContactusPageConstants.Danfoss_Customer_service_center_tile);
		return this;
	}

	public Contact_Us_Page Verify_Danfoss_distributors_service_partners_tile() {
		verifyElementDisplayed(ContactusPageConstants.Danfoss_Distributors_service_partners_tile);
		return this;
	}

	public Contact_Us_Page Click_Danfoss_distributors_service_partners_tile() {

		MoveToElement(ContactusPageConstants.Danfoss_Distributors_service_partners_tile);
		clickWebElement(ContactusPageConstants.Danfoss_Distributors_service_partners_tile);
		return this;
	}

	public Contact_Us_Page Verify_Danfoss_factories() {
		verifyElementDisplayed(ContactusPageConstants.Danfoss_factories);
		return this;
	}

	public Contact_Us_Page Verify_Danfoss_Headquarters() {
		verifyElementDisplayed(ContactusPageConstants.Danfoss_headquarters);
		return this;
	}

	public Contact_Us_Page Verify_Danfoss_Sales_service() {
		verifyElementDisplayed(ContactusPageConstants.Danfoss_sales_services);
		return this;
	}

	public Contact_Us_Page Verify_Danfoss_Distributer() {
		verifyElementDisplayed(ContactusPageConstants.Distributors);
		return this;
	}

	public Contact_Us_Page Click_Danfoss_Sales_service() throws InterruptedException {
		MoveToElement(ContactusPageConstants.Danfoss_sales_services);
		clickWebElement(ContactusPageConstants.Danfoss_sales_services);
		Thread.sleep(2000);
		return this;
	}

	public Contact_Us_Page Click_Danfoss_Distributer() throws InterruptedException {
		MoveToElement(ContactusPageConstants.Distributors);
		clickWebElement(ContactusPageConstants.Distributors);
		Thread.sleep(2000);
		return this;
	}

	public Contact_Us_Page Click_Looking_For_Distributers() throws InterruptedException{
		MoveToElement(ContactusPageConstants.LookingForDistributors);
		Thread.sleep(3000);
		clickJSWebElement(ContactusPageConstants.LookingForDistributors);
		switch_To_New_Window();
		Thread.sleep(2000);
		return this;
	}

	public Contact_Us_Page Click_Danfoss_Distributer_zh_cn() throws InterruptedException {
		MoveToElement(ContactusPageConstants.Distributors_zh_cn);
		clickWebElement(ContactusPageConstants.Distributors_zh_cn);
		Thread.sleep(2000);
		return this;
	}

	public Contact_Us_Page Click_Danfoss_sales_service_zh_cn() throws InterruptedException {
		MoveToElement(ContactusPageConstants.sales_service_zh_cn);
		clickWebElement(ContactusPageConstants.sales_service_zh_cn);
		Thread.sleep(3000);
		//driver.findElement(By.xpath("(//button[contains(@onclick,'CookieInformation.submitAll')])[1]")).click();
		if(VerifyElementIsClickableForAlert(HomePageconstants.acceptcookies)){
			clickWebElement(HomePageconstants.acceptcookies);	
			logger("INFO: Accept cookie pop-up is appear" , Status.INFO);
		}	
		else {
			logger("INFO: Accept cookie pop-up is not appear" , Status.INFO);
		}
		return this;
	}
	public Contact_Us_Page Click_Danfoss_Headquarters() {
		clickWebElement(ContactusPageConstants.Danfoss_headquarters);
		return this;
	}

	public Contact_Us_Page Verify_Danfoss_ServicePartner() {
		verifyElementDisplayed(ContactusPageConstants.Service_partners);
		return this;
	}

	public Contact_Us_Page Verify_Danfoss_overview() {
		verifyElementDisplayed(ContactusPageConstants.overview_link);
		return this;
	}

	public Contact_Us_Page Verify_Close() {
		ContactusPageConstants.close_button.isDisplayed();
		logger("Verification: Close Button is displayed", Status.PASS);
		return this;
	}

	public Contact_Us_Page Verify_Breadcrumbs() {
		if (ContactusPageConstants.breadcrumbs_homepage.isDisplayed())
			;
		{
			logger("Verification: Breadcrumb " + ContactusPageConstants.breadcrumbs_homepage.getText()
			+ " is displayed", Status.PASS);
		}

		if (ContactusPageConstants.breadcrumbs_contactus.isDisplayed())
			;
		{
			logger("Verification: Breadcrumb " + ContactusPageConstants.breadcrumbs_contactus.getText()
			+ " is displayed", Status.PASS);
		}

		return this;
	}

	public Contact_Us_Page Verify_StaticHeader() {
		verifyElementDisplayed(ContactusPageConstants.Static_description);
		return this;
	}

	public Contact_Us_Page Verify_Page_Title() throws InterruptedException {
		verifyPageTitle("Contacts list | Danfoss");
		return this;
	}

	public Contact_Us_Page Verify_Filter_section() {
		if (ContactusPageConstants.filter_section.isDisplayed())

		{
			logger("Verification: Filter section is displayed", Status.PASS);
		}
		return this;
	}

	public Contact_Us_Page Verify_Contact_list_section() throws InterruptedException {
		Thread.sleep(1000);
		if (ContactusPageConstants.contact_list_section.isDisplayed())
			;
		{
			logger("Verification: Contact list section is displayed", Status.PASS);
		}
		return this;
	}

	public Contact_Us_Page Verify_Map() {
		if (ContactusPageConstants.google_map.isDisplayed())
			;
		{
			logger("Verification: Google Map is displayed", Status.PASS);
		}
		return this;
	}

	public Contact_Us_Page Verify_Location_Inputbox() throws InterruptedException {
		Thread.sleep(2000);
		if (ContactusPageConstants.Location_inputbox.isDisplayed());
		{
			logger("Verification: Location input box is displayed", Status.PASS);
		}
		return this;
	}

	public Contact_Us_Page Verify_Location_Inputbox_zh_cn() {
		if (ContactusPageConstants.Location_inputbox_zh_cn.isDisplayed())
			;
		{
			logger("Verification: Location input box is displayed", Status.PASS);
		}
		return this;
	}

	public Contact_Us_Page EnterText_Location(String toEnter) throws InterruptedException {
		if(VerifyElementIsClickableForAlert(HomePageconstants.acceptcookies)){
			clickWebElement(HomePageconstants.acceptcookies);	
			logger("INFO: Accept cookie pop-up is appear" , Status.INFO);
		}	
		else {
			logger("INFO: Accept cookie pop-up is not appear" , Status.INFO);
		}
		enterText(ContactusPageConstants.Location_inputbox, toEnter);
		ContactusPageConstants.Location_inputbox.sendKeys(Keys.ENTER);
		Thread.sleep(2000);
		ContactusPageConstants.Static_description.click();
		Thread.sleep(1000);
		return this;
	}
	
	public Contact_Us_Page EnterText_China_Location_AutoSuggest(String toEnter) throws InterruptedException {
		//ContactusPageConstants.Location_inputbox.sendKeys(toEnter);
		System.out.println(toEnter + " text to enter in china location textbox");
		enterText(ContactusPageConstants.Location_inputbox_zh_cn, toEnter);
		Thread.sleep(3000);
		loggerWithScreenshot("Verification: Autosuggest options are displayed", "", Status.PASS, true);
		ContactusPageConstants.Location_inputbox_zh_cn.sendKeys(Keys.DOWN);
		Thread.sleep(250);
		ContactusPageConstants.Location_inputbox_zh_cn.sendKeys(Keys.DOWN);
		Thread.sleep(250);
		ContactusPageConstants.Location_inputbox_zh_cn.sendKeys(Keys.DOWN);
		Thread.sleep(250);
		ContactusPageConstants.Location_inputbox_zh_cn.sendKeys(Keys.DOWN);
		Thread.sleep(250);
		ContactusPageConstants.Location_inputbox_zh_cn.sendKeys(Keys.DOWN);
		Thread.sleep(250);
		ContactusPageConstants.Location_inputbox_zh_cn.sendKeys(Keys.DOWN);
		Thread.sleep(250);
		ContactusPageConstants.Location_inputbox_zh_cn.sendKeys(Keys.ESCAPE);
		Thread.sleep(1000);

		return this;
	}

	public Contact_Us_Page EnterText_Location_AutoSuggest(String toEnter) throws InterruptedException {
		if(HomePageconstants.acceptcookies.isDisplayed()==Boolean.TRUE){
			clickWebElement(HomePageconstants.acceptcookies);	
			logger("INFO: Accept cookie pop-up is appear" , Status.INFO);
		}	
		else {
			logger("INFO: Accept cookie pop-up is not appear" , Status.INFO);
		}
		//ContactusPageConstants.Location_inputbox.sendKeys(toEnter);
		System.out.println(toEnter + " text to enter in china location textbox");
		enterText(ContactusPageConstants.Location_inputbox, toEnter);
		Thread.sleep(3000);
		loggerWithScreenshot("Verification: Autosuggest options are displayed", "", Status.PASS, true);
		ContactusPageConstants.Location_inputbox.sendKeys(Keys.DOWN);
		Thread.sleep(250);
		ContactusPageConstants.Location_inputbox.sendKeys(Keys.DOWN);
		Thread.sleep(250);
		ContactusPageConstants.Location_inputbox.sendKeys(Keys.DOWN);
		Thread.sleep(250);
		ContactusPageConstants.Location_inputbox.sendKeys(Keys.DOWN);
		Thread.sleep(250);
		ContactusPageConstants.Location_inputbox.sendKeys(Keys.DOWN);
		Thread.sleep(250);
		ContactusPageConstants.Location_inputbox.sendKeys(Keys.DOWN);
		Thread.sleep(250);
		ContactusPageConstants.Location_inputbox.sendKeys(Keys.ESCAPE);
		Thread.sleep(1000);

		return this;
	}

	public Contact_Us_Page Select_AutoSuggest(String toEnter) throws InterruptedException {
		enterText(ContactusPageConstants.Location_inputbox, toEnter);
		Thread.sleep(3000);
		ContactusPageConstants.Location_inputbox.sendKeys(Keys.DOWN);
		Thread.sleep(250);
		ContactusPageConstants.Location_inputbox.sendKeys(Keys.ENTER);
		return this;
	}

	public Contact_Us_Page EnterOn_AutoSuggest(String toEnter) throws InterruptedException {
		enterText(ContactusPageConstants.Location_inputbox, toEnter);
		Thread.sleep(2000);
		ContactusPageConstants.Location_inputbox.sendKeys(Keys.ENTER);
		Thread.sleep(1000);
		ContactusPageConstants.Location_inputbox.sendKeys(Keys.ESCAPE);
		return this;
	}

	public Contact_Us_Page Close_AutoSuggest(String toEnter) throws InterruptedException {
		enterText(ContactusPageConstants.Location_inputbox, toEnter);
		Thread.sleep(3000);
		ContactusPageConstants.Location_inputbox.sendKeys(Keys.ESCAPE);
		logger("Verification: Autosuggestions are closed", Status.PASS);
		Thread.sleep(1000);
		return this;
	}

	public Contact_Us_Page Clear_Location() throws InterruptedException {
		//ContactusPageConstants.Location_inputbox.sendKeys(Keys.CONTROL, "a", Keys.DELETE);
		//ContactusPageConstants.Location_inputbox.sendKeys(Keys.ENTER);
		ContactusPageConstants.Location_inputbox.clear();
		Thread.sleep(2000);
		logger("Text in Location input box is cleared", Status.INFO);
		return this;
	}

	List<WebElement> Business_filter_intial = null;
	List<WebElement> Business_filter_Alter1 = null;
	List<WebElement> Business_filter_Alter2 = null;

	List<WebElement> Type_filter_intial = null;
	List<WebElement> Type_filter_Alter1 = null;
	List<WebElement> Type_filter_Alter2 = null;

	public Contact_Us_Page Verify_Business_filter() {
		verifyElementDisplayed(ContactusPageConstants.Business_unit_filter);
		ContactusPageConstants.Business_unit_filter.click();
		if (ContactusPageConstants.Multiple_selection.isDisplayed())
			;
		{
			logger("Verification: Business unit filter contains multiple selection options", Status.PASS);
		}
		Business_filter_intial = driver.findElements(By.xpath("//span[@class='multiselect-option-checkbox']//following-sibling::label"));
		System.out.println(Business_filter_intial.get(0).getText());
		System.out.println(Business_filter_intial.get(1).getText());
		ContactusPageConstants.Business_unit_filter.click();
		return this;
	}

	public Contact_Us_Page Verify_Type_filter() {
		verifyElementDisplayed(ContactusPageConstants.contact_type_fiter);
		ContactusPageConstants.contact_type_fiter.click();
		if (ContactusPageConstants.Multiple_selection.isDisplayed())
			;
		{
			logger("Verification: Contact type filter contains multiple selection options", Status.PASS);
		}
		Type_filter_intial = driver.findElements(By.xpath("//span[@class='multiselect-option-checkbox']//following-sibling::label"));
		System.out.println(Type_filter_intial.get(0).getText());
		System.out.println(Type_filter_intial.get(1).getText());
		ContactusPageConstants.contact_type_fiter.click();
		return this;
	}

	public Contact_Us_Page Verify_Altered_Business_filter1() throws InterruptedException {

		Thread.sleep(3000);
		VerifyElementIsClickable(ContactusPageConstants.Business_unit_filter);
		ContactusPageConstants.Business_unit_filter.click();
		Business_filter_Alter1 = driver.findElements(By.xpath("//span[@class='multiselect-option-checkbox']//following-sibling::label"));
		// System.out.println(Business_filter_updated_values.get(1));
		if (Business_filter_Alter1.equals(Business_filter_intial)) {
			logger("Verification: Business unit filter is not altered", Status.FAIL);
		} else {
			logger("Verification: Business unit filter is altered", Status.PASS);
		}
		ContactusPageConstants.Business_unit_filter.click();
		return this;
	}

	public Contact_Us_Page Verify_Altered_Type_filter1() {

		ContactusPageConstants.contact_type_fiter.click();
		Type_filter_Alter1 = driver.findElements(By.xpath("//span[@class='multiselect-option-checkbox']//following-sibling::label"));
		// System.out.println(Business_filter_updated_values.get(1));
		if (Type_filter_Alter1.equals(Type_filter_intial)) {
			logger("Verification: Contact Type filter is not altered", Status.FAIL);
		} else {
			logger("Verification: Contact Type filter is altered", Status.PASS);
		}
		ContactusPageConstants.contact_type_fiter.click();
		return this;
	}

	public Contact_Us_Page Verify_Altered_Business_filter2() throws InterruptedException {
		Thread.sleep(3000);
		ContactusPageConstants.Business_unit_filter.click();
		//ContactusPageConstants.Business_unit_filter_arrow.click();
		Business_filter_Alter2 = driver.findElements(By.xpath("//span[@class='multiselect-option-checkbox']//following-sibling::label"));

		// System.out.println(Business_filter_updated_values.get(1));
		if (Business_filter_Alter2.equals(Business_filter_Alter1)) {
			logger("Verification: Business unit filter is not altered", Status.FAIL);
		} else {
			logger("Verification: Business unit filter is altered", Status.PASS);
		}
		ContactusPageConstants.Business_unit_filter.click();
		return this;
	}

	public Contact_Us_Page Verify_Altered_Type_filter2() {

		ContactusPageConstants.contact_type_fiter1.click();
		Type_filter_Alter2 = driver.findElements(By.xpath("//span[@class='multiselect-option-checkbox']//following-sibling::label"));
		// System.out.println(Business_filter_updated_values.get(1));
		if (Type_filter_Alter2.equals(Type_filter_Alter1)) {
			logger("Verification: Contact type filter is not altered", Status.FAIL);
		} else {
			logger("Verification: Contact type filter is altered", Status.PASS);
		}
		ContactusPageConstants.contact_type_fiter1.click();
		return this;
	}

	public Contact_Us_Page Verify_Contact_type_filter() throws InterruptedException {
		verifyElementDisplayed(ContactusPageConstants.contact_type_fiter);
		clickWebElement(ContactusPageConstants.contact_type_fiter);
		if (ContactusPageConstants.Multiple_selection.isDisplayed())

		{
			logger("Verification: Contact type filter contains multiple selection options", Status.PASS);
		}
		Thread.sleep(1000);
		ContactusPageConstants.contact_type_fiter.click();
		return this;
	}

	public Contact_Us_Page Verify_Contact_type_filter_new() throws InterruptedException {
		WebElement ct = driver.findElement(By.xpath("//*[contains(text(),'Type')][contains(@class,'dropdown-multi-values')]"));
		verifyElementDisplayed(ct);
		ct.click();
		if (ContactusPageConstants.Multiple_selection.isDisplayed())

		{
			logger("Verification: Contact type filter contains multiple selection options", Status.PASS);
		}
		Thread.sleep(1000);
		ct.click();
		return this;
	}

	public Contact_Us_Page Select_Required_type_Filter(String filteroption) throws InterruptedException {
		Thread.sleep(5000);
		clickWebElement(ContactusPageConstants.contact_list_filter_arrow);//contact_type_filter
		WebElement Filter_Option = driver
				.findElement(By.xpath("//span[@class='multiselect-option-checkbox']//following-sibling::label[text()='"
						+ filteroption + "']"));

		if (Filter_Option.isDisplayed())
			;
		{
			logger("Verification: " + Filter_Option.getText() + " Contact type is available in the list", Status.PASS);
		}
		clickWebElement(Filter_Option);
		ContactusPageConstants.contact_type_fiter1.click();
		return this;
	}

	public Contact_Us_Page Select_Required_type_Filter2(String filteroption) throws InterruptedException {
		Thread.sleep(3000);
		//ContactusPageConstants.contact_type_fiter.click();
		VerifyElementIsClickable(ContactusPageConstants.contact_type_fiter1);
		ContactusPageConstants.contact_type_fiter1.click();
		WebElement Filter_Option = driver
				.findElement(By.xpath("//span[@class='multiselect-option-checkbox']//following-sibling::label[text()='"
						+ filteroption + "']"));

		if (Filter_Option.isDisplayed())
			;
		{
			logger("Verification: " + Filter_Option.getText() + " Contact type is available in the list", Status.PASS);
		}
		clickWebElement(Filter_Option);
		Thread.sleep(2000);
		driver.findElement(By.xpath("(//div[contains(@class,'dropdown-multi-values__indicator')])[3]")).click();
		return this;
	}

	public Contact_Us_Page Verify_Disabled_filter_option() throws Exception {
		Thread.sleep(3000);
		if (ContactusPageConstants.disabled_filter_option.isDisplayed()) {
			logger("Verification: Selected filter option is disabled", Status.PASS);
		}

		return this;
	}

	public Contact_Us_Page Click_Contact_type_filter() throws InterruptedException {
		clickWebElement(ContactusPageConstants.contact_list_filter_arrow);
		Thread.sleep(5000);
		return this;
	}

	public Contact_Us_Page Click_Business_filter() {
		clickWebElement(ContactusPageConstants.Business_unit_filter);
		return this;
	}

	public Contact_Us_Page Click_Business_filter_arrow() {
		clickWebElement(ContactusPageConstants.Business_unit_filter_arrow);
		return this;
	}

	public Contact_Us_Page Click_type_reset() {
		clickWithScreenshot(ContactusPageConstants.contact_type_reset);
		List<WebElement> Selected_option = driver.findElements(By.xpath("//div[contains(@class,'option--is-selected')]"));
		
		if (Selected_option.size() == 0) {
			logger("Verification: Selected Values are cleared", Status.PASS);
		} else {
			logger("Verification: Selected Values are not cleared", Status.FAIL);
		}
		return this;
	}

	public Contact_Us_Page Click_Business_reset() {
		clickWithScreenshot(ContactusPageConstants.Business_filter_reset);
		List<WebElement> Selected_option = driver.findElements(By.xpath("//div[contains(@class,'option--is-selected')]"));

		if (Selected_option.size() == 0) {
			logger("Verification: Selected Values are cleared", Status.PASS);
		} else {
			logger("Verification: Selected Values are not cleared", Status.FAIL);
		}
		return this;
	}

	public Contact_Us_Page Click_Business_reset_new() {
		Click_Business_filter_arrow();
		clickWithScreenshot(ContactusPageConstants.Business_filter_reset);
		List<WebElement> Selected_option = driver.findElements(By.xpath("//div[contains(@class,'option--is-selected')]"));

		if (Selected_option.size() == 0) {
			logger("Verification: Selected Values are cleared", Status.PASS);
		} else {
			logger("Verification: Selected Values are not cleared", Status.FAIL);
		}
		return this;
	}

	public Contact_Us_Page Select_Required_Business_Filter(String filteroption) throws InterruptedException {
		
		System.out.println(filteroption);
		Thread.sleep(5000);
		VerifyElementIsClickable(ContactusPageConstants.Business_filter_arrow);
		clickWebElement(ContactusPageConstants.Business_filter_arrow);
		WebElement Filter_Option = driver.findElement(By.xpath("//span[@class='multiselect-option-checkbox']//following-sibling::label[text()='"+filteroption+"']"));

		if (Filter_Option.isDisplayed())
		{
			logger("Verification: " + Filter_Option.getText() + " Business is available in the list", Status.PASS);
		}
		clickWebElement(Filter_Option);
		Thread.sleep(2000);
		ContactusPageConstants.Business_unit_filter_arrow.click();
		return this;
	}
	
public Contact_Us_Page Select_Required_Business_Filter(String filteroption,String filteroption2) throws InterruptedException {
		
		System.out.println(filteroption);
		Thread.sleep(5000);
		clickWebElement(ContactusPageConstants.Business_filter_arrow);
		WebElement Filter_Option = driver.findElement(By.xpath("//span[@class='multiselect-option-checkbox']//following-sibling::label[text()='"+filteroption+"']"));

		if (Filter_Option.isDisplayed())
		{
			logger("Verification: " + Filter_Option.getText() + " Business is available in the list", Status.PASS);
		}
		clickWebElement(Filter_Option);
		
		WebElement Filter_Option2 = driver.findElement(By.xpath("//span[@class='multiselect-option-checkbox']//following-sibling::label[text()='"+filteroption2+"']"));
		
		if (Filter_Option2.isDisplayed())
		{
			logger("Verification: " + Filter_Option.getText() + " Business is available in the list", Status.PASS);
		}
		clickWebElement(Filter_Option2);
		
		Thread.sleep(1000);
		ContactusPageConstants.Business_unit_filter_arrow.click();
		return this;
	}
	
	public Contact_Us_Page Select_Required_Business_Filter2(String filteroption) throws InterruptedException {
		Thread.sleep(3000);
		VerifyElementIsClickable(ContactusPageConstants.Business_unit_filter2);
		ContactusPageConstants.Business_unit_filter2.click();
		WebElement Filter_Option = driver
				.findElement(By.xpath("//span[@class='multiselect-option-checkbox']//following-sibling::label[text()='"
						+ filteroption + "']"));

		if (Filter_Option.isDisplayed())
			;
		{
			logger("Verification: " + Filter_Option.getText() + " Business is available in the list", Status.PASS);
		}
		clickWebElement(Filter_Option);
		Thread.sleep(2000);
		ContactusPageConstants.Business_unit_filter_arrow.click();
		return this;
	}

	public Contact_Us_Page Verify_Google_map() {

		if (ContactusPageConstants.Google_map_api.isDisplayed())
			;
		{
			logger("Verification: Google map is used in" + HomePageconstants.Region_selection_button.getText(),
					Status.PASS);
		}
		return this;
	}

	public Contact_Us_Page Verify_LocationPins_Maps() {

		if (ContactusPageConstants.Google_map_pins.isDisplayed())
			;
		{
			logger("Verification: Pins are displayed in Map for available contacts", Status.PASS);
		}

		return this;
	}

	public Contact_Us_Page Verify_LocationPins_cluster_maps() throws InterruptedException {
		Thread.sleep(2000);
		if (ContactusPageConstants.Consolidated_pin_map.isDisplayed())
			;
		{
			logger("Verification: Pins are displayed in Map for available contacts", Status.PASS);
		}

		return this;
	}


	public Contact_Us_Page Verify_ConsolidatedPins_Maps() {

		List<WebElement> consolidatedpins = driver.findElements(By.xpath(
				"//div[contains(@class,'contacts-list-map ')]//descendant::span[@aria-hidden='true']"));

		if (consolidatedpins.size() > 0) {
			logger("Verification: Consolidated Pins are displayed in Map for available contacts", Status.PASS);
		} else {
			logger("Verification: Consolidated Pins are not displayed in Map for available contacts", Status.FAIL);
		}

		return this;
	}

	public Contact_Us_Page Click_Map_ZoomIn() {
		MoveToElement(ContactusPageConstants.Map_zoomin);
		clickWebElement(ContactusPageConstants.Map_zoomin);
		return this;

	}

	public Contact_Us_Page Wait() throws InterruptedException {
		Thread.sleep(5000);
		return this;

	}

	public Contact_Us_Page Click_Location_textbox() throws InterruptedException {

		MoveToElement(ContactusPageConstants.Location_inputbox);
		Thread.sleep(2000);
		clickWebElement(ContactusPageConstants.Location_inputbox);
		ContactusPageConstants.Location_inputbox.sendKeys("test");
		return this;

	}

	public Contact_Us_Page Click_Map_ZoomOut() throws Exception {
		clickWebElement(ContactusPageConstants.Map_zoomout);
		Thread.sleep(2000);
		return this;

	}

	public Contact_Us_Page Verify_Contact_Name() {
		verifyElementDisplayed(ContactusPageConstants.contact_name);
		return this;

	}

	public Contact_Us_Page Verify_No_ContactForm() {

		List<WebElement> Selected_option = driver.findElements(By.xpath(
				"//button[contains(@class,'contact-details__contact-form')]//span[contains(@class,'cta-content-text')]"));

		if (Selected_option.size() == 0) {
			logger("Verification: For the Selected contact type contactform is not available", Status.PASS);
		} else {
			logger("Verification: For the Selected contact type contactform button is available", Status.FAIL);
		}
		return this;

	}

	public Contact_Us_Page Verify_Contact_type() {
		verifyElementDisplayed(ContactusPageConstants.contact_type);
		return this;

	}

	public Contact_Us_Page Verify_Contact_type_for_selected_type1(String filteroption) throws InterruptedException
	{
		Thread.sleep(3000);
		clickWebElement(ContactusPageConstants.contact_type_fiter1);
		dynamicElementDisplayed("//div[contains(@class,'option--is-selected')]//child::label", filteroption);
		clickWebElement(ContactusPageConstants.contact_type_fiter1);
		return this;

	}

	public Contact_Us_Page Verify_Contact_type_for_selected_type(String filteroption) throws InterruptedException {
		boolean type = false;

		List<WebElement> contact_type_list = driver.findElements(By.xpath("//div[@class='contact__type']"));

		for (int i = 0; i<= contact_type_list.size(); i++) {
			if (contact_type_list.get(i).getText().equalsIgnoreCase(filteroption)) {
				type = true;
				if (!type) {
					logger("Verification: Contact types are  not matching with the selected option", Status.FAIL);
					break;
				}
			}
		}
		logger("Verification: " + contact_type_list.get(0).getText()
				+ " Contact type are matching with the selected filter: " + filteroption, Status.PASS);
		return this;

	}

	public Contact_Us_Page Verify_Contact_Distance() {
		verifyElementDisplayed(ContactusPageConstants.contact_Distance);
		return this;

	}

	public Contact_Us_Page Verify_View_Details() {
		verifyElementDisplayed(ContactusPageConstants.View_details);
		return this;

	}

	public Contact_Us_Page Click_View_Details() throws InterruptedException {
		VerifyElementIsClickable(ContactusPageConstants.View_details);
		Thread.sleep(8000);
		clickWebElement(ContactusPageConstants.View_details);
		return this;

	}
	
	public Contact_Us_Page Click_View_Details_For_Chennai() throws InterruptedException {
		VerifyElementIsClickable(ContactusPageConstants.View_details2);
		Thread.sleep(5000);
		clickWebElement(ContactusPageConstants.View_details2);
		return this;

	}
	
	
	
	public Contact_Us_Page Accept_Cookie() throws InterruptedException {
		Thread.sleep(2000);
		if(VerifyElementIsClickableForAlert(HomePageconstants.acceptcookies)) {
			clickWebElement(HomePageconstants.acceptcookies);
			logger("verification: Cookies pop-up displayed and accepted", Status.PASS);
		}
		
		return this;
	}
	
	public Contact_Us_Page Click_View_Details_CNN() {
		clickWebElement(ContactusPageConstants.View_details_CNN);
		return this;
	}
	
	
	
	public Contact_Us_Page Verify_ContactID_URL() {
		if (driver.getCurrentUrl().contains("contact-us/contacts-list/?id="))

		{
			logger("verification: Contact ID is updated in URL", Status.PASS);
		} else {
			logger("verification: Contact ID is not updated in URL", Status.FAIL);
		}
		return this;

	}

	public Contact_Us_Page Verify_contact_details_view() {
			
		if (ContactusPageConstants.contact_details_view.isDisplayed())

		{
			logger("verification: Contact details view is displayed", Status.PASS);
		} else {
			logger("verification: Contact details view is not displayed", Status.FAIL);
		}
		return this;

	}

	public Contact_Us_Page Click_View_Details2() {
		driver.findElement(By.xpath(
				"(//button[@class='cta contact__view-details-button']//following::span[@class='cta-content-text'])[1]"))
		.click();
		return this;
	}

	public Contact_Us_Page Verify_Highlighted_pin() throws InterruptedException {
		
		Thread.sleep(7000);
		if (ContactusPageConstants.Highlighted_pin.isDisplayed())

		{
			logger("verification: Pin is highlighted in Map for the selected Location", Status.PASS);
		} else {
			logger("verification: Pin is not highlighted in Map for the selected Location", Status.FAIL);
		}
		return this;

	}

	public Contact_Us_Page Verify_Baidu_map() {

		if (ContactusPageConstants.Baidu_map.isDisplayed())
			;
		{
			logger("Verification: Baidu_map is used in Chinese site", Status.PASS);
		}
		return this;
	}

	public Home_Page Navigate_homepage() {

		HomePageconstants.titleImage.click();
		return new Home_Page();

	}

	public Contact_Us_Page Count_contacts(){

		List<WebElement> contact_list = driver.findElements(By.xpath("//div[@class='contact__company-name']"));
		int Number_of_Contacts = contact_list.size() + 1;

		logger("Number of Entries in contact list are : " + Number_of_Contacts, Status.INFO);
		return this;

	}
	
	public Contact_Us_Page Verify_contacts_notAlphabetic_order() throws Exception {

		//List<WebElement> contact_list = driver.findElementsByXPath("//div[@class='contact__company-name']");	
		/*
		 * TurnOnGeolocation(); Thread.sleep(2000);
		 */
		EnterText_Location("Chennai");
		Thread.sleep(5000);
		Verify_NotinAlphabatic_Order("//div[@class='contact__company-name']");
		return this;

	}
	
	public Contact_Us_Page Verify_contacts_Alphabetic_order() {

		//List<WebElement> contact_list = driver.findElementsByXPath("//div[@class='contact__company-name']");

		Verify_Alphabatic_Order("//div[@class='contact__company-name']");
		return this;

	}





	public Contact_Us_Page Verify_updated_Url_Business() {
		if (driver.getCurrentUrl().contains("contact-us/contacts-list/?filter=segment"))

		{
			logger("Verification: Selected filter is updated in current URL", Status.PASS);
		}

		return this;
	}

	public Contact_Us_Page Verify_updated_Url_type() {
		if (driver.getCurrentUrl().contains("contact-us/contacts-list/?filter=type"))

		{
			logger("Verification: Selected filter is updated in current URL", Status.PASS);
		}

		return this;
	}

	public Contact_Us_Page Verify_Contact_Name_Detailview() {
		verifyElementDisplayed(ContactusPageConstants.contact_name_detailview);
		return this;

	}

	public Contact_Us_Page Verify_Attribute_Detailview() {

		if (ContactusPageConstants.contact_detailview_attributelist.isDisplayed()) {
			logger("Verification: Attribute list is displayed in Contact detailview", Status.PASS);
		} else {
			logger("Verification: Attribute list is displayed in Contact detailview", Status.FAIL);
		}
		return this;

	}

	public Contact_Us_Page Verify_ShowMore_button() {
		verifyElementDisplayed(ContactusPageConstants.contact_detail_view_showmore);
		return this;
	}

	public Contact_Us_Page Click_ShowMore_button() throws InterruptedException {
		clickWithScreenshot(ContactusPageConstants.contact_detail_view_showmore);
		return this;
	}

	public Contact_Us_Page Click_ShowLess_button() {
		clickWithScreenshot(ContactusPageConstants.contact_detail_view_showless);
		return this;
	}

	public Contact_Us_Page Verify_View_close() {
		if (ContactusPageConstants.contact_details_view_close.isDisplayed()) {
			logger("Verification: Detail View Close button is available", Status.PASS);
		}
		return this;
	}

	public Contact_Us_Page Verify_contactform_button() {
		verifyElementDisplayed(ContactusPageConstants.contact_Us_form);
		return this;
	}

	public Contact_Us_Page Click_Contactform_Button() throws InterruptedException {
		clickWithScreenshot(ContactusPageConstants.contact_Us_form);
		Thread.sleep(5000);
		return this;
	}

	public Contact_Us_Page Verify_DistributorDPS_Form() throws InterruptedException {
		Thread.sleep(5000);
		if (ContactusPageConstants.Contact_form_popup.isDisplayed()) {
			loggerWithScreenshot("Verification: DistributorDPS form is displayed", "", Status.PASS, true);
		}

		return this;
	}

	public Contact_Us_Page Verify_Distributor_Form() throws InterruptedException {
		Thread.sleep(5000);
		if (ContactusPageConstants.Contact_form_popup.isDisplayed()) {
			loggerWithScreenshot("Verification: Distributor form is displayed", "", Status.PASS, true);
		}

		return this;
	}

	public Contact_Us_Page Verify_Pardot_Form() throws InterruptedException {
		Thread.sleep(5000);
		if (ContactusPageConstants.Contact_form_popup.isDisplayed()) {
			loggerWithScreenshot("Verification: Pardot form is displayed", "", Status.PASS, true);
		}

		return this;
	}

	public Contact_Us_Page Verify_ServiceCloud_Form() throws InterruptedException {
		Thread.sleep(5000);
		if (ContactusPageConstants.Contact_form_popup.isDisplayed()) {
			loggerWithScreenshot("Verification: ServiceCloud form is displayed", "", Status.PASS, true);
		}

		return this;
	}

	public Contact_Us_Page Click_Form_close() {
		
		ContactusPageConstants.Contact_form_close.click();

		return this;
	}

	public Contact_Us_Page Verify_Attribute_list() throws InterruptedException {

		List<WebElement> Attribute_key = driver
				.findElements(By.xpath("//td[contains(@class,'contact-details__key-cell')]"));
		List<WebElement> Attribute_value = driver
				.findElements(By.xpath("//td[contains(@class,'contact-details__value-cell')]"));

		for (int i = 0; i < Attribute_key.size(); i++) {
			logger("Verification: Attribute " + Attribute_key.get(i).getText() + " is available with Value "
					+ Attribute_value.get(i).getText(), Status.PASS);
		}
		return this;

	}

	public Contact_Us_Page Verify_Tel_number() throws InterruptedException {

		List<WebElement> tel_no = driver.findElements(By.xpath("//a[contains(@href,'tel:')]"));
		for (int i=0; i<tel_no.size(); i++)
		{
			VerifyElementIsHighlighted(tel_no.get(i));
			VerifyElementIsClickable(tel_no.get(i));
		}
		return this;

	}

	public Contact_Us_Page Verify_website() throws InterruptedException {

		List<WebElement> tel_no = driver.findElements(By.xpath("//td[contains(@class,'contact-details-url')]//a[contains(@href,'http')]"));
		for (int i=0; i<tel_no.size(); i++)
		{
			VerifyElementIsHighlighted(tel_no.get(i));
			VerifyElementIsClickable(tel_no.get(i));
		}
		return this;

	}

	public Contact_Us_Page Verify_Alphabatic_Order() {
		List<WebElement> listOfElement = ListOfElement("xpath", "(//div[@class='contact__company-name'])");
		List<String> list1 = new ArrayList<>();
		List<String> list2 = new ArrayList<>();
		for (WebElement webElement : listOfElement) {
			String text = webElement.getText();
			list1.add(text);
			list2.add(text);
		}

		Collections.sort(list1);
		if (list1.equals(list2)) {
			logger("Contact lists are sorted in alphabetical order", Status.PASS);

		} else {
			logger("Contact lists are Not sorted in alphabetic order", Status.FAIL);
		}
		return this;
	}

	public Contact_Us_Page Verify_Distributor_Contactus_form() {

		if (ContactusPageConstants.Contact_form_pp_distributor.isDisplayed()
				&& ContactusPageConstants.Contact_form_distributor_consent.isDisplayed()) {
			logger("Verification: Contact us form: Distributor is opened in popup", Status.PASS);

		} else {
			logger("Verification: Issue with Contact us form", Status.FAIL);
		}
		return this;

	}

	public Contact_Us_Page Verify_DistributorDPS_Contactus_form() throws InterruptedException {
		Thread.sleep(1000);
		VerifyElementIsClickable(ContactusPageConstants.Contact_form_pp_distributordps);
		if (ContactusPageConstants.Contact_form_pp_distributordps.isDisplayed()) {
			logger("Verification: Contact us form: Distributor_DPS is opened in popup", Status.PASS);
		}

		else {
			logger("Verification: Issue with Contact us form", Status.FAIL);
		}

		return this;

	}

	public Contact_Us_Page Verify_ServiceCloud_Contactus_form() throws InterruptedException {
	
		if (ContactusPageConstants.Contact_form_servicecloud_selectreason.isDisplayed()
				&& ContactusPageConstants.Contact_form_servicecloud_consent.isDisplayed()) {
			logger("Verification: Contact us form: ServiceCloud is opened in popup", Status.PASS);
		}

		else {
			logger("Verification: Issue with Contact us form", Status.FAIL);
		}

		return this;

	}

	public Contact_Us_Page Verify_Pardot_Contactus_form() {

		if (ContactusPageConstants.Contact_form_pp_pardot.isDisplayed()) {
			logger("Verification: Contact us form: Pardot is opened in popup", Status.PASS);
		}

		else {
			logger("Verification: Issue with Contact us form", Status.FAIL);
		}

		return this;

	}

	///////// Contact us Form////////////////

	public Contact_Us_Page Verify_CF_Firstname() {
		MoveToElement(ContactusPageConstants.C_F_first_name_tooltip_icon);
		if (ContactusPageConstants.C_F_first_name.isDisplayed()) {
			logger("Verification: Firstname is displayed", Status.PASS);
		} else {
			logger("Verification: Firstname is not displayedd", Status.FAIL);
		}
		if (ContactusPageConstants.C_F_first_name_req.isDisplayed()) {
			logger("Verification: Firstname is marked as * required field", Status.PASS);
		} else {
			logger("Verification: Firstname is not marked * required field", Status.FAIL);
		}

		if (ContactusPageConstants.C_F_first_name_txtbx.isDisplayed()) {
			logger("Verification: Firstname text box is placed below the title and its empty", Status.PASS);
		} else {
			logger("Verification: Firstname text box is not  placed below the title", Status.FAIL);
		}

		if (ContactusPageConstants.C_F_first_name_tooltip_icon.isDisplayed()) {
			logger("Verification: First name tooltip icon is displayed", Status.PASS);
			if (ContactusPageConstants.C_F_first_name_tooltip.getText()
					.contains("We need to be able to identify you.")) {
				logger("Verification: First name tooltip message matches with expected text", Status.PASS);
			} else {
				logger("Verification: First name tooltip message not matches with expected text", Status.FAIL);
			}
		} else {
			logger("Verification: First name  tooltip icon is not displayed", Status.FAIL);
		}

		return this;
	}

	public Contact_Us_Page Entertext_CF_Firstname(String text) {
		enterText(ContactusPageConstants.C_F_first_name_txtbx, text);
		return this;
	}

	public Contact_Us_Page Verify_CF_Lastname() {
		MoveToElement(ContactusPageConstants.C_F_last_name_tooltip_icon);
		if (ContactusPageConstants.C_F_last_name.isDisplayed()) {
			logger("Verification: Lastname is displayed", Status.PASS);
		} else {
			logger("Verification: Lastname is not displayedd", Status.FAIL);
		}
		if (ContactusPageConstants.C_F_last_name_req.isDisplayed()) {
			logger("Verification: Lastname is marked as * required field", Status.PASS);
		} else {
			logger("Verification: Lastname is not marked * required field", Status.FAIL);
		}

		if (ContactusPageConstants.C_F_last_name_txtbx.isDisplayed()) {
			logger("Verification: Lastname text box is placed below the title and its empty", Status.PASS);
		} else {
			logger("Verification: Lastname text box is not placed below the title", Status.FAIL);
		}

		if (ContactusPageConstants.C_F_last_name_tooltip_icon.isDisplayed()) {
			logger("Verification: Last name tooltip icon is displayed", Status.PASS);

			if (ContactusPageConstants.C_F_last_name_tooltip.getText()
					.contains("We need to be able to identify you.")) {
				logger("Verification: Last name tooltip message matches with expected text", Status.PASS);
			} else {
				logger("Verification: Last name tooltip message not matches with expected text", Status.FAIL);
			}
		} else {
			logger("Verification: Last name  tooltip icon is not displayed", Status.FAIL);
		}
		return this;
	}

	public Contact_Us_Page Entertext_CF_Lastname(String text) {
		enterText(ContactusPageConstants.C_F_last_name_txtbx, text);
		return this;
	}

	public Contact_Us_Page Verify_CF_Email() {

		if (ContactusPageConstants.C_F_Email.isDisplayed()) {
			logger("Verification: Email is displayed", Status.PASS);
		} else {
			logger("Verification: Email is not displayedd", Status.FAIL);
		}
		if (ContactusPageConstants.C_F_Email_req.isDisplayed()) {
			logger("Verification: Email is marked as * required field", Status.PASS);
		} else {
			logger("Verification: Email is not marked * required field", Status.FAIL);
		}

		if (ContactusPageConstants.C_F_Email_txtbx.isDisplayed()) {
			logger("Verification: Email text box is placed below the title and its empty", Status.PASS);
		} else {
			logger("Verification: Email text box is not placed below the title", Status.FAIL);
		}

		if (ContactusPageConstants.C_F_Email_tooltip_icon.isDisplayed()) {
			logger("Verification: Email tooltip icon is displayed", Status.PASS);
			MoveToElement(ContactusPageConstants.C_F_Email_tooltip_icon);
			if (ContactusPageConstants.C_F_Email_tooltip.getText()
					.contains("We need this to be able to send you information.")) {
				logger("Verification: Email tooltip message matches with expected text", Status.PASS);
			} else {
				logger("Verification: Email tooltip message not matches with expected text", Status.FAIL);
			}
		} else {
			logger("Verification: Email tooltip icon is not displayed", Status.FAIL);
		}

		return this;
	}


	public Contact_Us_Page Verify_CF_Phone() {

		if (ContactusPageConstants.C_F_Phone.isDisplayed()) {
			logger("Verification: Phone is displayed", Status.PASS);
		} else {
			logger("Verification: Phone is not displayedd", Status.FAIL);
		}
		if (ContactusPageConstants.C_F_Phone_req.isDisplayed()) {
			logger("Verification: Phone is marked as * required field", Status.PASS);
		} else {
			logger("Verification: Phone is not marked * required field", Status.FAIL);
		}

		if (ContactusPageConstants.C_F_Phone_txtbx.isDisplayed()) {
			logger("Verification: Phone text box is placed below the title and its empty", Status.PASS);
		} else {
			logger("Verification: Phone text box is not placed below the title", Status.FAIL);
		}

		if (ContactusPageConstants.C_F_Phone_tooltip_icon.isDisplayed()) {
			logger("Verification: Phone tooltip icon is displayed", Status.PASS);
			MoveToElement(ContactusPageConstants.C_F_Phone_tooltip_icon);
			if (ContactusPageConstants.C_F_Phone_tooltip.getText()
					.contains("We need this for effective request handling")) {
				logger("Verification: Phone tooltip message matches with expected text", Status.PASS);
			} else {
				logger("Verification: Phone tooltip message not matches with expected text", Status.FAIL);
			}
		} else {
			logger("Verification: Phone tooltip icon is not displayed", Status.FAIL);
		}

		return this;
	}

	public Contact_Us_Page Entertext_CF_Email(String text) {
		enterText(ContactusPageConstants.C_F_Email_txtbx, text);
		return this;
	}

	public Contact_Us_Page Entertext_CF_Phone(String text) {
		enterText(ContactusPageConstants.C_F_Phone_txtbx, text);
		return this;
	}

	public Contact_Us_Page Verify_CF_Company() {
		if (ContactusPageConstants.C_F_Company.isDisplayed()) {
			logger("Verification: Company is displayed", Status.PASS);
		} else {
			logger("Verification: Company is not displayedd", Status.FAIL);
		}
		if (ContactusPageConstants.C_F_Company_req.isDisplayed()) {
			logger("Verification: Company is marked as * required field", Status.PASS);
		} else {
			logger("Verification: Company is not marked * required field", Status.FAIL);
		}

		if (ContactusPageConstants.C_F_Company_textbx.isDisplayed()) {
			logger("Verification: Company text box is placed below the title and its empty", Status.PASS);
		} else {
			logger("Verification: Company text box is not placed below the title", Status.FAIL);
		}

		if (ContactusPageConstants.C_F_Company_tooltip_icon.isDisplayed()) {
			logger("Verification: Company tooltip icon is displayed", Status.PASS);

			MoveToElement(ContactusPageConstants.C_F_Company_tooltip_icon);
			if (ContactusPageConstants.C_F_Company_tooltip.getText().contains(
					"We need this to be able to know, if the company you work at is already a customer – this is to give you better service and not process too much information about you.")) {
				logger("Verification: Company tooltip message matches with expected text", Status.PASS);
			} else {
				logger("Verification: Company tooltip message not matches with expected text", Status.FAIL);
			}
		} else {
			logger("Verification: Company tooltip icon is not displayed", Status.FAIL);
		}

		return this;
	}

	public Contact_Us_Page Entertext_CF_Company(String text) {
		enterText(ContactusPageConstants.C_F_Company_textbx, text);
		return this;
	}

	public Contact_Us_Page Verify_CF_Country_Region() {
		if (ContactusPageConstants.C_F_Country_region.isDisplayed()) {
			logger("Verification: Country/region is displayed", Status.PASS);
		} else {
			logger("Verification:Country/region is not displayedd", Status.FAIL);
		}
		if (ContactusPageConstants.C_F_Country_region_req.isDisplayed()) {
			logger("Verification: Country_region is marked as * required field", Status.PASS);
		} else {
			logger("Verification: Country_region is not marked * required field", Status.FAIL);
		}

		if (ContactusPageConstants.C_F_Country_region_dd.isDisplayed()) {
			logger("Verification: Country dd is placed below the title and it have default value as 'choose county/region'",
					Status.PASS);
		} else {
			logger("Verification: Country dd is not placed below the title", Status.FAIL);
		}

		if (ContactusPageConstants.C_F_Country_tooltip_icon.isDisplayed()) {
			logger("Verification: Country tooltip icon is displayed", Status.PASS);
			MoveToElement(ContactusPageConstants.C_F_Country_tooltip_icon);
			if (ContactusPageConstants.C_F_Country_tooltip.getText().contains(
					"We want to send you content in your own language if possible. Furthermore, we want to send you information about events in your country or region.")) {
				logger("Verification: Country tooltip message matches with expected text", Status.PASS);
			} else {
				logger("Verification: Country tooltip message not matches with expected text", Status.FAIL);
			}

		}

		else {
			logger("Verification: Country tooltip icon is not displayed", Status.FAIL);
		}

		return this;
	}


	public Contact_Us_Page Select_CF_country(String country) {

		selectDropDownByText(driver.findElement(By.xpath("//select[@name='Country']")), country);
		return this;

	}

	public Contact_Us_Page Select_CF_state(String state) throws InterruptedException {
		Thread.sleep(3000);
		selectDropDownByText(driver.findElement(By.xpath("//select[@name='State / Province']")), state);
		return this;

	}

	public Contact_Us_Page Verify_CF_state_province() {
		if (ContactusPageConstants.C_F_State_province.isDisplayed()) {
			logger("Verification: state_province is displayed", Status.PASS);
		} else {
			logger("Verification: state_province is not displayed", Status.FAIL);
		}

		if (ContactusPageConstants.C_F_state_province_dd.isDisplayed()) {
			logger("Verification: state dd is placed below the title and it have default value as 'choose state'",
					Status.PASS);
		} else {
			logger("Verification: state dd is placed below the title", Status.FAIL);
		}
		return this;
	}

	public Contact_Us_Page Verify_CF_Zipcode() {
		if (ContactusPageConstants.C_F_Zip_code.isDisplayed()) {
			logger("Verification: Zipcode is displayed", Status.PASS);
		} else {
			logger("Verification: Zipcode is not displayedd", Status.FAIL);
		}
		if (ContactusPageConstants.C_F_Zip_code_req.isDisplayed()) {
			logger("Verification: Zipcode is marked as * required field", Status.PASS);
		} else {
			logger("Verification: Zipcode is not marked * required field", Status.FAIL);
		}
		if (ContactusPageConstants.C_F_Zipcode_textbx.isDisplayed()) {
			logger("Verification: Zipcode text box is placed below the title and its empty", Status.PASS);
		} else {
			logger("Verification: Zipcode text box is not placed below the title", Status.FAIL);
		}

		if (ContactusPageConstants.C_F_Zip_code_tooltip_icon.isDisplayed()) {
			logger("Verification: Zipcode tooltip icon is displayed", Status.PASS);
			MoveToElement(ContactusPageConstants.C_F_Zip_code_tooltip_icon);
			if (ContactusPageConstants.C_F_Zip_code_tooltip.getText()
					.contains("We need this for verification and identification purposes.")) {
				logger("Verification: Zipcode tooltip message matches with expected text", Status.PASS);
			} else {
				logger("Verification: Zipcode tooltip message not matches with expected text", Status.FAIL);
			}

		} else {
			logger("Verification: Zipcode tooltip icon is not displayed", Status.FAIL);
		}

		return this;
	}

	public Contact_Us_Page Entertext_CF_Zipcode(String text) {
		enterText(ContactusPageConstants.C_F_Zipcode_textbx, text);
		return this;
	}

	public Contact_Us_Page Verify_CF_City() {
		if (ContactusPageConstants.C_F_City.isDisplayed()) {
			logger("Verification: City is displayed", Status.PASS);
		} else {
			logger("Verification: City is not displayedd", Status.FAIL);
		}
		if (ContactusPageConstants.C_F_City_req.isDisplayed()) {
			logger("Verification: City is marked as * required field", Status.PASS);
		} else {
			logger("Verification: City is not marked * required field", Status.FAIL);
		}
		if (ContactusPageConstants.C_F_City_textbx.isDisplayed()) {
			logger("Verification: City text box is placed below the title and its empty", Status.PASS);
		} else {
			logger("Verification: City text box is not placed below the title", Status.FAIL);
		}

		if (ContactusPageConstants.C_F_City_tooltip_icon.isDisplayed()) {
			logger("Verification: City tooltip icon is displayed", Status.PASS);
			MoveToElement(ContactusPageConstants.C_F_City_tooltip_icon);
			if (ContactusPageConstants.C_F_City_tooltip.getText()
					.contains("We need this for verification and identification purposes.")) {
				logger("Verification: City tooltip message matches with expected text", Status.PASS);
			} else {
				logger("Verification: City tooltip message not matches with expected text", Status.FAIL);
			}
		} else {
			logger("Verification: City tooltip icon is not displayed", Status.FAIL);
		}

		return this;
	}

	public Contact_Us_Page Entertext_CF_City(String text) {
		enterText(ContactusPageConstants.C_F_City_textbx, text);
		return this;
	}

	public Contact_Us_Page Verify_CF_Address() {
		if (ContactusPageConstants.C_F_Address.isDisplayed()) {
			logger("Verification: Address is displayed", Status.PASS);
		} else {
			logger("Verification: Address is not displayedd", Status.FAIL);
		}
		if (ContactusPageConstants.C_F_Address_req.isDisplayed()) {
			logger("Verification: Address is marked as * required field", Status.PASS);
		} else {
			logger("Verification: Address is not marked * required field", Status.FAIL);
		}
		if (ContactusPageConstants.C_F_Address_textbx.isDisplayed()) {
			logger("Verification: Address text box is placed below the title and its empty", Status.PASS);
		} else {
			logger("Verification: Address text box is not placed below the title", Status.FAIL);
		}

		if (ContactusPageConstants.C_F_Address_tooltip_icon.isDisplayed()) {
			logger("Verification: Address tooltip icon is displayed", Status.PASS);
			MoveToElement(ContactusPageConstants.C_F_Address_tooltip_icon);
			if (ContactusPageConstants.C_F_Address_tooltip.getText()
					.contains("We need this for verification and identification purposes.")) {
				logger("Verification: Address tooltip message matches with expected text", Status.PASS);
			} else {
				logger("Verification: Address tooltip message not matches with expected text", Status.FAIL);
			}
		} else {
			logger("Verification: Address tooltip icon is not displayed", Status.FAIL);
		}

		return this;
	}

	public Contact_Us_Page Entertext_CF_Address(String text) {
		enterText(ContactusPageConstants.C_F_Address_textbx, text);
		return this;
	}

	public Contact_Us_Page Verify_CF_Message() {
		if (ContactusPageConstants.C_F_Message.isDisplayed()) {
			logger("Verification: Message is displayed", Status.PASS);
		} else {
			logger("Verification: Message is not displayedd", Status.FAIL);
		}
		if (ContactusPageConstants.C_F_Message_req.isDisplayed()) {
			logger("Verification: Message is marked as * required field", Status.PASS);
		} else {
			logger("Verification: Message is not marked * required field", Status.FAIL);
		}
		if (ContactusPageConstants.C_F_Message_textbx.isDisplayed()) {
			logger("Verification: Message text box is placed below the title and its empty", Status.PASS);
		} else {
			logger("Verification: Message text box is not placed below the title", Status.FAIL);
		}

		if (ContactusPageConstants.C_F_Message_tooltip_icon.isDisplayed()) {
			logger("Verification: Message tooltip icon is displayed", Status.PASS);
			MoveToElement(ContactusPageConstants.C_F_Message_tooltip_icon);
			if (ContactusPageConstants.C_F_Message_tooltip.getText()
					.contains("We need this for effective request handling")) {
				logger("Verification: Message tooltip message matches with expected text", Status.PASS);
			} else {
				logger("Verification: Message tooltip message not matches with expected text", Status.FAIL);
			}
		} else {
			logger("Verification: Message tooltip icon is not displayed", Status.FAIL);
		}
		return this;
	}

	public Contact_Us_Page Entertext_CF_Message(String text) {
		enterText(ContactusPageConstants.C_F_Message_textbx, text);
		return this;
	}

	public Contact_Us_Page Verify_CF_ConsentMessage() {
		verifyElementDisplayed(ContactusPageConstants.C_F_consent);

		return this;
	}

	public Contact_Us_Page Verify_CF_Undersood() {
		verifyElementDisplayed(ContactusPageConstants.C_F_Understand);

		return this;
	}

	public Contact_Us_Page Verify_CF_Undersood_DPS() {
		verifyElementDisplayed(ContactusPageConstants.C_F_Understand_DPS);

		return this;
	}

	public Contact_Us_Page Verify_CF_Undersood_SC() {
		verifyElementDisplayed(ContactusPageConstants.C_F_Understand_SC);

		return this;
	}

	public Contact_Us_Page Verify_CF_Undersood_PD() {
		verifyElementDisplayed(ContactusPageConstants.C_F_Understand_PD);

		return this;
	}
	public Contact_Us_Page Verify_CF_Undersood_chkbx() {
		if (ContactusPageConstants.C_F_Understand_chkbx.isDisplayed()) {
			logger("Verification: Checkbox is displayed", Status.PASS);
		} else {
			logger("Verification: Checkbox is not displayed", Status.FAIL);
		}

		return this;
	}

	public Contact_Us_Page Verify_CF_Undersood_dps_chkbx() {
		if (ContactusPageConstants.C_F_Understand_chkbx_dps.isDisplayed()) {
			logger("Verification: Dps understand ucheckbox is displayed", Status.PASS);
		} else {
			logger("Verification: Checkbox is not displayed", Status.FAIL);
		}

		return this;
	}


	public Contact_Us_Page Verify_CF_Undersood_SC_chkbx() {
		if (ContactusPageConstants.C_F_Understand_chkbx_SC.isDisplayed()) {
			logger("Verification: Servicecloud understand checkbox is displayed", Status.PASS);
		} else {
			logger("Verification: Checkbox is not displayed", Status.FAIL);
		}

		return this;
	}

	public Contact_Us_Page Verify_CF_Undersood_PD_chkbx() {
		if (ContactusPageConstants.C_F_Understand_chkbx_PD.isDisplayed()) {
			logger("Verification: Pardot understand checkbox is displayed", Status.PASS);
		} else {
			logger("Verification: Checkbox is not displayed", Status.FAIL);
		}

		return this;
	}

	public Contact_Us_Page Select_CF_Undersood_chkbx() {
		scrollBottomOfPageJS();
		MoveToElement(ContactusPageConstants.C_F_Understand_chkbx);
		clickWebElement(ContactusPageConstants.C_F_Understand);

		return this;
	}

	public Contact_Us_Page Select_CF_Undersood_dps_chkbx() {
		scrollBottomOfPageJS();
		MoveToElement(ContactusPageConstants.C_F_Understand_chkbx_dps);
		clickWebElement(ContactusPageConstants.C_F_Understand_DPS);

		return this;
	}

	public Contact_Us_Page Select_CF_Undersood_SC_chkbx() {
		scrollBottomOfPageJS();
		MoveToElement(ContactusPageConstants.C_F_Understand_chkbx_SC);
		clickWebElement(ContactusPageConstants.C_F_Understand_SC);

		return this;
	}

	public Contact_Us_Page Select_CF_Undersood_PD_chkbx() {
		scrollBottomOfPageJS();
		MoveToElement(ContactusPageConstants.C_F_Understand_chkbx_PD);
		clickWebElement(ContactusPageConstants.C_F_Understand_PD);

		return this;
	}

	public Contact_Us_Page Verify_CF_Submitbutton() {
		verifyElementDisplayed(ContactusPageConstants.C_F_Submit_button);
		return this;
	}
	
	public Contact_Us_Page close_form(){
		clickWebElement(ContactusPageConstants.C_F_Close_button);
		return this;
	}

	public Contact_Us_Page Verify_CF_Submitbutton_disabled() throws InterruptedException {
		Thread.sleep(2000);
		if(ContactusPageConstants.C_F_Submit_button_disabled.isDisplayed())
		{
			logger("Verification: Submit button is disabled", Status.PASS);
		}else
		{
			logger("Verification: Submit button is not disabled", Status.FAIL);
		}

		return this;
	}

	public Contact_Us_Page Click_CF_Submitbutton() {
		clickWithScreenshot(ContactusPageConstants.C_F_Submit_button);
		return this;
	}

	public Contact_Us_Page Verify_CF_Recaptcha() {
		if (ContactusPageConstants.C_F_Recaptcha.isDisplayed()) {

			logger("Verification: Captcha is displayed", Status.PASS);
		} else {
			logger("Verification: Captcha is not displayed", Status.FAIL);
		}

		return this;
	}

	public Contact_Us_Page Verify_SC_SubReason_Errormsg(String text) {
		if (verifyElementDisplayed(ContactusPageConstants.C_F_SC_selectsubreason_error_msg)) {
			ContactusPageConstants.C_F_SC_selectsubreason_error_msg.getText().contains(text);
		}
		return this;
	}
	public Contact_Us_Page Verify_firstname_Errormsg(String text) {
		if (verifyElementDisplayed(ContactusPageConstants.C_F_first_error_msg)) {
			ContactusPageConstants.C_F_first_error_msg.getText().contains(text);
		}
		return this;
	}

	public Contact_Us_Page Verify_lastname_Errormsg(String text) {
		if (verifyElementDisplayed(ContactusPageConstants.C_F_last_error_msg)) {
			ContactusPageConstants.C_F_last_error_msg.getText().contains(text);
		}
		return this;
	}

	public Contact_Us_Page Verify_email_Errormsg(String text) {
		if (verifyElementDisplayed(ContactusPageConstants.C_F_Email_error_msg)) {
			ContactusPageConstants.C_F_Email_error_msg.getText().contains(text);
		}
		return this;
	}

	public Contact_Us_Page Verify_phone_Errormsg(String text) {
		if (verifyElementDisplayed(ContactusPageConstants.C_F_Phone_error_msg)) {
			ContactusPageConstants.C_F_Phone_error_msg.getText().contains(text);
		}
		return this;
	}

	public Contact_Us_Page Verify_company_Errormsg(String text) {
		if (verifyElementDisplayed(ContactusPageConstants.C_F_Company_error_msg)) {
			ContactusPageConstants.C_F_Company_error_msg.getText().contains(text);
		}
		return this;
	}

	public Contact_Us_Page Verify_Country_Errormsg(String text) {
		if (verifyElementDisplayed(ContactusPageConstants.C_F_Company_error_msg)) {
			ContactusPageConstants.C_F_Company_error_msg.getText().contains(text);
		}
		return this;
	}

	public Contact_Us_Page Verify_Zipcode_Errormsg(String text) {
		if (verifyElementDisplayed(ContactusPageConstants.C_F_Zip_code_error_msg)) {
			ContactusPageConstants.C_F_Zip_code_error_msg.getText().contains(text);
		}
		return this;
	}

	public Contact_Us_Page Verify_City_Errormsg(String text) {
		if (verifyElementDisplayed(ContactusPageConstants.C_F_City_error_msg)) {
			ContactusPageConstants.C_F_City_error_msg.getText().contains(text);
		}
		return this;
	}

	public Contact_Us_Page Verify_Address_Errormsg(String text) {
		if (verifyElementDisplayed(ContactusPageConstants.C_F_Address_error_msg)) {
			ContactusPageConstants.C_F_Address_error_msg.getText().contains(text);
		}

		return this;
	}

	public Contact_Us_Page Verify_Message_Errormsg(String text) {
		if (verifyElementDisplayed(ContactusPageConstants.C_F_Message_error_msg)) {
			ContactusPageConstants.C_F_Message_error_msg.getText().contains(text);
		}
		return this;
	}

	public Contact_Us_Page Verify_Undersand_Errormsg(String text) {
		if (verifyElementDisplayed(ContactusPageConstants.C_F_Understand_error_msg)) {
			ContactusPageConstants.C_F_Understand_error_msg.getText().contains(text);
		}
		return this;
	}

	public Contact_Us_Page Verify_Undersand_Dps_Errormsg(String text) {
		if (verifyElementDisplayed(ContactusPageConstants.C_F_Understand_Dps_error_msg)) {
			ContactusPageConstants.C_F_Understand_Dps_error_msg.getText().contains(text);
		}
		return this;
	}

	public Contact_Us_Page Verify_Undersand_PD_Errormsg(String text) {
		if (verifyElementDisplayed(ContactusPageConstants.C_F_Understand_PD_error_msg)) {
			ContactusPageConstants.C_F_Understand_PD_error_msg.getText().contains(text);
		}
		return this;
	}

	//service cloud form

	public Contact_Us_Page Verify_CF_SC_Select_Reason() {
		MoveToElement(ContactusPageConstants.Contact_form_servicecloud_selectreason_tooltip);
		if (ContactusPageConstants.Contact_form_servicecloud_selectreason.isDisplayed()) {
			logger("Verification: Please select a reason is displayed", Status.PASS);
		} else {
			logger("Verification: Please select a reason is not displayedd", Status.FAIL);
		}
		if (ContactusPageConstants.C_F_SC_selectreason_req.isDisplayed()) {
			logger("Verification: Please select reason is marked as * required field", Status.PASS);
		} else {
			logger("Verification: Please select reason is not marked * required field", Status.FAIL);
		}

		if (ContactusPageConstants.C_F_select_reason_dd.isDisplayed()) {
			logger("Verification: Select Reason dropdown is placed below the title and contains label Choose reason", Status.PASS);
		} else {
			logger("Verification: Select Reason dropdown text box is not placed below the title", Status.FAIL);
		}

		if (ContactusPageConstants.Contact_form_servicecloud_selectreason_tooltip.isDisplayed()) {
			logger("Verification: Select Reason tooltip icon is displayed", Status.PASS);
			if (ContactusPageConstants.Contact_form_servicecloud_selectreason_tooltip.getText()
					.contains("We need this for effective request handling.")) {
				logger("Verification: Select Reason tooltip message matches with expected text", Status.PASS);
			} else {
				logger("Verification: Select Reason tooltip message not matches with expected text", Status.FAIL);
			}
		} else {
			logger("Verification: Select Reason tooltip icon is not displayed", Status.FAIL);
		}

		return this;
	}

	public Contact_Us_Page Verify_CF_SC_disabled_form_except_SelectReason() {

		List<WebElement> textbox = driver.findElements(By.xpath("//input[contains(@class,'form-control-disabled')]"));
		try {
			for (WebElement webElement : textbox) {
				if(webElement.isDisplayed())
				{

				}
				else {
					logger("Verification: All input fields are not disabled", Status.PASS);
					break;
				} 

			} logger("Verification: All input fields are  disabled", Status.PASS);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		List<WebElement> dropdowns = driver.findElements(By.xpath("(//select[contains(@aria-disabled,'true')])//following::label[contains(@class,'fs-select')]"));
		try {
			for (WebElement webElement : dropdowns) {
				if(webElement.isDisplayed())
				{

				}
				else {
					logger("Verification: All dropdown fields are not disabled", Status.PASS);
					break;
				} 

			} logger("Verification: All dropdown fields are disabled", Status.PASS);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		return this;

	}

	public Contact_Us_Page Verify_CF_SC_Select_Sub_Reason() throws InterruptedException {
		MoveToElement(ContactusPageConstants.Contact_form_servicecloud_selectsubreason_tooltip);
		if (ContactusPageConstants.Contact_form_servicecloud_selectsubreason.isDisplayed()) {
			logger("Verification: Please select a sub reason is displayed", Status.PASS);
		} else {
			logger("Verification: Please select a sub reason is not displayedd", Status.FAIL);
		}
		if (ContactusPageConstants.C_F_SC_selectsubreason_req.isDisplayed()) {
			logger("Verification: Please select sub reason is marked as * required field", Status.PASS);
		} else {
			logger("Verification: Please select sub reason is not marked * required field", Status.FAIL);
		}

		if (ContactusPageConstants.C_F_select_subreason_dd.isDisplayed()) {
			logger("Verification: Select Sub Reason dropdown is placed below the title and contains label Choose reason", Status.PASS);
		} else {
			logger("Verification: Select Sub Reason dropdown text box is not placed below the title", Status.FAIL);
		}

		if (ContactusPageConstants.Contact_form_servicecloud_selectsubreason_tooltip.isDisplayed()) {
			logger("Verification: Select sub Reason tooltip icon is displayed", Status.PASS);
			
			Thread.sleep(2000);
			selectDropDownByText(ContactusPageConstants.choose_Reason, "Product inquiry processes");
			String aa = ContactusPageConstants.Contact_form_servicecloud_selectsubreason_tooltip.getText();
			if (ContactusPageConstants.Contact_form_servicecloud_selectsubreason_tooltip.getText()
					.contains("We need this for effective request handling.")) {
				logger("Verification: Select Sub Reason tooltip message matches with expected text", Status.PASS);
			} else {
				logger("Verification: Select Sub Reason tooltip message not matches with expected text", Status.FAIL);
			}
		} else {
			logger("Verification: Select Sub Reason tooltip icon is not displayed", Status.FAIL);
		}

		return this;
	}

	public Contact_Us_Page Select_CF_SC_Select_Reason(String string) {
		selectDropDownByText(driver.findElement(By.xpath("//select[@name='Reason']")), string);
		return this;
	}

	public Contact_Us_Page Select_CF_SC_Select_SubReason(String string) {
		selectDropDownByText(driver.findElement(By.xpath("//select[@name='SubReason']")), string);
		return this;
	}

	public Contact_Us_Page Verify_Undersand_SC_Errormsg(String text) {
		if (verifyElementDisplayed(ContactusPageConstants.C_F_Understand_SC_error_msg)) {
			ContactusPageConstants.C_F_Understand_SC_error_msg.getText().contains(text);
		}
		return this;
	}
	
	public Contact_Us_Page Turnon_Location_Robot() throws Exception {
		TurnOnGeolocation();
		Thread.sleep(2000);
		return this;
	}
	
	public Contact_Us_Page Turnoff_Locationservice_Robot() throws Exception{
		TurnOffGeolocation();
		Thread.sleep(2000);
		return this;
	}
	
public Contact_Us_Page Select_Contact_us() throws InterruptedException {
		
		SelectAnyMenu_NoArrow(HomePageconstants.Contact_us);
		
		return new Contact_Us_Page();

	}
	
	public void SelectAnyMenu_NoArrow(WebElement ele) throws InterruptedException {

		VerifyElementIsHighlighted(ele);
		Thread.sleep(2000);
		clickWithScreenshot(ele);

		if (verifyElementDisplayed(ele)) {
			logger("Element is underlined", Status.PASS);
		}

	}
	
	public Contact_Us_Page switchToFrame() {
		switchToFrame(ContactusPageConstants.Contact_form_iframe);
		System.out.println(driver.getTitle());
		driver.findElement(By.xpath("//input[@name='First name']")).sendKeys("Inside Frame");
		return this;
	}
	
	public Contact_Us_Page switchToParentFrameByDefault() {
		switchToParentFrame();
		return this;
		
	}
	
	public Contact_Us_Page Script_Pass_Logger(){
		logger("Script Pass Successfully",Status.PASS);
		return this;
	}
	
	public Contact_Us_Page Wait(int timeunit) throws InterruptedException {
		Thread.sleep(timeunit);
		return this;
	}
	
}
