package test.automation.pages;

import java.util.List;

import org.openqa.selenium.Dimension;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.PageFactory;

import com.aventstack.extentreports.Status;

import test.automation.pagelocators.RegionSelectionPageConstants;
import test.automation.globalfunctionality.TestCaseInitiator;
import test.automation.pagelocators.FooterPageConstants;
import test.automation.pagelocators.HomePageconstants;

public class Region_Selection_Page extends TestCaseInitiator {

	public Region_Selection_Page() {
		PageFactory.initElements(driver, RegionSelectionPageConstants.class);
	}


	public Region_Selection_Page Verify_Current_selection() {
		clickWebElement(RegionSelectionPageConstants.Current_selection);
		return this;
	}

	public Home_Page Click_Global_English() {
		clickWebElement(RegionSelectionPageConstants.Global_English);
		return new Home_Page();
	}

	public Region_Selection_Page Verify_Global_English() {
		verifyElementDisplayed(RegionSelectionPageConstants.Global_English);
		return  this;
	}

	public Region_Selection_Page Click_Europe() {
		clickWebElement(RegionSelectionPageConstants.Europe_region);
		return this;
	}

	public Region_Selection_Page Click_NAmerica() {
		clickWebElement(RegionSelectionPageConstants.NAmerica_region);
		return this;
	}

	public Region_Selection_Page Click_SAmerica() {
		clickWebElement(RegionSelectionPageConstants.SAmerica_region);
		return this;
	}

	public Region_Selection_Page Click_Asia() {
		clickWebElement(RegionSelectionPageConstants.Asia_region);
		return this;
	}

	public Home_Page Click_Russian() {
		clickWithScreenshot(RegionSelectionPageConstants.Russian_region);
		return new Home_Page();
	}

	public Home_Page Click_USA() throws InterruptedException {
		Thread.sleep(2000);
		clickWebElement(RegionSelectionPageConstants.USA);
		return new Home_Page();
	}

	public Home_Page Click_china() throws InterruptedException {
		Thread.sleep(2000);
		clickWebElement(RegionSelectionPageConstants.china);
		return new Home_Page();
	}
	
	public Home_Page Click_Canada() throws InterruptedException {
		Thread.sleep(2000);
		clickWebElement(RegionSelectionPageConstants.Canada);
		return new Home_Page();
	}
	
	public Footer_Page Click_china2() throws InterruptedException {
		Thread.sleep(2000);
		clickWebElement(RegionSelectionPageConstants.china);
		return new Footer_Page();
	}
	
	public Footer_Page Click_India() throws InterruptedException {
		Thread.sleep(2000);
		clickWebElement(RegionSelectionPageConstants.India);
		return new Footer_Page();
	}

	public Home_Page Click_Australia() {
		clickWebElement(RegionSelectionPageConstants.Australia);
		return new Home_Page();
	}
	
	public Home_Page Click_UK() {
		clickWebElement(RegionSelectionPageConstants.UK);
		return new Home_Page();
	}
	
	public Home_Page Click_France() {
		clickWebElement(RegionSelectionPageConstants.France);
		return new Home_Page();
	}

	public Home_Page Click_Ukraine() {
		clickWebElement(RegionSelectionPageConstants.Ukraine);
		return new Home_Page();
	}
	public Region_Selection_Page verify_PageTitle() throws InterruptedException {
		verifyPageTitle("Choose country/region/language | Danfoss");
		return this;
	}

	public Region_Selection_Page verify_Breadcrumbs() throws InterruptedException {
		verifyElementDisplayed(RegionSelectionPageConstants.breadcrumbs);
		return this;
	}

	public Footer_Page Navigate_To_Footer() throws InterruptedException {

		MoveToElement(FooterPageConstants.Ftr_primary_footer);

		return new Footer_Page();
	}

	public Footer_Page Navigate_To_Footer_sp() throws InterruptedException {
		scrollBottomOfPageJS();
		Thread.sleep(2000);
		return new Footer_Page();
	}

	public Region_Selection_Page verifyPrimaryHeadersChangeSizeonScrolling() throws InterruptedException {
		Dimension size1 = HomePageconstants.primary_header.getSize();

		int height1 = size1.height;

		scrollBottomOfPageJS();
		Thread.sleep(2000);
		Dimension size2 = HomePageconstants.primary_header.getSize();

		int height2 = size2.height;

		if(height1>height2)
		{
			logger("On Scrolling down primary header size is reduced",Status.PASS);
		}else {
			logger("On Scrolling down primary header size is not reduced",Status.FAIL);
		}

		return this;
	}

	public Region_Selection_Page verifyMenuHeadersChangeSizeonScrolling() throws InterruptedException {
		scrollTopOfPageJS();
		Thread.sleep(2000);
		Dimension size3 = HomePageconstants.menu_header.getSize();

		int height3 = size3.height;
		scrollBottomOfPageJS();
		Thread.sleep(2000);

		Dimension size4 = HomePageconstants.menu_header.getSize();

		int height4 = size4.height;
		if(height3>height4)
		{
			logger("On Scrolling down menu header size is reduced",Status.PASS);
		}else {
			logger("On Scrolling down menu header size is not reduced",Status.FAIL);
		}

		return this;
	}

	public Home_Page Click_Danfoss_Logo() throws InterruptedException {
		HomePageconstants.titleImage.click();
		logger("Danfoss Logo is clicked" , Status.PASS);
		Thread.sleep(2000);
		verifyPageTitle("Danfoss - Engineering Tomorrow | Danfoss");
		return new Home_Page();
	}

	public Region_Selection_Page MouseHover_EachRegion()  {
		MoveToElement(RegionSelectionPageConstants.Global_English);
		logger("Verification: "+RegionSelectionPageConstants.Global_English.getText()+" is underlined ", Status.PASS);
		MoveToElement(RegionSelectionPageConstants.Europe_region);
		logger("Verification: "+RegionSelectionPageConstants.Europe_region.getText()+" is underlined ", Status.PASS);
		MoveToElement(RegionSelectionPageConstants.NAmerica_region);
		logger("Verification: "+RegionSelectionPageConstants.NAmerica_region.getText()+" is underlined ", Status.PASS);
		MoveToElement(RegionSelectionPageConstants.SAmerica_region);
		logger("Verification: "+RegionSelectionPageConstants.SAmerica_region.getText()+" is underlined ", Status.PASS);
		MoveToElement(RegionSelectionPageConstants.Asia_region);
		logger("Verification: "+RegionSelectionPageConstants.Asia_region.getText()+" is underlined ", Status.PASS);
		MoveToElement(RegionSelectionPageConstants.Russian_region);
		logger("Verification: "+RegionSelectionPageConstants.Russian_region.getText()+" is underlined ", Status.PASS);
		
		return  this;
	}


	public Region_Selection_Page Verify_Coutries_Highlighted() throws InterruptedException {
		Thread.sleep(500);
		List<WebElement> country = ListOfElement("xpath", "//a[@class='country-item__link']");
		
		for (int i = 0; i < country.size(); i++) {
			VerifyElementIsHighlighted(country.get(i));
			Thread.sleep(1000);
		}
		return this;
	}

	public Region_Selection_Page Verify_Language_InCountry() {
		dynamicElementDisplayed("//a[@class='country-item__link']", "Belgium (French)");
		dynamicElementDisplayed("//a[@class='country-item__link']", "Belgium (Dutch)");
		dynamicElementDisplayed("//a[@class='country-item__link']", "Switzerland (German)");
		dynamicElementDisplayed("//a[@class='country-item__link']", "Switzerland (French)");
		return this;
	}

	public Region_Selection_Page Verfiy_Coutries_Alphabatical_order() {
		Verify_Alphabatic_Order("//a[@class='country-item__link']") ;
		return this;
	}


	public Region_Selection_Page Click_Africa() {
		clickWebElement(RegionSelectionPageConstants.Africa_region);
		return this;
	}

}
