package test.automation.pages;


import org.openqa.selenium.support.PageFactory;

import com.aventstack.extentreports.Status;

import test.automation.globalfunctionality.TestCaseInitiator;
import test.automation.pagelocators.HomePageconstants;
import test.automation.pagelocators.Service_SupportConstants;

public class Service_Support_Page extends TestCaseInitiator {

	public Service_Support_Page() {
		PageFactory.initElements(driver, Service_SupportConstants.class);
	}

	public  Service_Support_Page verify_Downloads() {
		verifyElementDisplayed(Service_SupportConstants.Downloads);
		return this;
	}
	
	public  Service_Support_Page Mousehover_Downloads() throws InterruptedException {
		VerifyElementIsHighlighted(Service_SupportConstants.Downloads);
		return this;
	}
	
	public  Service_Support_Page verify_Casestudies() {
		verifyElementDisplayed(Service_SupportConstants.Case_studies);
		return this;
	}

	public  Service_Support_Page verify_Documents() {
		verifyElementDisplayed(Service_SupportConstants.Documentation);
		return this;
	}
	
	public  Document_Page Click_Documents() {
		clickWebElement(Service_SupportConstants.Documentation);
		return new Document_Page();
	}

	public  Service_Support_Page verify_Fix_troubleshooting() {
		verifyElementDisplayed(Service_SupportConstants.Fix_troubleshooting);
		return this;
	}
	public  Service_Support_Page verify_Learning() {
		verifyElementDisplayed(Service_SupportConstants.Danfoss_learning);
		return this;
	}

	public  Service_Support_Page verify_overview() {
		verifyElementDisplayed(Service_SupportConstants.overview_link);
		return this;
	}

	public  Service_Support_Page verify_closebutton() {
		if(Service_SupportConstants.close_button.isDisplayed())
		{
			logger("Verification: Close button is displayed", Status.PASS);
		}
		return this;
	}

	public Home_Page Click_CloseButton() {
		Service_SupportConstants.close_button.click();
		return new Home_Page();
		
	}
	
	public  Downloads_Page Click_Downloads() {
		clickWithScreenshot(Service_SupportConstants.Downloads);
		return new Downloads_Page();
	}

	public  Casestudies_Page Click_Case_studies() {
		clickWithScreenshot(Service_SupportConstants.Case_studies);
		return new Casestudies_Page();
	}
	public  Service_Support_Page Click_overview() {
		clickWithScreenshot(Service_SupportConstants.overview_link);
		return this;
	}
	
	public  Home_Page Navigate_homepage() {
		clickWebElement(HomePageconstants.titleImage);
			return new Home_Page();
		}
	public  Service_Support_Page Script_Pass_Logger(){
		logger("Script Pass Successfully",Status.PASS);
		return this;
	}
}
