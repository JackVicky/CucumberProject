package test.automation.pages;


import org.openqa.selenium.support.PageFactory;

import com.aventstack.extentreports.Status;

import test.automation.globalfunctionality.TestCaseInitiator;
import test.automation.pagelocators.HomePageconstants;
import test.automation.pagelocators.MarketPageconstants;


public class Market_Page extends TestCaseInitiator {

	public Market_Page() {
		PageFactory.initElements(driver, MarketPageconstants.class);
	}
	
	public  Market_Page VerifyAutomotives() {
		verifyElementDisplayed(MarketPageconstants.Automotive);
		return this;
	}
	
	public  Market_Page VerifyBuildingsCommercial() {
		verifyElementDisplayed(MarketPageconstants.Buildings_commercial);
		return this;
	}
	
	public  Market_Page VerifyBuildingsResidential() {
		verifyElementDisplayed(MarketPageconstants.Buildings_residential);
		return this;
	}
	
	public  Market_Page VerifyDistrictEnergy() {
		verifyElementDisplayed(MarketPageconstants.District_energy);
		return this;
	}
	
	public  Market_Page VerifyEnergyNaturalResources() {
		verifyElementDisplayed(MarketPageconstants.Energy_natural_resources);
		return this;
	}
	
	public  Market_Page VerifyFood_Beverage() {
		verifyElementDisplayed(MarketPageconstants.Food_beverage);
		return this;
	}
	
	public  Market_Page VerifyIndustry() {
		verifyElementDisplayed(MarketPageconstants.Industry);
		return this;
	}
	
	public  Market_Page VerifyMarineOffshore() {
		verifyElementDisplayed(MarketPageconstants.Marine_offshore);
		return this;
	}
	
	public  Market_Page VerifyMobile_hydraulics() {
		verifyElementDisplayed(MarketPageconstants.Mobile_hydraulics);
		return this;
	}
	
	public  Market_Page VerifyRefrigeration_airconditioning() {
		verifyElementDisplayed(MarketPageconstants.Refrigeration_airconditioning);
		return this;
	}
	
	public  Market_Page VerifyWater_wastewater() {
		verifyElementDisplayed(MarketPageconstants.Water_wastewater);
		return this;
	}
	
	public  Market_Page VerifyAll_markets() {
		verifyElementDisplayed(MarketPageconstants.All_markets);
		return this;
	}
	
	public  Market_Page Verifyclosebutton() {
		verifyElementDisplayed(MarketPageconstants.close_button);
		return this;
	}
	
	public  Home_Page Click_CloseButton() {
		MarketPageconstants.close_button.click();
		return new Home_Page();
	}
	
	public  Market_Page Mousehover_Automotive() {
		MoveToElement(MarketPageconstants.Automotive);
		return this;
	}
	
	public  Market_Page Click_Automotive() {
		clickWithScreenshot(MarketPageconstants.Automotive);
		return this;
	}
	
	public  Market_Page VerifyPagetitle() throws InterruptedException {
		verifyPageTitle("Efficient power module solutions for the automotive and transport industries | Danfoss");
		return this;
	}
	public  Home_Page Navigate_homepage() {
		clickWebElement(HomePageconstants.titleImage);
			return new Home_Page();
		}
	
	public Market_Page Script_Pass_Logger(){
		logger("Script Pass Successfully",Status.PASS);
		return this;
	}
}
