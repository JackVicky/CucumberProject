package test.automation.pages;

import org.openqa.selenium.By;
import org.openqa.selenium.support.PageFactory;

import com.aventstack.extentreports.Status;

import test.automation.globalfunctionality.TestCaseInitiator;
import test.automation.pagelocators.AboutDanfossPageConstants;
import test.automation.pagelocators.HomePageconstants;


public class About_Danfoss_Page extends TestCaseInitiator {

	public About_Danfoss_Page() {
		PageFactory.initElements(driver, AboutDanfossPageConstants.class);
	} 

	public About_Danfoss_Page VerifySecondLevel_Menu() {
		if(AboutDanfossPageConstants.Second_level_menu.isDisplayed())

		{
			logger("Verification: Second level menu  is displayed", Status.PASS);
		}
		else 
		{
			logger("Verification: Second level menu is not displayed", Status.FAIL);
		}

		return this;
	}

	public Event_Page Click_Events() throws InterruptedException {
		driver.findElement(By.xpath("//span[text()='News and events']")).click();
		driver.findElement(By.xpath("//span[text()='Events']")).click();
		Thread.sleep(3000);
		return new Event_Page();
	}

	public News_Page Click_News() {
		driver.findElement(By.xpath("//span[text()='News and events']")).click();
		driver.findElement(By.xpath("//span[text()='News']")).click();
		return new News_Page();
	}

	public About_Danfoss_Page VerifySecondLevel_MenuArrow() {

		if(AboutDanfossPageConstants.Second_LevelMenu_arrow.isDisplayed())
		{
			logger("Verification: Second level menu arrow is displayed", Status.PASS);
		}
		else 
		{
			logger("Verification: Second level menu arrow is not displayed", Status.FAIL);
		}
		return this;
	}

	public About_Danfoss_Page VerifyThirdLevel_Menu() {
		if(AboutDanfossPageConstants.third_level_menu.isDisplayed())
		{
			logger("Verification: Third level menu is displayed", Status.PASS);
		}
		else 
		{
			logger("Verification: Third level menu is displayed", Status.FAIL);
		}


		return this;
	}

	public About_Danfoss_Page VerifyFourthLevel_Menu() {
		if(AboutDanfossPageConstants.Fourth_LevelMenu_Container.isDisplayed())
		{
			logger("Verification: Fourth level menu is displayed", Status.PASS);
		}
		else 
		{
			logger("Verification: Fourth level menu is displayed", Status.FAIL);
		}

		return this;
	}

	public About_Danfoss_Page VerifyClose_Button() {

		if(AboutDanfossPageConstants.Company_close.isDisplayed())

		{
			logger("Verification: Close button is displayed", Status.PASS);
		}

		return this;
	}

	public Home_Page Click_CloseButton() {
		AboutDanfossPageConstants.Company_close.click();
		return new Home_Page();
	}
	public About_Danfoss_Page VerifyOverview() {
		verifyElementDisplayed(AboutDanfossPageConstants.Company_overview);
		return this;
	}

	public About_Danfoss_Page MouseHoveronCompany() throws InterruptedException {
		VerifyElementIsHighlighted(AboutDanfossPageConstants.Company);
		return this;
	}

	public About_Danfoss_Page Click_Company() {
		clickWithScreenshot(AboutDanfossPageConstants.Company);
		return this;
	}
	public About_Danfoss_Page VerifyThirdlevel_Menu_EachPage() throws InterruptedException {
		clickWebElement(AboutDanfossPageConstants.Engineering_tomorrow);
		verifyPageTitle("Quality, reliability and innovation since 1933 - Learn how Danfoss is engineering tomorrow | Danfoss");
		Thread.sleep(1000);
		HomePageconstants.About_danfoss.click();
		clickWebElement(AboutDanfossPageConstants.foundations);
		verifyPageTitle("Foundations | Danfoss");
		Thread.sleep(1000);
		HomePageconstants.About_danfoss.click();
		Thread.sleep(1000);
		clickWebElement(AboutDanfossPageConstants.sustainability);
		verifyPageTitle("Sustainability | Danfoss");
		Thread.sleep(1000);
		HomePageconstants.About_danfoss.click();
		Thread.sleep(1000);
		clickWebElement(AboutDanfossPageConstants.history);
		verifyPageTitle("Danfoss - The journey to Engineering Tomorrow | Danfoss");
		Thread.sleep(1000);
		HomePageconstants.About_danfoss.click();
		Thread.sleep(1000);
		clickWebElement(AboutDanfossPageConstants.management);
		verifyPageTitle("Management | Danfoss");
		Thread.sleep(2000);
		HomePageconstants.About_danfoss.click();
		Thread.sleep(2000);
		clickWebElement(AboutDanfossPageConstants.financials_new_prod);
		Thread.sleep(1000);
		verifyPageTitle("Find latest financial information | Danfoss");
		Thread.sleep(1000);
		HomePageconstants.About_danfoss.click();
		clickWebElement(AboutDanfossPageConstants.procurement);
		verifyPageTitle("Procurement | Danfoss");
		Thread.sleep(1000);
		HomePageconstants.About_danfoss.click();
		return this;
	}

	public About_Danfoss_Page VerifyFourthlevel_Menu_Page() throws InterruptedException {
		clickWebElement(AboutDanfossPageConstants.Group_executive);
		verifyPageTitle("Group Executive Team | Danfoss");
		return this;
	}

	public  Home_Page Navigate_homepage() {
		clickWebElement(HomePageconstants.titleImage);
		return new Home_Page();
	}

	public About_Danfoss_Page Mousehover_Company_Russian() throws InterruptedException {
		VerifyElementIsHighlighted(AboutDanfossPageConstants.Russian_Company);
		return this;
	}
	public About_Danfoss_Page Click_Company_Russian() {
		clickWebElement(AboutDanfossPageConstants.Russian_Company);
		return this;
	}


	public About_Danfoss_Page Verify_Russian_Companytitle() throws InterruptedException {
		verifyPageTitle("Danfoss — инженерные разработки с 1933 года. Узнайте больше о нашей инновационной компании | Danfoss");
		
		return this;
	}
	
	public  About_Danfoss_Page Script_Pass_Logger(){
		logger("Script Pass Successfully",Status.PASS);
		return this;
	}
}
