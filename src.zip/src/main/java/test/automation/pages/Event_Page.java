package test.automation.pages;

import java.util.List;

import org.apache.poi.util.SystemOutLogger;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.PageFactory;

import com.aventstack.extentreports.Status;

import test.automation.globalfunctionality.TestCaseInitiator;
import test.automation.pagelocators.EventPageconstants;
import test.automation.pagelocators.HomePageconstants;

public class Event_Page extends TestCaseInitiator {

	public Event_Page() {
		PageFactory.initElements(driver, EventPageconstants.class);
	}

	public  Event_Page verify_EventsTitle() throws InterruptedException {
		waitForPageLoad();
		driver.navigate().refresh();
		verifyPageTitle("Events | Danfoss");
		return this;
	}


	public  Home_Page Navigate_homepage() {
		clickWebElement(HomePageconstants.titleImage);
		return new Home_Page();
	}

	public  Event_Page Click_Business_filter(String str) throws InterruptedException {
		Thread.sleep(3000);
		//dynamicElementselector("((//div[contains(@class,'filters-group__items')])//descendant::span[@class='filters-group__item__title'])", str);
		dynamicElementselector("//div[contains(text(),'Business unit')]/following-sibling::div/ul/li/div",str);
		return this;
	}


	public  Event_Page Verify_Business_filtervalue(String str) throws InterruptedException {
		dynamicElementDisplayed("(//div[@class='filters-group__item'])//descendant::span[@class='filters-group__item__title']", str);

		return this;
	}

	public  Event_Page Click_EventCategories_filter(String str) throws InterruptedException {
		Thread.sleep(3000);
		dynamicElementselector("((//div[contains(@class,'filters-group__items')])//descendant::span[@class='filters-group__item__title'])", str);
		return this;
	}
	
	public Event_Page Click_EventCategories_filter_value(String value) throws InterruptedException{
		Thread.sleep(2000);
		driver.findElement(By.xpath("//*[text()='"+value+"']")).click();
		return this;
	}
	
	/*
	 * public Event_Page Click_EventCategories_filter(String str) throws
	 * InterruptedException {
	 * 
	 * dynamicElementselector(
	 * "((//div[contains(@class,'filters-group__items')])//descendant::span[@class='filters-group__item__title'])",
	 * str); return this; }
	 * 
	 * ((//div[contains(@class,'filters-group__items')])//descendant::span[@class='
	 * filters-group__item__title'])[18]
	 */
	public  Event_Page Verify_Url(String str1) throws InterruptedException {
		Thread.sleep(1000);
		if(driver.getCurrentUrl().contains(str1))
		{
			logger("Verification: Selected Filter is updated in the URL" , Status.PASS);
		}
		else
		{
			logger("Verification: URL does not contain filters" , Status.FAIL);
		}
		return this;
	}

	public  Event_Page Verify_Url_NoFilter(String str1) throws InterruptedException {
		Thread.sleep(1000);
		if(!driver.getCurrentUrl().contains(str1))
		{
			logger("Verification: Filter are not available in updated URL" , Status.PASS);
		}
		else
		{
			logger("Verification: Filter are  available in updated URL" , Status.FAIL);
		}
		return this;
	}

	public  Event_Page Verify_clear_filter() throws InterruptedException {
		verifyElementDisplayed(EventPageconstants.clear_filter);
		return this;
	}

	public  Event_Page Click_Clear_filter() throws InterruptedException {
		clickWebElement(EventPageconstants.clear_filter);
		return this;
	}
	public  Event_Page Verify_No_clear_filter() throws InterruptedException {
		verifyElementNotDisplayed("//button[contains(@class,'reset-filter-button')]//descendant::span[@class='cta-content-text']");
		return this;
	}

	public  Event_Page Verify_Item_Count() throws InterruptedException {
		Thread.sleep(2000);
		String text = EventPageconstants.numberofresult.getText();
		//String substring = text.substring(text.indexOf(':'), text.lastIndexOf(text)-1);
		logger("Information:  "+text , Status.INFO);
		return this;
	}

	public  Event_Page Verify_Filter_Section() throws InterruptedException {
		Thread.sleep(4000);
		if(EventPageconstants.filter.isDisplayed())
		{
			logger("Verification: Filter section is displayed", Status.PASS);
		}
		else
		{
			logger("Verification: Filter section is not displayed", Status.FAIL);
		}
		return this;
	}

	public  Event_Page Verify_Breadcrumbs() throws InterruptedException {
		Thread.sleep(3000);
		if(EventPageconstants.breadcrumbs1.isDisplayed() && EventPageconstants.breadcrumbs2.isDisplayed())
		{
			logger("Verification: Breadcrumb is displayed", Status.PASS);
		}
		else
		{
			logger("Verification: Breadcrumb is not displayed", Status.FAIL);
		}
		return this;
	}

	public  Event_Page Verify_Page_heading() throws InterruptedException {
		VerifyElementIsClickable(EventPageconstants.Page_heading);
		if(verifyElementDisplayed(EventPageconstants.Page_heading))
		{
			logger("Verification: Page title is displayed in H1 format in top of the page", Status.PASS);
		}

		else
		{
			logger("Verification: Page title is not displayed in H1 format in top of the page", Status.FAIL);
		}
		return this;

	}

	public  Event_Page Verify_Countries_filter() throws InterruptedException {
		verifyElementDisplayed(EventPageconstants.Countries_filter);
		if(EventPageconstants.Countries_filters_collapsed.isDisplayed())
		{
			logger("Verification: Countries Type filter is collapsed by default and Arrow is pointed down", Status.PASS);
		}
		else
		{
			logger("Verification: Countries Type filter is not collapsed ", Status.FAIL);
		}
		return this;
	}

	public  Event_Page Verify_EventCategories_filter() throws InterruptedException {
		verifyElementDisplayed(EventPageconstants.Event_Categories_filter);
		if(EventPageconstants.Event_Categories_filters_collapsed.isDisplayed())
		{
			logger("Verification: Event Categories Type filter is collapsed by default and Arrow is pointed down", Status.PASS);
		}
		else
		{
			logger("Verification: Event Categories Type filter is not collapsed ", Status.FAIL);
		}
		return this;
	}

	public  Event_Page Verify_Megatrends_filter() throws InterruptedException {
		verifyElementDisplayed(EventPageconstants.Megatrends_filter);
		if(EventPageconstants.Megatrends_filters_collapsed.isDisplayed())
		{
			logger("Verification: Event Categories Type filter is collapsed by default and Arrow is pointed down", Status.PASS);
		}
		else
		{
			logger("Verification: Event Categories Type filter is not collapsed ", Status.FAIL);
		}
		return this;
	}

	public  Event_Page Click_EventCategories_filter() throws InterruptedException {
		
		//dynamicElementselector("(//div[@class='filters-group__heading'])[2]", "Event categories");
		driver.findElement(By.xpath("(//div[@class='filters-group__heading'])[2]")).click();
		Thread.sleep(2000);
		return this;
	}


	public  Event_Page Verify_Market_filter() throws InterruptedException {
		verifyElementDisplayed(EventPageconstants.Market_filter);
		if(EventPageconstants.Market_filters_collapsed.isDisplayed())
		{
			logger("Verification: Event Categories Type filter is collapsed by default and Arrow is pointed down", Status.PASS);
		}
		else
		{
			logger("Verification: Event Categories Type filter is not collapsed ", Status.FAIL);
		}
		return this;
	}

	public  Event_Page Verify_Business_filter() throws InterruptedException {

		if(dynamicElementDisplayed("//div[contains(@class,'filters-group__items-wrapper_expanded')]//preceding-sibling::div[@class='filters-group__heading']", "Business unit"))

		{
			logger("Verification: Business filter is expanded by default and Arrow is pointed up", Status.PASS);
		}
		else
		{
			logger("Verification: Business filter is not expanded ", Status.FAIL);
		}
		return this;
	}


	public  Event_Page Verify_Alphaticalorder_Filteroptions() throws InterruptedException {
		logger("Below steps will check filter values in each filters are arranged in alphabatical order", Status.INFO);
		try {
			Verify_Alphabatic_Order("(//div[contains(@class,'filters-group__items-wrapper')])[1]//descendant::span[@class='filters-group__item__title']");
			Verify_Alphabatic_Order("(//div[contains(@class,'filters-group__items-wrapper')])[2]//descendant::span[@class='filters-group__item__title']");
			Verify_Alphabatic_Order("(//div[contains(@class,'filters-group__items-wrapper')])[3]//descendant::span[@class='filters-group__item__title']");
			Verify_Alphabatic_Order("(//div[contains(@class,'filters-group__items-wrapper')])[4]//descendant::span[@class='filters-group__item__title']");
		} catch (Exception e) {
			System.out.println(e);
			e.printStackTrace();
		}
		return this;

	}

	public  Event_Page Verify_FilterisSelected(String str) throws InterruptedException {
		if(dynamicElementDisplayed("//span[contains(@class,'checked-true')]//following-sibling::span[@class='filters-group__item__title']", str));
		{
			logger("Verification: "+str+ " is selected", Status.PASS);

		}
		return this;
	}


	public  Event_Page Verify_Highlighted_filterValues() throws InterruptedException {
		WebElement ele = driver.findElement(By.xpath("((//div[contains(@class,'filters-group__items')])[4]//descendant::span[@class='filters-group__item__title'])[1]"));
		VerifyElementIsHighlighted(ele);
		return this;
	}

	public  Event_Page Verify_SelectedFilter_In_Applied(String str) throws InterruptedException {
		Thread.sleep(2000);
		String text = driver.findElement(By.xpath("(//div[@class='unselect-buttons-group']//descendant::span[@class='cta__content-text'])[1]")).getText();
		if(text.contains(str))

		{
			logger("Verification: "+str+ " is added in the applied filter section", Status.PASS);

			if(EventPageconstants.Applied_filter_close.isDisplayed())
			{
				logger("Verification: "+str+ " contains close button", Status.PASS);

			}
			else {

				logger("Verification: "+str+ " not contains close button", Status.FAIL);
			}
		}
		else {

			logger("Verification: "+str+ "is not added in the applied filter section", Status.FAIL);

		}

		return this;
	}


	public  Event_Page Verify_Highlighted_AppliedFilter() throws InterruptedException {
		WebElement ele = driver.findElement(By.xpath("(//div[@class='unselect-buttons-group']//descendant::span[@class='cta__content-text'])[1]"));
		VerifyElementIsHighlighted(ele);
		return this;
	}


	public  Event_Page Deselect_Filters() throws InterruptedException {
		try {
			List<WebElement> findElementsByXPath = driver.findElements(By.xpath("//div[@class='unselect-buttons-group']//descendant::span[@class='icon icon-cancel']"));
			for (int i = 0; i < findElementsByXPath.size(); i++) {
				findElementsByXPath.get(i).click();
			}
			Thread.sleep(2000);
			loggerWithScreenshot("Verification: Filters are removed in applied filter and also it filter section", "", Status.PASS, true);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		return this;
	}

	public  Event_Page Verify_SortButton_withoptions() throws InterruptedException {
		verifyElementDisplayed(EventPageconstants.sort_button);
		Thread.sleep(2000);
		driver.findElement(By.xpath("//select[@class='sort-select cta cta--small cta--block']")).click();
		
		if(EventPageconstants.Now_future.isDisplayed())
		{
			loggerWithScreenshot("Verification: The element Now -> Future is displayed and it is Default value", "", Status.PASS, true);
		}
		verifyElementDisplayed(EventPageconstants.Now_future);
		verifyElementDisplayed(EventPageconstants.future_now);
		verifyElementDisplayed(EventPageconstants.Past);
		verifyElementDisplayed(EventPageconstants.sort_title_asc);
		verifyElementDisplayed(EventPageconstants.sort_title_desc);

		return this;
	}
	
	public Event_Page Click_Sort_With_Value(String str) {
		
		driver.findElement(By.xpath("//select[@class='sort-select cta cta--small cta--block']")).click();
		
		int size = driver.findElements(By.xpath("//span[@class='sort-icons']//following-sibling::span[@class='cta-content-text']//following::option")).size();
		for(int i=1;i<=size;i++) {
			WebElement ele = driver.findElement(By.xpath("(//span[@class='sort-icons']//following-sibling::span[@class='cta-content-text']//following::option)["+i+"]"));
			String option = ele.getText();
			if(option.contains(str)) {
				clickWebElement(ele);
			}
		}
		return this;
	}

	public Event_Page Verify_items_AscendingOrder()

	{

		clickWebElement(EventPageconstants.sort_title_asc);
		Verify_Alphabatic_Order("//div[@class='tile__text-title']");
		return this;

	}

	public Event_Page Verify_Result_Tile() throws InterruptedException {
		if(EventPageconstants.Item_Tile.isDisplayed())
		{
			logger("Verification: Tites are displayed", Status.PASS);
		}

		else {
			logger("Verification: Tiles are not displayed", Status.FAIL);
		}
		return this;
	}

	public  Event_Page Verify_Result_Tile_Content() throws InterruptedException {
		if(EventPageconstants.Tile_title.isDisplayed())
		{
			logger("Verification: Tile Title is displayed", Status.PASS);

			if(EventPageconstants.Tile_image.isDisplayed())
			{ 
				logger("Verification: Tile image is displayed", Status.PASS);


				if(EventPageconstants.Tile_description.isDisplayed())
				{ 
					logger("Verification: Tile description is displayed", Status.PASS);


					if(EventPageconstants.Tile_date.isDisplayed())
					{ 
						String text = EventPageconstants.Tile_date.getText();
						logger("Verification: Event details is displayed as: "+text, Status.PASS);

					}
				}
			}
		}

		else 
		{
			loggerWithScreenshot("Verification: Issue with tiles", "", Status.FAIL, true);
		}

		return this;
	}


	public  Event_Page Verify_Pagination() throws InterruptedException {
		if(EventPageconstants.pagination.isDisplayed())
		{
			logger("Verification: Pagination are displayed", Status.PASS);
		}

		else {
			logger("Verification: Pagination are not displayed", Status.FAIL);
		}
		return this;
	}


}
