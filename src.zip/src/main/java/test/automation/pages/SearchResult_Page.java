package test.automation.pages;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import com.aventstack.extentreports.Status;
import com.gargoylesoftware.htmlunit.WebConsole.Logger;

import test.automation.pages.SearchResult_Page;
import test.automation.globalfunctionality.TestCaseInitiator;
import test.automation.pagelocators.HomePageconstants;
import test.automation.pagelocators.SearchResultPageConstants;


public class SearchResult_Page extends TestCaseInitiator{

	public SearchResult_Page() {
		PageFactory.initElements(driver, SearchResultPageConstants.class);
	} 

	/////////////////////Common///////////////////////////////////////////////////

	public SearchResult_Page Verify_DidYouMean() {
		if(SearchResultPageConstants.did_you_mean.isDisplayed())
		{
			loggerWithScreenshot("Verification: Did you mean text is displayed with Suggestion", "", Status.PASS, true);
		}
		else
		{
			logger("Verification: Did you mean text is not displayed", Status.FAIL);
		}
		return this;
	}

	public SearchResult_Page Verify_SuggestedValue() {
		if((SearchResultPageConstants.did_you_mean.isDisplayed()))
		{
			MoveToElement(SearchResultPageConstants.did_you_mean);
			logger("Verification: Suggested value is highlighted on Mousehover", Status.PASS);
		}

		return this;
	}

	public SearchResult_Page Verify_No_DidYouMean() {
		List<WebElement> didyoumean = driver.findElements(By.xpath("//div[@class='list-total-count']"));

		if(didyoumean.size()==0)
		{
			logger("Verification: Did you mean text is not displayed", Status.PASS);
		}

		return this;

	}

	public SearchResult_Page Click_SuggestedValue() {
		clickWebElement(SearchResultPageConstants.suggested_value);
		return this;
	}

	public SearchResult_Page Verify_SearchPage_title() {
		verifyElementDisplayed(SearchResultPageConstants.Search_page_title);
		return this;
	}

	public SearchResult_Page Verify_SearchPage_title(String text) throws InterruptedException {
		Thread.sleep(3000);
		verifyElementDisplayed(SearchResultPageConstants.Search_page_title);
		if(SearchResultPageConstants.Search_page_title.getText().contains(text))
		{
			logger("Verification: Result title contains the search term: '" +text+ "'", Status.PASS);
		}
		else
		{
			logger("Verification: Result title not contains the search term " +text, Status.FAIL);
		}
		return this;
	}

	public SearchResult_Page Verify_ActiveTab(String text) throws InterruptedException
	{
		Thread.sleep(3000);
		if(SearchResultPageConstants.active_filter_tab.getText().contains(text))
		{
			logger("Verification: Active tab is :  "+text, Status.PASS);
		}
		else
		{
			logger("Verification: Active tab is not as expected", Status.FAIL);
		}
		return this;
	}

	public SearchResult_Page Verify_Filter_Section() {

		if((SearchResultPageConstants.filter_section.isDisplayed()))
		{
			logger("Verification: Filter section is available", Status.PASS);
		}
		return this;
	}

	public SearchResult_Page Verify_Zero_Result_Title() {
		verifyElementDisplayed(SearchResultPageConstants.Zero_result_title);
		return this;
	}
	public SearchResult_Page Verify_Zero_Result_tips() {
		verifyElementDisplayed(SearchResultPageConstants.Zero_result_tips);
		return this;
	}

	public SearchResult_Page Verify_Zero_Result_Description1() {
		verifyElementDisplayed(SearchResultPageConstants.Zero_result_description1);
		return this;
	}

	public SearchResult_Page Verify_Zero_Result_Description2() {
		verifyElementDisplayed(SearchResultPageConstants.Zero_result_description2);
		return this;
	}


	public SearchResult_Page Verify_Zero_Result_Description3() {
		verifyElementDisplayed(SearchResultPageConstants.Zero_result_description3);
		return this;
	}


	public SearchResult_Page Verify_Pagination() {
		if(SearchResultPageConstants.pagination.isDisplayed())
		{
			logger("Verification: Pagination is available", Status.PASS);
		}

		return this;

	}


	public SearchResult_Page Verify_Result_section() {
		if(SearchResultPageConstants.Result_section.isDisplayed())
		{
			logger("Verification: Result section is available", Status.PASS);
		}

		return this;

	}
	public SearchResult_Page Verify_NoPagination() {
		List<WebElement> Nopagenation = driver.findElements(By.xpath("//ul[@class='pagination']"));

		if(Nopagenation.size()==0)
		{
			logger("Verification: Pagination is not available", Status.PASS);
		}
		return this;
	}

	public  Home_Page Navigate_homepage() {
		HomePageconstants.titleImage.click();
		logger("Verification: Navigate to Homescreen", Status.PASS);
		return new Home_Page();
	}

	public SearchResult_Page Verify_AllResult() {
		verifyElementDisplayed(SearchResultPageConstants.All_result);

		return this;
	}

	public SearchResult_Page Click_AllResult_tab() {
		clickWithScreenshot(SearchResultPageConstants.All_result);
		return this;
	}

	public SearchResult_Page Verify_Rightslide_Icon() {
		verifyElementDisplayed(SearchResultPageConstants.Rightslide_icon);
		return this;
	}

	public SearchResult_Page Verify_Leftslide_Icon() {
		verifyElementDisplayed(SearchResultPageConstants.Leftslide_icon);
		return this;
	}

	public SearchResult_Page Click_Rightslide_Icon() {
		try {
			SearchResultPageConstants.Rightslide_icon.click();
			logger("Verification: User is scrolled to till the end of all tabs", Status.PASS);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return this;
	}

	public SearchResult_Page Click_Leftslide_Icon() {
		try {
			SearchResultPageConstants.Leftslide_icon.click();
			logger("Verification: User is scrolled to leftside of all tabs", Status.PASS);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return this;
	}

	public SearchResult_Page Click_Partialvisible_tab(String txt) {
		if(txt.contains("Усі результати"))
		{			
			Click_AllResult_tab();
		}		
		if(txt.contains("Каталог навчальних курсів"))
		{
			Click_learning_tab();
		}

		return this;
	}


	public SearchResult_Page Verify_PMP_Result() {

		verifyElementDisplayed(SearchResultPageConstants.product_tile_txt);
		verifyElementDisplayed(SearchResultPageConstants.product_tile_img);
		verifyElementDisplayed(SearchResultPageConstants.product_tile_segment);
		if(SearchResultPageConstants.product_tile_desc.isDisplayed())
		{
			logger("Verification: product description is displayed", Status.PASS);
		}

		return this;
	}

	public SearchResult_Page Verify_Product_hybris_Result() {

		verifyElementDisplayed(SearchResultPageConstants.product_tile_txt);
		verifyElementDisplayed(SearchResultPageConstants.product_tile_img);
		verifyElementDisplayed(SearchResultPageConstants.product_tile_segment);
		verifyElementDisplayed(SearchResultPageConstants.product_tile_desc);
		if(SearchResultPageConstants.product_tile_extn_link.isDisplayed())
		{
			logger("Verification: External product icon is displayed", Status.PASS);
		}

		return this;
	}

	public SearchResult_Page Verify_Product_hybris_Result_Noimg() throws InterruptedException {

		verifyElementDisplayed(SearchResultPageConstants.product_tile_txt);
		verifyElementDisplayed(SearchResultPageConstants.product_tile_segment);
		//verifyElementDisplayed(SearchResultPageConstants.product_tile_desc
		return this;
	}

	public SearchResult_Page Verify_Product_hybris_Attribute() {

		try {
			List<WebElement> attribute_key = ListOfElement("xpath", "(//div[contains(@class,'attributes')])[1]//child::table//child::td[contains(@class,'key')]");
			List<WebElement> attribute_value = ListOfElement("xpath", "(//div[contains(@class,'attributes')])[1]//child::table//child::td[contains(@class,'cell')][2]");
			for (int i = 0; i < attribute_key.size(); i++) {

				verifyElementDisplayed(attribute_key.get(i));
				verifyElementDisplayed(attribute_value.get(i));

			}logger("Verification: Attribute section is displayed in two coloumns" , Status.PASS);
		} catch (Exception e) {

			e.printStackTrace();
			logger("Verification: Error occured in attribute section", Status.FAIL);
		}

		return this;
	}

	public SearchResult_Page Verify_Product_hybris_Attribute_Alphaorder() {

		Verify_Alphabatic_Order("(//div[contains(@class,'attributes')])[1]//child::table//child::td[contains(@class,'key')]");

		return this;
	}

	public SearchResult_Page Verify_count_Attribute() {

		try {
			List<WebElement> attribute_key = ListOfElement("xpath", "(//div[contains(@class,'attributes')])[1]//child::table//child::td[contains(@class,'key')]");

			if(attribute_key.size()<=4)
			{
				logger("Verification: Attribute count is 4 in when show more button  is displayed" , Status.PASS);
			}

			if(attribute_key.size()>4)
			{
				logger("Verification: Attribute count is more than 4 in when show less button is displayed" , Status.PASS);
			}

		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			logger("Verification: Error occured in attribute section", Status.FAIL);
		}

		return this;
	}

	public SearchResult_Page Verify_Product_tags() {
		verifyElementDisplayed(SearchResultPageConstants.product_segment_tags);
		return this;
	}
	
	public SearchResult_Page Verify_ValidFor_Tag() {
		//verifyPartialText(SearchResultPageConstants.product_segment_tags,"Valid for: Multiple");
		//verifyPartialText(SearchResultPageConstants.product_segment_tags,"EU Declaration | English | .pdf | 40.7 KB | Valid for: Multiple");
		verifyPartialText(SearchResultPageConstants.product_segment_tags,"Pump, High Pressure Pumps");
		return this;
	}
	
	public SearchResult_Page Verify_ValidFor_Tag_French() {
		//verifyPartialText(SearchResultPageConstants.product_segment_tags,"Valide pour: France");
		//verifyPartialText(SearchResultPageConstants.product_segment_tags,"Guide d'application | français, langue française | .pdf | 465.47 KB | Dernière modification: 30 mars 2021 | Valide pour: France");
		verifyPartialText(SearchResultPageConstants.product_segment_tags, "Climate Solutions for cooling");
		return this;
	}
	
	

	public SearchResult_Page Click_Show_more() {
		clickWebElement(SearchResultPageConstants.product_atrribute_show_more);
		return this;
	}

	public SearchResult_Page Verify_Show_more() {
		verifyElementDisplayed(SearchResultPageConstants.product_atrribute_show_more);
		return this;
	}
	public SearchResult_Page Verify_highlighted_tile() throws InterruptedException {
		VerifyElementIsHighlighted(SearchResultPageConstants.product_tile_txt);
		return this;
	}

	public SearchResult_Page Click_Product_item() throws InterruptedException {
		Thread.sleep(4000);
		clickWebElement(SearchResultPageConstants.product_FirstProduct);
		/*
		 * if(VerifyElementIsClickableForAlert(HomePageconstants.acceptcookies)){
		 * clickWebElement(HomePageconstants.acceptcookies);
		 * logger("INFO: Accept cookie pop-up is appear" , Status.INFO); } else {
		 * logger("INFO: Accept cookie pop-up is not appear" , Status.INFO); }
		 */
		return this;
	}
	
	public  SearchResult_Page AcceptCookies() throws InterruptedException {
		Thread.sleep(3000);
		if(VerifyElementIsClickable(HomePageconstants.acceptcookies)){
			clickWebElement(HomePageconstants.acceptcookies);	
		}	
		else {
			logger("INFO: Accept cookie pop-up is not appear" , Status.INFO);
		}
		return this;
	}
	
	public SearchResult_Page Click_Software_item_() {
		VerifyElementIsClickable(SearchResultPageConstants.software_result1);
		clickJSWebElement(SearchResultPageConstants.software_result1);
		return this;
	}

	public SearchResult_Page Verify_Productstore_Page(String str) throws InterruptedException {
		switchToWindow(1);
		String currentUrl = driver.getCurrentUrl();
		Thread.sleep(2500);
		if(currentUrl.contains(str))
		{
			logger("Verification: Correct Product store page is displayed ", Status.PASS);
		}
		else
		{
			logger("Verification: Correct Product store page is not displayed ", Status.INFO);
		}
		
		return this;
	}

	public SearchResult_Page Verify_product_page_title(String str) throws InterruptedException {
		verifyPageTitle(str);
		return this;
	}

	public SearchResult_Page Verify_ProductResult_158699() {

		if(SearchResultPageConstants.product_tile_txt.isDisplayed() && SearchResultPageConstants.product_tile_img.isDisplayed()
				&& SearchResultPageConstants.product_tile_segment.isDisplayed() && SearchResultPageConstants.product_tile_desc.isDisplayed() 
				&& SearchResultPageConstants.product_tile_extn_link.isDisplayed())
		{
			logger("Verification: Internal and External product pages are displayed with Title, image, External Icon, Description, segment", Status.PASS);
		}
		else {
			logger("Verification: Issue with product results", Status.FAIL);
		}
		return this;
	}


	public SearchResult_Page Verify_AllResult_count() throws InterruptedException {
		Thread.sleep(2000);
		if(SearchResultPageConstants.All_result.getText().matches("([0-9]+)"));
		{
			String substring = SearchResultPageConstants.All_result.getText().substring(SearchResultPageConstants.All_result.getText().indexOf('('), SearchResultPageConstants.All_result.getText().indexOf(')'));
			logger("Verification: AllResult Tab contains number of result: "+substring+")", Status.PASS);
		}

		return this;
	}

	public SearchResult_Page Verify_Products_count() {

		if(SearchResultPageConstants.products_tab.getText().matches("([0-9]+)"));
		{
			String substring = SearchResultPageConstants.products_tab.getText().substring(SearchResultPageConstants.products_tab.getText().indexOf('('), SearchResultPageConstants.products_tab.getText().indexOf(')'));
			logger("Verification: Products Tab contains number of result: "+substring+")", Status.PASS);
		}

		return this;
	}





	public SearchResult_Page Verify_zoomin() {
		Perform_Zoom_In();
		return this;
	}

	public SearchResult_Page Select_Pagination(int i) {
		driver.findElement(By.xpath("//ul[@class='pagination']//child::li[1+"+i+"]")).click();
		logger("Verification: Page number: "+i+" is clicked", Status.PASS);
		return this;
	}

	public SearchResult_Page Verify_Product_tab() {
		verifyElementDisplayed(SearchResultPageConstants.products_tab);
		return this;
	}

	public SearchResult_Page Click_Product_tab() {
		clickWithScreenshot(SearchResultPageConstants.products_tab);
		return this;
	}




	public SearchResult_Page Verify_Business_Filter() {
		verifyElementDisplayed(SearchResultPageConstants.business_unit);
		return this;
	}

	public SearchResult_Page Click_Business_Filter() throws InterruptedException {
		Thread.sleep(4000);
		VerifyElementIsClickable(SearchResultPageConstants.business_unit);
		clickWebElement(SearchResultPageConstants.business_unit);
		return this;
	}
	
	public SearchResult_Page Click_Level1_Filter() throws InterruptedException {
		Thread.sleep(1000);
		clickWebElement(SearchResultPageConstants.document_level1_dd);
		Thread.sleep(1000);
		return this;
	}
	
	public SearchResult_Page Click_Level2_Filter() throws InterruptedException {
		Thread.sleep(2000);
		clickWebElement(SearchResultPageConstants.document_level2_dd);
		Thread.sleep(1000);
		return this;
	}
	
	public SearchResult_Page Click_Level3_Filter() throws InterruptedException {
		Thread.sleep(2000);
		clickWebElement(SearchResultPageConstants.document_level3_dd);
		Thread.sleep(1000);
		return this;
	}
	
	public SearchResult_Page Verify_Business_Filter_Colour() throws InterruptedException {
		VerifyElementColour(SearchResultPageConstants.business_unit, "rgba(48, 48, 48, 1)");
		return this;
	}
	
	public SearchResult_Page Verify_Business_Filter_Arrowdown() {
		verifyElementDisplayed(SearchResultPageConstants.business_filter_arrowdown);
		return this;
	}
	

	public SearchResult_Page Verify_NoSelected_Value() {
		List<WebElement> findElementsByXPath = driver.findElements(By.xpath("//div[contains(@class,'dropdown-single-value__menu-list')]//child::div[contains(@class,'is-selected')]"));
		try {
			if (findElementsByXPath.size()==0) {

				loggerWithScreenshot("Verification: There is no Selected value and Default value is shown", "", Status.PASS, true); 
				Thread.sleep(1000);
			}
		} catch (Exception e) {
			logger("Verification: Exception Occured : " + e.getMessage(), Status.FAIL);
		}

		return this;
	}

	public SearchResult_Page Verify_Business_Filter_value(String txt) {
		if (SearchResultPageConstants.business_unit.isDisplayed()) {
			SearchResultPageConstants.business_unit.click();
		}
		// dynamicElementDisplayed("//div[contains(@class,'dropdown-single-value__menu-list')]//child::div[contains(@id,'react-select')]",
		// txt);

		if (dynamicElementDisplayed(
				"//div[contains(@class,'dropdown-single-value__menu css-26l3qy-menu')]//child::div[contains(@id,'react-select')]",
				txt) == Boolean.FALSE) {
			logger("Element" + txt + " is not displayed", Status.INFO);
		}
		return this;
	}
	
	public SearchResult_Page Click_Business_Filter_ArrowUp(){
		if (SearchResultPageConstants.business_unit.isDisplayed()) {
			SearchResultPageConstants.business_unit.click();
		}
		return this;
	}
	
	public SearchResult_Page Verify_Business_Filter_Selectedvalue(String txt) {
		dynamicElementDisplayed("//div[contains(@class,'dropdown-single-value__single-value')]", txt);
		return this;
	}

	public SearchResult_Page Click_Business_Filter_value(String txt) throws InterruptedException {
		VerifyElementIsClickable(SearchResultPageConstants.business_unit);
		if(SearchResultPageConstants.business_unit.isDisplayed()) {
			SearchResultPageConstants.business_unit.click();
		}
		try {
			Thread.sleep(3000);
			driver.findElement(By.xpath("//div[text()='"+txt+"']")).click();
			logger("Verification: Value "+txt+" is selected", Status.PASS);
		} catch (Exception e) {
			
			e.printStackTrace();
		}
		Thread.sleep(2000);
		return this;
	}
	
	public SearchResult_Page Click_Level1_Filter_Value(String txt) throws InterruptedException {
		try {
			driver.findElement(By.xpath("//div[text()='"+txt+"']")).click();
			logger("Verification: Value "+txt+" is selected", Status.PASS);
		} catch (Exception e) {
			
			e.printStackTrace();
		}
		Thread.sleep(2000);
		return this;
	}
	
	public SearchResult_Page Click_Level2_Filter_Value(String txt) throws InterruptedException {
		try {
			driver.findElement(By.xpath("//div[text()='"+txt+"']")).click();
			logger("Verification: Value "+txt+" is selected", Status.PASS);
		} catch (Exception e) {
			
			e.printStackTrace();
		}
		Thread.sleep(2000);
		return this;
	}
	
	public SearchResult_Page Click_Level3_Filter_Value(String txt) throws InterruptedException {
		try {
			driver.findElement(By.xpath("//div[text()='"+txt+"']")).click();
			logger("Verification: Value "+txt+" is selected", Status.PASS);
		} catch (Exception e) {
			
			e.printStackTrace();
		}
		Thread.sleep(2000);
		return this;
	}
	
	public SearchResult_Page Click_Business_Filter_value2(String txt) throws InterruptedException {
		try {
			driver.findElement(By.xpath("//div[text()='"+txt+"']")).click();
			logger("Verification: Value "+txt+" is selected", Status.PASS);
		} catch (Exception e) {

			clickWebElement(SearchResultPageConstants.business_unit);
			driver.findElement(By.xpath("//div[text()='"+txt+"']")).click();
			//e.printStackTrace();
			logger("Verification: Value "+txt+" is not selected", Status.INFO);
		}
		Thread.sleep(2000);
		return this;
	}

	public SearchResult_Page Verify_Business_Filter_container(String txt) {
		dynamicElementDisplayed("((//div[contains(@class,'value-container')])//child::div)", txt);
		return this;
	}
	public SearchResult_Page Verify_clear_button() throws InterruptedException {
	
		By ele = By.xpath("//span[@class='icon icon-cancel']");
		if(isElementPresent(ele)==Boolean.FALSE) {
			logger("Verifycation: Element not present",Status.PASS);
		}else {
			logger("Verification: Element is present",Status.PASS);
		}
		/*
		 * if(SearchResultPageConstants.clear_filter.isEnabled()==Boolean.FALSE) {
		 * logger("Verification: Clear filter button is not displayed", Status.PASS); }
		 * else { logger("Verification: Clear filter button is displayed", Status.FAIL);
		 * }
		 */
		return this;
	}

	public SearchResult_Page Verify_No_Clearbutton() {
		List<WebElement> clearfilter = driver.findElements(By.xpath("//div[contains(@class,'clear-filters-button')]//span"));

		if(clearfilter.size()==0)
		{
			logger("Verification: Clear filter button is not displayed", Status.PASS);
		}
		else
		{
			logger("Verification: Issues with clear filter button", Status.FAIL);
		}
		return this;

	}


	public SearchResult_Page Verify_clear_button_mousehover() {
		MoveToElement(SearchResultPageConstants.clear_filter);
		if(driver.findElement(By.xpath("//div[@id='search-filter-clear']")).isDisplayed())
		{
			logger("Verification: Clear filter text is displayed on Mousehover", Status.PASS);
		}
		else {
			logger("Verification: Clear filter text is not displayed on Mousehover", Status.FAIL);
		}
		return this;
	}

	public SearchResult_Page v() throws InterruptedException {
		MoveToElement(SearchResultPageConstants.clear_filter);
		Thread.sleep(2000);
		clickWebElement(SearchResultPageConstants.clear_filter);
		
		/*
		 * try { Thread.sleep(2000); SearchResultPageConstants.clear_filter.click();
		 * logger("Verification: Clear filter button is clicked", Status.PASS); } catch
		 * (Exception e) { e.printStackTrace(); logger("Verification: unexpected error",
		 * Status.FAIL); } {
		 * 
		 * }
		 */
		return this;
	}



	//////////////// Document tab//////////////////////////

	public SearchResult_Page Verify_Documents_count() {
		if(SearchResultPageConstants.document_tab.getText().matches("([0-9]+)"));
		{
			String substring = SearchResultPageConstants.document_tab.getText().substring(SearchResultPageConstants.document_tab.getText().indexOf('('), SearchResultPageConstants.document_tab.getText().indexOf(')'));
			logger("Verification: Documents Tab contains number of result: "+substring+")", Status.PASS);
		}

		return this;
	}

	public SearchResult_Page Verify_Document_tab() {
		verifyElementDisplayed(SearchResultPageConstants.document_tab);
		return this;
	}

	public SearchResult_Page Click_Document_tab() throws InterruptedException {
		clickWithScreenshot(SearchResultPageConstants.document_tab);
		Thread.sleep(3000);
		return this;
	}

	public SearchResult_Page Verify_Document_Type_Filter() {
		verifyElementDisplayed(SearchResultPageConstants.downloads_type_dd);
		return this;
	}
	
	public SearchResult_Page Verify_Approval_Type_Filer() {
		verifyElementDisplayed(SearchResultPageConstants.approval_type_dd);
		return this;
	}
	
	public SearchResult_Page Click_Document_Type_Filter() throws InterruptedException {
		clickWithScreenshot(SearchResultPageConstants.downloads_type_dd);
		return this;
	}
	
	public SearchResult_Page Click_Approval_Type_Filter() throws InterruptedException {
		clickWithScreenshot(SearchResultPageConstants.approval_type_dd);
		return this;
	}
	
	public SearchResult_Page Click_Document_Type_Filter_arrowdown() {
		clickWebElement(SearchResultPageConstants.document_type_filter_arrowdown);
		//driver.findElement(By.xpath("(//span[contains(@class,'icon icon-chevron-down-small')])[2]").click();
		return this;
	}
	public SearchResult_Page Click_Document_Type_Filter_arrowup() throws InterruptedException {
		clickWebElement(SearchResultPageConstants.document_type_filter_arrowup);
		//driver.findElement(By.xpath("(//span[contains(@class,'icon icon-chevron-down-small')])[2]").click();
		return this;
	}
	
	public SearchResult_Page Click_Document_Language_filter_arrowup() throws InterruptedException {
		Thread.sleep(2000);
		clickWebElement(SearchResultPageConstants.language_type_filter_arrowup);
		verifyElementEnabled(SearchResultPageConstants.language_type_filter_arrowup);
		WebElement arrow = driver.findElement(By.xpath("//*[text()='All languages']"));
		if(arrow.isDisplayed()) {
			SearchResultPageConstants.language_type_filter_arrowup.click();
		}
		return this;
	}
	
	public SearchResult_Page Click_Approval_Type_Filter_arrowup() throws InterruptedException {
		clickWebElement(SearchResultPageConstants.approval_type_filter_arrowup);
		//driver.findElement(By.xpath("(//span[contains(@class,'icon icon-chevron-down-small')])[2]").click();
		return this;
	}
	
	public SearchResult_Page Verify_Document_Type_Filter_Color() throws InterruptedException {
		VerifyElementColour(SearchResultPageConstants.document_type_dd, "rgba(48, 48, 48, 1)");
		return this;
	}
	
	public SearchResult_Page Verify_Hierarchy_Level1_Filter_color() throws InterruptedException {
		VerifyElementColour(SearchResultPageConstants.document_level1_dd, "rgba(48, 48, 48, 1)");
		return this;
	}
	
	public SearchResult_Page Verify_Hierarchy_Level2_Filter_color() throws InterruptedException {
		VerifyElementColour(SearchResultPageConstants.document_level1_dd, "rgba(48, 48, 48, 1)");
		return this;
	}
	
	public SearchResult_Page Verify_Hierarchy_Level3_Filter_color() throws InterruptedException {
		VerifyElementColour(SearchResultPageConstants.document_level3_dd, "rgba(48, 48, 48, 1)");
		return this;
	}
	
	
	public SearchResult_Page Verify_Level1_Filter_color() throws InterruptedException {
		VerifyElementColour(SearchResultPageConstants.document_level1_dd, "rgba(48, 48, 48, 1)");
		return this;
	}
	
	public SearchResult_Page Verify_Document_Type_Filter_Arrow_Color() throws InterruptedException{
		VerifyElementColour(SearchResultPageConstants.document_type_filter_arrowdown, "rgba(226, 0, 15, 1)");
		return this;
	}
	
	public SearchResult_Page Verify_Document_Type_ContainerName() throws InterruptedException {
		Thread.sleep(3000);
		//String text = driver.findElement(By.xpath("(//span[contains(@class,'multiselect-dropdown-value')])[1]")).getText();
		String text = driver.findElement(By.xpath("//div[contains(@class,'multiselect-option-wrapper')]")).getText();
		logger("Verification: Container name of Document type dropdown is " + text, Status.INFO);
		return this;
	}
	
	public SearchResult_Page Verify_Document_Type_Predefined_Values() throws InterruptedException {
		Thread.sleep(1000);
		
		int size = driver.findElements(By.xpath("//div[@class='dropdown-multi-values__option css-yt9ioa-option']")).size();
		if(size==29) {
			logger("Verification: Document type filter "+size+" options are matching with the expected value",Status.PASS);
		}
		else {
			logger("Verification: Document type filter "+size+" options are not matching with the expected value",Status.INFO);	
		}
		
		for(int i=1;i<=size;i++) {
			WebElement value = driver.findElement(By.xpath("(//div[@class='dropdown-multi-values__option css-yt9ioa-option'])["+i+"]"));
			MoveToElement(value);
			String option =driver.findElement(By.xpath("(//div[@class='dropdown-multi-values__option css-yt9ioa-option'])["+i+"]")).getText();
			logger("Verification: "+option+" is present",Status.PASS);
		}
		return this;
	}
	
	public SearchResult_Page Verify_Approval_Type_Filer_Values() throws InterruptedException {
		Thread.sleep(1000);
		
		int size = driver.findElements(By.xpath("//div[contains(@class,'dropdown-multi-values__option')]")).size();
		if(size==0) {
			clickWithScreenshot(SearchResultPageConstants.approval_type_dd);
			
		}
		int size_new = driver.findElements(By.xpath("//div[contains(@class,'dropdown-multi-values__option')]")).size();
		if(size_new==3) {
			logger("Verification: Approval type filter "+size+" options are matching with the expected value",Status.PASS);
		}
		else {
			logger("Verification: Approval type filter "+size+" options are not matching with the expected value",Status.INFO);	
		}
		
		for(int i=1;i<size_new;i++) {
			WebElement value = driver.findElement(By.xpath("(//div[@class='dropdown-multi-values__option css-yt9ioa-option'])["+i+"]"));
			MoveToElement(value);
			String option =driver.findElement(By.xpath("(//div[@class='dropdown-multi-values__option css-yt9ioa-option'])["+i+"]")).getText();
			logger("Verification: "+option+" is present",Status.PASS);
		}
		return this;
	}
	
	public SearchResult_Page Verify_Document_Type_Predefined_Values_with_Checkbox() throws InterruptedException {
		Thread.sleep(1000);
		
		int size = driver.findElements(By.xpath("//div[@class='dropdown-multi-values__option css-yt9ioa-option']")).size();
		if(size==29) {
			logger("Verification: Document type filter "+size+" options are matching with the expected value",Status.PASS);
		}
		else {
			logger("Verification: Document type filter "+size+" options are not matching with the expected value",Status.INFO);	
		}
		
		for(int i=1;i<=size;i=i+8) {
			WebElement value = driver.findElement(By.xpath("(//div[@class='dropdown-multi-values__option css-yt9ioa-option'])["+i+"]"));
			MoveToElement(value);
			clickWebElement(value);
			String option =driver.findElement(By.xpath("(//div[@class='dropdown-multi-values__option css-yt9ioa-option'])["+i+"]")).getText();
			logger("Verification: "+option+" is present",Status.PASS);
		}
		return this;
	}
	
	public SearchResult_Page Verify_All_Language_Predeined_Values() throws InterruptedException {
		Thread.sleep(2000);
		int size = driver.findElements(By.xpath("//span[@class='multiselect-option-checkbox']/following::label")).size();
		if(size==42) {
			logger("Verification: ALl Language filter "+size+" options are matching with the expected value",Status.PASS);
		}
		else {
			logger("Verification: All Language filter "+size+" options are not matching with the expected value",Status.FAIL);	
		}
		
		for(int i=1;i<=size;i++) {
			WebElement value = driver.findElement(By.xpath("//span[@class='multiselect-option-checkbox']/following::label["+i+"]"));
			MoveToElement(value);
			String option =driver.findElement(By.xpath("//span[@class='multiselect-option-checkbox']/following::label["+i+"]")).getText();
			logger("Verification: "+option+" is present",Status.PASS);
		}
		return this;
	}
	
	public SearchResult_Page Verify_Business_Type_Predefined_Values() throws InterruptedException {
		Thread.sleep(2000);
		int size = driver.findElements(By.xpath("//div[@class='dropdown-single-value__option css-yt9ioa-option']")).size();
		if(size==9) {
			logger("Verification: ALl Language filter "+size+" options are matching with the expected value",Status.PASS);
		}
		else {
			logger("Verification: All Language filter "+size+" options are not matching with the expected value",Status.FAIL);	
		}
		
		for(int i=1;i<=size;i++) {
			WebElement value = driver.findElement(By.xpath("//div[@class='dropdown-single-value__option css-yt9ioa-option']["+i+"]"));
			MoveToElement(value);
			String option =driver.findElement(By.xpath("//div[@class='dropdown-single-value__option css-yt9ioa-option']["+i+"]")).getText();
			logger("Verification: "+option+" is present",Status.PASS);
		}
		return this;
	}
	
	public SearchResult_Page Verify_Level1_Predefined_values() throws InterruptedException {
		Thread.sleep(2000);
		int size = driver.findElements(By.xpath("//div[@class='dropdown-single-value__option css-yt9ioa-option']")).size();
		if(size==12) {
			logger("Verification: ALl Language filter "+size+" options are matching with the expected value",Status.PASS);
		}
		else {
			logger("Verification: All Language filter "+size+" options are not matching with the expected value",Status.FAIL);	
		}
		
		for(int i=1;i<=size;i++) {
			WebElement value = driver.findElement(By.xpath("//div[@class='dropdown-single-value__option css-yt9ioa-option']["+i+"]"));
			MoveToElement(value);
			String option =driver.findElement(By.xpath("//div[@class='dropdown-single-value__option css-yt9ioa-option']["+i+"]")).getText();
			logger("Verification: "+option+" is present",Status.PASS);
		}
		return this;
	}
	
	public SearchResult_Page Verify_Level2_Predefined_values() throws InterruptedException {
		Thread.sleep(2000);
		int size = driver.findElements(By.xpath("//div[@class='dropdown-single-value__option css-yt9ioa-option']")).size();
		if(size==2) {
			logger("Verification: ALl Language filter "+size+" options are matching with the expected value",Status.PASS);
		}
		else {
			logger("Verification: All Language filter "+size+" options are not matching with the expected value",Status.FAIL);	
		}
		
		for(int i=1;i<=size;i++) {
			WebElement value = driver.findElement(By.xpath("//div[@class='dropdown-single-value__option css-yt9ioa-option']["+i+"]"));
			MoveToElement(value);
			String option =driver.findElement(By.xpath("//div[@class='dropdown-single-value__option css-yt9ioa-option']["+i+"]")).getText();
			logger("Verification: "+option+" is present",Status.PASS);
		}
		return this;
	}
	
	public SearchResult_Page Verify_Document_Archived_Default_Value() throws InterruptedException {
		String default_value = driver.findElement(By.xpath("//div[contains(@class,'dropdown-single-value__value-container dropdown-single-value__value-container--has-value css-1hwfws3')]/div")).getText();
		if(default_value.contains("Published")) {
			logger("Verification: Archived Type filter default value is present as "+default_value,Status.PASS);
		}else {
			logger("Verification: Archived Type filter default value is not present as "+default_value,Status.FAIL);
		}
		
		return this;
	}
	
	
	public SearchResult_Page Verify_Document_Type_ContainerName3() throws InterruptedException {
		Thread.sleep(2000);
		String text = driver.findElement(By.xpath("(//span[contains(@class,'multiselect-dropdown-value')])[1]")).getText();
		logger("Verification: Container name of Document type dropdown is " + text, Status.INFO);
		return this;
	}

	public SearchResult_Page Verify_Disabled_Document_Type_value() throws InterruptedException {
		Thread.sleep(2000);
		try {
			String text = driver.findElement(By.xpath("(//div[contains(@class,'disabled dropdown')]//following::label)[1]")).getText();

			logger("Verification: "+text+ "value is disabled in Document type filter ", Status.PASS);
		} catch (Exception e) {
			logger("Verification: issue with Document type filter ", Status.FAIL);

		}
		return this;
	}

	public SearchResult_Page Verify_Selected_Document_Type_value() throws InterruptedException {
		Thread.sleep(2000);
		try {
			List<WebElement> findElementsByXPath = driver.findElements(By.xpath("(//div[contains(@class,'dropdown-multi-values__option dropdown-multi-values__option--is-selected')]//following::label)"));
			for (int i = 0; i < findElementsByXPath.size(); i++) {
				String text = driver.findElement(By.xpath("(//div[contains(@class,'dropdown-multi-values__option dropdown-multi-values__option--is-selected')]//following::label)"))
						.getText();
				logger("Verification: value is " + text + " selected in Document type filter ", Status.PASS);
			}
		} catch (Exception e) {

			logger("Verification: issue with Document type filter ", Status.FAIL);

		}

		return this;
	}

	public SearchResult_Page Click_Document_Type_filtervalue(String text) throws InterruptedException {
		Thread.sleep(1000);
		dynamicElementselector("(//div[contains(@class,'dropdown-multi-values__option')]//label)[position()>1]", text);
		Thread.sleep(1000);
		return this;
	}

	public SearchResult_Page Click_Approval_Type_filtervalue(String text) throws InterruptedException {

		dynamicElementselector("(//div[contains(@class,'dropdown-multi-values__option')]//label)[position()>1]", text);
		Thread.sleep(1000);
		return this;
	}
	
	public SearchResult_Page Verify_Document_Language_filter() throws InterruptedException {
		Thread.sleep(4000);
		verifyElementDisplayed(SearchResultPageConstants.document_language_filter);
		return this;


	}

	public SearchResult_Page Click_Document_Language_filter() throws InterruptedException {
		Thread.sleep(5000);
		clickWebElement(SearchResultPageConstants.document_language_filter);
		return this;
	}

	public SearchResult_Page Verify_Document_Language_Alphabetic() {
		Verify_Alphabatic_Order("(//div[contains(@class,'dropdown-multi-values__option')]//label)[position()>1]");
		logger("Verification: Language filter is multi selection, user can select one or more value ",Status.INFO);
		return this;
	}

	public SearchResult_Page Verify_Document_Language_Preselectedvalue(String text) {

		List<WebElement> Preselectedvalue = driver.findElements(By.xpath("//div[contains(@class,'option--is-selected')]"));
		for (int i = 0; i < Preselectedvalue.size(); i++) {

			if(Preselectedvalue.get(i).getText().contains(text))
			{
				logger("Verification: preselect value in language filter: "+ text, Status.PASS);
			}

		}

		return this;
	}

	public SearchResult_Page Click_Document_Language_filtervalue(String text) throws InterruptedException {
		//VerifyElementIsClickable(SearchResultPageConstants.document_language_filter);
		if(SearchResultPageConstants.document_language_filter.isDisplayed()) {
			SearchResultPageConstants.document_language_filter.click();
		}
		Thread.sleep(4000);
		dynamicElementselector("(//div[contains(@class,'dropdown-multi-values__option')]//label)[position()>1]", text);
		Thread.sleep(1000);
		return this;
	}

	public SearchResult_Page Verify_Document_Language_containervalue(String text) throws InterruptedException {
		Thread.sleep(1000);
		if(SearchResultPageConstants.document_language_container.getText().contains(text))
		{
			logger("Verification: Container value in Language filter is: "+text, Status.PASS);
		}

		return this;
	}

	public SearchResult_Page Verify_Document_validfor_filter() {

		verifyElementDisplayed(SearchResultPageConstants.document_Validfor_filter);

		return this;
	}

	public SearchResult_Page Click_Document_validfor_filter() {

		clickWebElement(SearchResultPageConstants.document_Validfor_filter);

		return this;
	}

	public SearchResult_Page Click_Document_validfor_filterarrow() {

		clickWebElement(SearchResultPageConstants.document_Validfor_filter1);

		return this;
	}

	public SearchResult_Page Verify_Document_validfor_filter_alphabetic() {

		Verify_Alphabatic_Order("(//div[contains(@class,'dropdown-single-value__option')])[position()>1]");
		logger("Verification: There is ability to select only 1 Value" , Status.PASS);

		return this;
	}

	public SearchResult_Page Click_Document_validfor_filtervalue(String text) throws InterruptedException {

		dynamicElementselector("//div[contains(@class,'dropdown-single-value__option')]", text);
		Thread.sleep(2000);

		return this;
	}

	public SearchResult_Page Verify_Document_validfor_container(String text) throws InterruptedException {

		dynamicElementDisplayed("(//span[@aria-live='polite']//following::div[contains(@class,'dropdown-single-value__value-container')]//child::div)[1]", text);
		Thread.sleep(2000);

		return this;
	}



	public SearchResult_Page Verify_Document_Authority_filter() throws InterruptedException {
		verifyElementDisplayed(SearchResultPageConstants.document_Authority_filter);
		return this;
	}


	public SearchResult_Page Verify_Document_No_Authority_filter() throws InterruptedException {
		List<WebElement> Authority = driver.findElements(By.xpath("(//div[text()='Authority'])[1]"));
		if(Authority.size()==0)
		{
			logger("Verification: Authority filter is not available", Status.PASS);
		}
		else
		{
			logger("Verification: issue with Authority filter", Status.FAIL);
		}
		return this;
	}

	public SearchResult_Page Click_Document_Authority_filter() throws InterruptedException {

		clickWebElement(SearchResultPageConstants.document_Authority_filter);
		return this;
	}
	
	public SearchResult_Page Click_Document_Authority_filter_BV() throws InterruptedException {
		clickWebElement(SearchResultPageConstants.document_Authority_filter_BV);
		return this;
	}
	
	public SearchResult_Page Verify_Document_Authority_Alphabetic() throws InterruptedException {

		Verify_Alphabatic_Order("(//div[contains(@class,'dropdown-single-value__option')])[position()>1]");
		logger("Verification: There is ability to select only 1 Value" , Status.PASS);
		return this;
	}



	public SearchResult_Page Click_Document_Authority_filtervalue(String text) throws InterruptedException {

		dynamicElementselector("//div[contains(@class,'dropdown-single-value__option')]", text);
		Thread.sleep(2000);

		return this;
	}

	public SearchResult_Page Verify_Document_Authority_container(String text) throws InterruptedException {

		dynamicElementDisplayed("(//div[contains(@class,'dropdown-single-value__value-container dropdown-single-value')]//child::div)[2]", text);
		Thread.sleep(2000);

		return this;
	}

	public SearchResult_Page Click_Document_Authority_container(String text) throws InterruptedException {

		dynamicElementselector("(//div[contains(@class,'dropdown-single-value__value-container dropdown-single-value')]//child::div)[2]", text);
		Thread.sleep(2000);

		return this;
	}

	public SearchResult_Page Verify_Document_Archived_Filter() throws InterruptedException {

		verifyElementDisplayed(SearchResultPageConstants.document_Archived_filter);

		return this;
	}

	public SearchResult_Page Click_Document_Archived_Filter() throws InterruptedException {

		clickWebElement(SearchResultPageConstants.document_Archived_filter);

		return this;
	}

	public SearchResult_Page verify_Document_Archived_Filter_container(String text) throws InterruptedException {
		dynamicElementDisplayed("//div[contains(@class,'dropdown-single-value__value-container')]//child::div[contains(@class,'dropdown-single-value__single')]", text);
		return this;
	}

	public SearchResult_Page Verify_Document_Archived_Alphabetic() throws InterruptedException {

		Verify_Alphabatic_Order("(//div[contains(@class,'dropdown-single-value__option')])[position()>1]");
		logger("Verification: There is ability to select only 1 Value" , Status.PASS);
		return this;
	}



	public SearchResult_Page Click_Document_Archived_filtervalue(String text) throws InterruptedException {

		dynamicElementselector("//div[contains(@class,'dropdown-single-value__option')]", text);
		Thread.sleep(2000);

		return this;
	}


	public SearchResult_Page Verify_Product_series_filter()  {
		verifyElementDisplayed(SearchResultPageConstants.product_filter_lvl1);
		//SearchResultPageConstants.product_filter_lvl1.sendKeys();
		return this;
	}

	public SearchResult_Page Verify_Product_line_filter()  {
		verifyElementDisplayed(SearchResultPageConstants.productline_filter_lvl1);
		//SearchResultPageConstants.productline_filter_lvl1.sendKeys();
		return this;
	}

	public SearchResult_Page Verify_Product_level2_filter()  {
		verifyElementDisplayed(SearchResultPageConstants.product_filter_lvl2);
		//SearchResultPageConstants.productline_filter_lvl1.sendKeys();
		return this;
	}
	
	public SearchResult_Page Verify_NoProduct_level2_filter()  {
		verifyElementNotDisplayed("(//div[contains(text(),'Level  2')])[2]");
		//SearchResultPageConstants.productline_filter_lvl1.sendKeys();
		return this;
	}
	public SearchResult_Page Verify_Product_group_filter()  {
		verifyElementDisplayed(SearchResultPageConstants.product_filter_lvl1);
		return this;
	}

	public SearchResult_Page click_Product_group_filter()  {
		clickWebElement(SearchResultPageConstants.product_filter_lvl1);
		return this;
	}

	public SearchResult_Page Verify_Product_series_filter_withprodgrp()  {
		verifyElementDisplayed(SearchResultPageConstants.product_filter_lvl2);
		return this;
	}

	public SearchResult_Page click_Product_series_filter_withprodgrp() {
		clickWebElement(SearchResultPageConstants.product_filter_lvl2);
		return this;
	}
	
	
	public SearchResult_Page click_Product_series_filter() {
		clickWebElement(SearchResultPageConstants.product_filter_lvl1);
		return this;
	}
	
	public SearchResult_Page click_Productline_filter() {
		clickWebElement(SearchResultPageConstants.productline_filter_lvl1);
		return this;
	}
	
	public SearchResult_Page click_Product_level2_filter() {
		clickWebElement(SearchResultPageConstants.product_filter_lvl2);
		return this;
	}


	public SearchResult_Page click_Product_series_filtervalue(String text) {
		dynamicElementselector("//div[contains(@class,'dropdown-single-value__option')]", text);
		return this;
	}
	
	public SearchResult_Page click_Productline_filtervalue(String text) {
		dynamicElementselector("//div[contains(@class,'dropdown-single-value__option')]", text);
		return this;
	}

	public SearchResult_Page click_Product_group_filtervalue(String text) {
		dynamicElementselector("//div[contains(@class,'dropdown-single-value__option')]", text);
		return this;
	}

	public SearchResult_Page Verify_Product_series_Alphabetic() {
		Verify_Alphabatic_Order("//div[contains(@class,'dropdown-single-value__option')]");
		logger("Verification: There is ability to select only one value in a time", Status.PASS);
		return this;
	}

	public SearchResult_Page Verify_Product_line_Alphabetic() {
		Verify_Alphabatic_Order("//div[contains(@class,'dropdown-single-value__option')]");
		logger("Verification: There is ability to select only one value in a time", Status.PASS);
		return this;
	}

	public SearchResult_Page Verify_Product_group_Alphabetic() {
		Verify_Alphabatic_Order("//div[contains(@class,'dropdown-single-value__option')]");
		logger("Verification: There is ability to select only one value in a time", Status.PASS);
		return this;
	}

	public SearchResult_Page Verify_Product_series_contianer(String text) {
		dynamicElementDisplayed("(//div[contains(@class,'dropdown-single-value__value-container')]//child::div[contains(@class,'dropdown-single-value__single-value')])[3]", text);
		return this;
	}
	
	public SearchResult_Page Click_Product_series_contianer(String text) {
		dynamicElementselector("(//div[contains(@class,'dropdown-single-value__value-container')]//child::div[contains(@class,'dropdown-single-value__single-value')])[3]", text);
		return this;
	}
	
	public SearchResult_Page Click_Product_group_contianer(String text) {
		dynamicElementselector("(//div[contains(@class,'dropdown-single-value__value-container')]//child::div[contains(@class,'dropdown-single-value__single-value')])[3]", text);
		return this;
	}
	public SearchResult_Page Verify_Product_line_contianer(String text) {
		dynamicElementDisplayed("(//div[contains(@class,'dropdown-single-value__value-container')]//child::div[contains(@class,'dropdown-single-value__single-value')])[3]", text);
		return this;
	}

	public SearchResult_Page Verify_Product_group_contianer(String text) {
		dynamicElementDisplayed("(//div[contains(@class,'dropdown-single-value__value-container')]//child::div[contains(@class,'dropdown-single-value__single-value')])[3]", text);
		return this;
	}

	public SearchResult_Page Verify_Product_series_contianerwithprdgrp(String text) {
		dynamicElementDisplayed("(//div[contains(@class,'dropdown-single-value__value-container')]//child::div[contains(@class,'dropdown-single-value__single-value')])[3]", text);


		return this;
	}

	public SearchResult_Page Navigate_back() throws InterruptedException {
		navigateBack();
		Thread.sleep(2000);
		return this;
	}








	//////////////// Download tab//////////////////////////


	public SearchResult_Page Verify_Downloads_count() {
		verifyElementDisplayed(SearchResultPageConstants.downloads_tab);
		if(SearchResultPageConstants.downloads_tab.getText().matches("([0-9]+)"));
		{
			String substring = SearchResultPageConstants.downloads_tab.getText().substring(SearchResultPageConstants.downloads_tab.getText().indexOf('('), SearchResultPageConstants.downloads_tab.getText().indexOf(')'));
			logger("Verification: Downloads Tab contains number of result: "+substring+")", Status.PASS);
		}

		return this;
	}

	public SearchResult_Page Verify_Download_tab() {
		verifyElementDisplayed(SearchResultPageConstants.downloads_tab);
		return this;
	}

	public SearchResult_Page Click_Download_tab() {
		clickWithScreenshot(SearchResultPageConstants.downloads_tab);
		return this;
	}

	public SearchResult_Page Verify_Download_items() {
		verifyElementDisplayed(SearchResultPageConstants.downloads_title);
		if(driver.findElement(By.xpath("(//div[@class='tile__image bordered'])[1]")).isDisplayed())
		{
			logger("Verification: Image is displayed", Status.PASS);
		}
		else
		{
			logger("Verification: Image is displayed", Status.FAIL);
		}
		verifyElementDisplayed(SearchResultPageConstants.downloads_Segment_type);
		if(SearchResultPageConstants.downloads_description.isDisplayed())
		{
			logger("Verification: Description is displayed", Status.PASS);
		}
		else
		{
			logger("Verification: Description is not displayed", Status.FAIL);
		}

		return this;
	}

	public SearchResult_Page Verify_Whole_Download_isclickable() {

		VerifyElementIsClickable("(//div[@class='tile__text'])[1]");

		return this;
	}

	public SearchResult_Page Click_Download_item() {
		clickWebElement(SearchResultPageConstants.downloads_title);
		return this;
	}

	public SearchResult_Page Verify_Pagetitle(String txt) throws InterruptedException {
		verifyPageTitle(txt);
		return this;
	}

	public SearchResult_Page Verify_Download_Type_Filter() {
		verifyElementDisplayed(SearchResultPageConstants.downloads_type_dd);
		return this;
	}

	public SearchResult_Page Click_Download_Type_Filter() {
		clickWithScreenshot(SearchResultPageConstants.downloads_type_dd);
		return this;
	}

	public SearchResult_Page Verify_DownloadType_Filter_value(String txt) throws InterruptedException {
		if(SearchResultPageConstants.downloads_type_dd.isDisplayed()) {
			SearchResultPageConstants.downloads_type_dd.click();
		}
		dynamicElementDisplayed("//div[contains(@class,'dropdown-multi-values__value-container')]//following::span[contains(@class,'multiselect-option-checkbox')]//following::label", txt);
		return this;
	}

	public SearchResult_Page Verify_DownloadType_Filter_Alphaorder() {
		Verify_Alphabatic_Order("//div[contains(@class,'dropdown-multi-values__value-container')]//following::span[contains(@class,'multiselect-option-checkbox')]//following::label");
		return this;
	}

	public SearchResult_Page Click_DownloadType_Filter_value(String txt) throws InterruptedException {
		try {
			dynamicElementselector("//div[contains(@class,'dropdown-multi-values__value-container')]//following::span[contains(@class,'multiselect-option-checkbox')]//following::label", txt);

			logger("Verification: Value "+txt+" is selected", Status.PASS);
		} catch (Exception e) {

			e.printStackTrace();
		}
		Thread.sleep(4000);
		return this;
	}


	public SearchResult_Page Click_Download_Type_Filter_arrowdown() throws InterruptedException {
		Thread.sleep(2000);
		driver.findElement(By.xpath("(//span[contains(@class,'icon icon-chevron-down-small')])[2]")).click();
		Thread.sleep(2000);
		return this;
	}
	public SearchResult_Page Click_Download_Type_Filter_arrowup() throws InterruptedException {
		Thread.sleep(2000);
		driver.findElement(By.xpath("(//span[contains(@class,'icon icon-chevron-down-small')])[2]")).click();
		Thread.sleep(2000);
		return this;
	}
	
	public SearchResult_Page Verify_Document_Type_Filter_Arrowdown() throws InterruptedException {
		Thread.sleep(2000);
		verifyElementDisplayed(SearchResultPageConstants.document_type_filter_arrowdown);
		return this;
	}
	

	public SearchResult_Page Verify_Download_Type_ContainerName() throws InterruptedException {
		Thread.sleep(2000);
		String text = driver.findElement(By.xpath("(//span[contains(@class,'multiselect-dropdown-value')])[1]")).getText();
		logger("Verification: Container name of Download type dropdown is " + text, Status.INFO);
		return this;
	}

	public SearchResult_Page Verify_Download_Type_ContainerName3() throws InterruptedException {
		Thread.sleep(2000);
		String text = driver.findElement(By.xpath("(//span[contains(@class,'multiselect-dropdown-value')])[3]")).getText();
		logger("Verification: Container name of Download type dropdown is " + text, Status.INFO);
		return this;
	}

	public SearchResult_Page Verify_Disabled_Download_Type_value() throws InterruptedException {
		Thread.sleep(2000);
		try {
			String text = driver.findElement(By.xpath("(//div[contains(@class,'disabled dropdown')]//following::label)[1]")).getText();

			logger("Verification: "+text+ "value is disabled in Download type filter ", Status.PASS);
		} catch (Exception e) {
			logger("Verification: issue with Download type filter ", Status.FAIL);

		}
		return this;
	}

	public SearchResult_Page Verify_Selected_Download_Type_value() throws InterruptedException {
		Thread.sleep(2000);
		try {
			List<WebElement> findElementsByXPath = driver.findElements(By.xpath("(//div[contains(@class,'dropdown-multi-values__option dropdown-multi-values__option--is-selected')]//following::label)"));
			for (int i = 0; i < findElementsByXPath.size(); i++) {
				String text = driver.findElement(By.xpath("(//div[contains(@class,'dropdown-multi-values__option dropdown-multi-values__option--is-selected')]//following::label)"))
						.getText();
				logger("Verification: value is " + text + " selected in Download type filter ", Status.PASS);
			}
		} catch (Exception e) {

			logger("Verification: issue with Download type filter ", Status.FAIL);

		}

		return this;
	}

	//////////////////////////// jobs ///////////////////////////////


	List<WebElement> Job_Country_altervalue, Job_Country_intialvalue, Job_location_altervalue, Job_location_intialvalue,
	Job_area_intialvalue, Job_area_altervalue, Position_type_intialvalue, Position_type_altervalue;

	public SearchResult_Page Verify_Jobs_tab() {
		verifyElementDisplayed(SearchResultPageConstants.jobs_tab);
		return this;
	}

	public SearchResult_Page Click_Job_tab() throws InterruptedException {
		clickWithScreenshot(SearchResultPageConstants.jobs_tab);
		Thread.sleep(2000);
		return this;
	}

	public SearchResult_Page Verify_Jobs_count() {

		if(SearchResultPageConstants.jobs_tab.getText().matches("([0-9]+)"));
		{
			String substring = SearchResultPageConstants.jobs_tab.getText().substring(SearchResultPageConstants.jobs_tab.getText().indexOf('('), SearchResultPageConstants.jobs_tab.getText().indexOf(')'));
			logger("Verification: Jobs Tab contains number of result: "+substring+")", Status.PASS);
		}

		return this;
	}


	public SearchResult_Page Verify_Job_Posting_items() {

		if(SearchResultPageConstants.External_icon.isDisplayed())
		{
			logger("Verification: External icon is displayed", Status.PASS);
		}
		else {
			logger("Verification: External icon is not displayed", Status.FAIL);
		}
		verifyElementDisplayed(SearchResultPageConstants.Job_title);
		verifyElementDisplayed(SearchResultPageConstants.Job_Date_location);

		return this;
	}

	public SearchResult_Page Verify_Job_title_Highlighted() throws InterruptedException {

		VerifyElementIsHighlighted(SearchResultPageConstants.Job_title);

		return this;
	}

	public SearchResult_Page Verify_Whole_Job_Posting_isclickable() {

		VerifyElementIsClickable("(//div[@class='tile__text'])[1]");

		return this;
	}

	public SearchResult_Page Click_Job_Title() {

		clickWebElement(SearchResultPageConstants.Job_title);

		return this;
	}

	public SearchResult_Page Verify_CareerPage_opens() {
		switchToWindow(1);
		if(driver.getCurrentUrl().contains("https://jobs.danfoss.com/job"))
		{
			logger("Verification: User is navigated to Career portal", Status.PASS);
		}
		else
		{
			logger("Verification: User is not navigated to Career portal", Status.FAIL);
		}

		return this;
	}

	public SearchResult_Page Navigate_SearchResult() {

		switchToParentWindow();
		return this;
	}

	public SearchResult_Page Click_Job_Area_filter() {

		clickWebElement(SearchResultPageConstants.Job_Area_filter);
		return this;
	}


	public SearchResult_Page Select_Job_Area_filter(String value) throws InterruptedException {

		dynamicElementselector("//div[contains(@class,'dropdown-single-value__option')]", value);
		Thread.sleep(2000);
		return this;
	}

	public SearchResult_Page Select_Job_Area_filter_default() throws InterruptedException {
		clickWebElement(driver.findElement(By.xpath("//div[contains(@id,'option-0')]")));
		Thread.sleep(2000);
		return this;
	}

	public SearchResult_Page Select_Job_Position_filter_default() throws InterruptedException {
		clickWebElement(driver.findElement(By.xpath("//div[contains(@id,'option-0')]")));
		Thread.sleep(2000);
		return this;
	}

	public SearchResult_Page Select_Job_location_filter_default() throws InterruptedException {
		clickWebElement(driver.findElement(By.xpath("//div[contains(@id,'option-0')]")));
		Thread.sleep(2000);
		return this;
	}
	public SearchResult_Page Verify_Job_Area_filter() {

		verifyElementDisplayed(SearchResultPageConstants.Job_Area_filter);
		return this;
	}



	public SearchResult_Page Verify_Job_Area_filter_container(String txt) {

		dynamicElementDisplayed("(//div[contains(@class,'dropdown-single-value__placeholder')])[3]", txt);
		return this;
	}

	public SearchResult_Page Click_Job_Area_filter_selected() throws InterruptedException {
		Thread.sleep(2000);
		clickWebElement(SearchResultPageConstants.Job_Area_filter_selected_value);
		Thread.sleep(2000);
		return this;
	}

	public SearchResult_Page Click_Job_Position_type_filter_selected() throws InterruptedException {

		clickWebElement(SearchResultPageConstants.Job_Area_filter_selected_value);
		Thread.sleep(2000);
		return this;
	}

	public SearchResult_Page Click_Job_Location_filter_selected() throws InterruptedException {

		clickWebElement(SearchResultPageConstants.Job_Location_filter_selected_value);
		Thread.sleep(2000);
		return this;
	}

	public SearchResult_Page Verify_Job_Area_filter_Alphaorder() {

		Verify_Alphabatic_Order("(//div[contains(@class,'dropdown-single-value__option')])[position()>1]");
		Job_area_intialvalue = driver.findElements(By.xpath("(//div[contains(@class,'dropdown-single-value__option')])[position()>1]"));
		return this;
	}

	public SearchResult_Page Verify_Job_Position_type_filter() {

		verifyElementDisplayed(SearchResultPageConstants.Job_Position_type_filter);
		return this;
	}

	public SearchResult_Page Verify_Job_Experience_level_filter() {

		verifyElementDisplayed(SearchResultPageConstants.Job_Experience_level_filter);
		return this;
	}

	public SearchResult_Page Click_Job_Position_type_filter() {
		clickWebElement(SearchResultPageConstants.Job_Position_type_filter);
		return this;
	}

	public SearchResult_Page Click_Job_Experience_level_filter() {
		clickWebElement(SearchResultPageConstants.Job_Experience_level_filter);
		return this;
	}

	public SearchResult_Page Click_Job_Experience_level_filter_arrow() {
		SearchResultPageConstants.Job_Experience_level_filter_arrow.click();
		return this;
	}


	public SearchResult_Page Verify_Position_type_filter_container(String txt) {

		dynamicElementDisplayed("(//div[contains(@class,'dropdown-single-value__placeholder')])[4]", txt);
		return this;
	}

	public SearchResult_Page Verify_Experience_level_filter_container(String txt) {

		dynamicElementDisplayed("(//div[contains(@class,'dropdown-single-value__placeholder')])[4]", txt);
		return this;
	}

	public SearchResult_Page Verify_Position_type_filter_selectedvalue(String txt) {

		dynamicElementDisplayed("(//div[contains(@class,'dropdown-single-value__placeholder')])[4]", txt);
		return this;
	}

	public SearchResult_Page Verify_Position_type_filter_Alphaorder() {

		Verify_Alphabatic_Order("(//div[contains(@class,'dropdown-single-value__option')])[position()>1]");

		return this;
	}

	public SearchResult_Page Verify_Experience_level_type_filter_Alphaorder() {

		Verify_Alphabatic_Order("(//div[contains(@class,'dropdown-multi-values__option')])[position()>1]");

		return this;
	}

	public SearchResult_Page Verify_Job_Country_filter() {

		verifyElementDisplayed(SearchResultPageConstants.Job_Country_filter);
		return this;
	}

	public SearchResult_Page Click_Job_Country_filter() throws InterruptedException {

		clickWebElement(SearchResultPageConstants.Job_Country_filter);
		Thread.sleep(2000);

		return this;
	}

	public SearchResult_Page Click_Job_Country_filter1() throws InterruptedException {
		Thread.sleep(2000);
		clickWebElement(SearchResultPageConstants.Job_Country_filter1);	
		return this;
	}


	public SearchResult_Page Verify_Single_Selection_value() {
		if(driver.findElement(By.xpath("(//div[contains(@class,'dropdown-single-value__option')])")).isDisplayed())
		{
			logger("Verification: Only single value can be selected", Status.PASS);
		}
		return this;
	}

	public SearchResult_Page Verify_Job_Country_filter_value(String txt) {

		dynamicElementDisplayed("(//div[contains(@class,'dropdown-single-value__option')])", txt);
		return this;
	}


	public SearchResult_Page Verify_Job_Country_filter_container(String txt) throws InterruptedException {
		Thread.sleep(2000);
		dynamicElementDisplayed("(//div[contains(@class,'dropdown-single-value__placeholder')])[1]", txt);
		return this;
	}

	public SearchResult_Page Verify_Altered_Country_filter() {

		SearchResultPageConstants.Job_Country_filter.click();
		Job_Country_altervalue = driver.findElements(By.xpath("(//div[contains(@class,'dropdown-single-value__option')])[position()>1]"));

		if(Job_Country_altervalue.equals(Job_Country_intialvalue))
		{
			logger("Verification: Country filter is not altered", Status.FAIL);
		}
		else
		{
			logger("Verification: Country filter is altered", Status.PASS);	
		}
		SearchResultPageConstants.Job_Country_filter.click();
		return this;
	}

	public SearchResult_Page Verify_Altered_Location_filter() {

		SearchResultPageConstants.Job_Location_filter.click();
		Job_location_altervalue = driver.findElements(By.xpath("(//div[contains(@class,'dropdown-single-value__option')])[position()>1]"));

		if(Job_location_altervalue.equals(Job_location_intialvalue))
		{
			logger("Verification: Location filter is not altered", Status.FAIL);
		}
		else
		{
			logger("Verification: Location filter is altered", Status.PASS);	
		}
		SearchResultPageConstants.Job_Location_filter.click();
		return this;
	}

	public SearchResult_Page Verify_Altered_Job_area_filter() throws InterruptedException {
		Thread.sleep(2000);
		SearchResultPageConstants.Job_Area_filter.click();
		Job_area_altervalue = driver.findElements(By.xpath("(//div[contains(@class,'dropdown-single-value__option')])[position()>1]"));

		if(Job_area_altervalue.equals(Job_area_intialvalue))
		{
			logger("Verification: Job area is not altered", Status.FAIL);
		}
		else
		{
			logger("Verification: Job area filter is altered", Status.PASS);	
		}
		SearchResultPageConstants.Job_Area_filter.click();
		return this;
	}

	public SearchResult_Page Select_Job_Country_filter_value(String txt) throws InterruptedException {

		dynamicElementselector("(//div[contains(@class,'dropdown-single-value__option')])", txt);
		Thread.sleep(2000);
		return this;
	}

	public SearchResult_Page Select_Job_Position_type_filter_value(String txt) throws InterruptedException {

		dynamicElementselector("(//div[contains(@class,'dropdown-single-value__option')])", txt);
		Thread.sleep(2000);
		return this;
	}

	public SearchResult_Page Select_Job_Experience_level_filter_value(String txt) throws InterruptedException {

		dynamicElementselector("//div[contains(@class,'multiselect-option')]//label", txt);
		Thread.sleep(2000);
		return this;
	}
	public SearchResult_Page Verify_Job_Location_filter() {
		verifyElementNotDisplayed("(((//div[text()='Location'])[1])//ancestor::div[contains(@class,'is-disabled')])[1]");
		//verifyElementDisplayed(SearchResultPageConstants.Job_Location_filter);
		return this;
	}

	public SearchResult_Page Click_Job_Location_filter() throws InterruptedException {
		verifyElementEnabled(SearchResultPageConstants.Job_Location_filter_enabled);
		clickWebElement(SearchResultPageConstants.Job_Location_filter_enabled);
		Thread.sleep(3000);
		return this;
	}

	public SearchResult_Page Verify_Job_Location_filter_container(String txt) {

		dynamicElementDisplayed("(//div[contains(@class,'dropdown-single-value__placeholder')])[2]", txt);
		return this;
	}

	public SearchResult_Page Verify_Job_Location_filter_selectedvalue(String txt) {
		dynamicElementDisplayed("(//div[contains(@class,'selected-value')]//child::div[contains(@class,'dropdown-single-value__single-value')])[2]", txt);
		return this;
	}

	public SearchResult_Page Verify_Job_country_filter_Alphaorder() {

		Verify_Alphabatic_Order("(//div[contains(@class,'dropdown-single-value__option')])[position()>1]");
		Job_Country_intialvalue = driver.findElements(By.xpath("(//div[contains(@class,'dropdown-single-value__option')])[position()>1]"));
		return this;
	}

	public SearchResult_Page Select_Job_Location_filter_value(String txt) {

		dynamicElementselector("(//div[contains(@class,'dropdown-single-value__option')])", txt);
		return this;
	}

	public SearchResult_Page Verify_Job_Location_filter_value(String txt) {

		dynamicElementDisplayed("(//div[contains(@class,'dropdown-single-value__option')])", txt);
		return this;
	}

	public SearchResult_Page Verify_Location_filter_Alphaorder() {

		Verify_Alphabatic_Order("(//div[contains(@class,'dropdown-single-value__option')])[position()>1]");
		Job_location_intialvalue = driver.findElements(By.xpath("(//div[contains(@class,'dropdown-single-value__option')])[position()>1]"));
		return this;
	}

	public SearchResult_Page Verify_Location_filter_inActive() {

		if(SearchResultPageConstants.Job_Location_filter_disabled.isDisplayed())
		{
			logger("Verification: Location filter is not active", Status.PASS);
		}
		else
		{
			logger("Verification: issue in Location filter", Status.FAIL);
		}

		return this;
	}

	public SearchResult_Page Verify_Location_filter_Active() {

		if(SearchResultPageConstants.Job_Location_filter_enabled.isDisplayed())
		{
			logger("Verification: Location filter is active", Status.PASS);
		}
		else
		{
			logger("Verification: issue in Location filter", Status.FAIL);
		}

		return this;
	}


	////////////////////Learning///////////////////////////////////

	List<WebElement> Learning_Language_altervalue, Learning_Language_intialvalue, Learning_Coursecategory_altervalue, Learning_Coursecategory_intialvalue;

	public SearchResult_Page Verify_learnings_count() {

		if(SearchResultPageConstants.learning_tab.getText().matches("([0-9]+)"));
		{
			String substring = SearchResultPageConstants.learning_tab.getText().substring(SearchResultPageConstants.learning_tab.getText().indexOf('('), SearchResultPageConstants.learning_tab.getText().indexOf(')'));
			logger("Verification: learnings Tab contains number of result: "+substring+")", Status.PASS);
		}

		return this;
	}

	public SearchResult_Page Verify_learning_tab() {
		verifyElementDisplayed(SearchResultPageConstants.learning_tab);
		return this;
	}

	public SearchResult_Page Click_learning_tab() {
		clickWithScreenshot(SearchResultPageConstants.learning_tab);
		return this;
	}

	public SearchResult_Page Verify_Learning_Posting_items() {

		if(driver.findElement(By.xpath("(//div[@class='tile__image bordered'])[1]")).isDisplayed())
		{
			logger("Verification: Image is displayed", Status.PASS);
		}
		else
		{
			logger("Verification: Image is displayed", Status.FAIL);
		}

		if(SearchResultPageConstants.Learning_External_icon.isDisplayed())
		{
			logger("Verification: External icon is displayed", Status.PASS);
		}
		else {
			logger("Verification: External icon is not displayed", Status.FAIL);
		}
		verifyElementDisplayed(SearchResultPageConstants.learning_title);
		verifyElementDisplayed(SearchResultPageConstants.learning_segment);
		verifyElementDisplayed(SearchResultPageConstants.learning_description);
		return this;
	}

	public SearchResult_Page Verify_Learning_title_Highlighted() throws InterruptedException {

		VerifyElementIsHighlighted(SearchResultPageConstants.learning_title);

		return this;
	}

	public SearchResult_Page Verify_Whole_Learning_item_isclickable() {

		VerifyElementIsClickable("(//div[@class='tile__text'])[1]");

		return this;
	}

	public SearchResult_Page Click_learning_Title() {

		clickWebElement(SearchResultPageConstants.learning_title);

		return this;
	}

	public SearchResult_Page Verify_Sabacloud_Page() {
		switchToWindow(1);
		if(driver.getCurrentUrl().contains("sabacloud.com/Saba"))
		{
			logger("Verification: Saba learning page is Opened", Status.PASS);
		}
		else
		{
			logger("Verification: Saba learning page is not Opened", Status.FAIL);
		}
		return this;

	}

	public SearchResult_Page Navigate_Back_SearchScreen() {
		switchToWindow(0);
		return this;

	}

	public SearchResult_Page Verify_InActive_CourseCategory_filter() {
		if(SearchResultPageConstants.learning_course_category_filter_disabled.isDisplayed())
		{
			logger("Verification: Course category filter is inactive", Status.PASS);
		}
		else
		{
			logger("Verification: Issue with Course category filter", Status.FAIL);	
		}
		return this;
	}

	public SearchResult_Page Verify_Active_CourseCategory_filter() throws InterruptedException {
		Thread.sleep(2000);
		if(SearchResultPageConstants.learning_course_category_filter_enabled.isDisplayed())
		{
			logger("Verification: Course category filter is active", Status.PASS);
		}
		else
		{
			logger("Verification: Issue with Course category filter", Status.FAIL);	
		}
		return this;
	}

	public SearchResult_Page Verify_Course_Category_filter_Alphaorder() {

		Verify_Alphabatic_Order("(//div[contains(@class,'dropdown-single-value__option')])[position()>1]");

		return this;
	}

	public SearchResult_Page Verify_Learning_Business_Filter() {
		verifyElementDisplayed(SearchResultPageConstants.business_unit);
		return this;
	}

	public SearchResult_Page Click_Learning_Business_Filter() throws InterruptedException {
		clickWebElement(SearchResultPageConstants.business_unit);
		Thread.sleep(1000);
		return this;
	}

	public SearchResult_Page Verify_NoSelected_Value_Learning_Business_filter() {
		List<WebElement> findElementsByXPath = driver.findElements(By.xpath("//div[contains(@class,'dropdown-single-value__menu-list')]//child::div[contains(@class,'is-selected')]"));
		try {
			if (findElementsByXPath.size()==0) {

				loggerWithScreenshot("Verification: There is no Selected value and Default value is shown", "", Status.PASS, true); 
				Thread.sleep(1000);
			}
		} catch (Exception e) {
			logger("Verification: Exception Occured : " + e.getMessage(), Status.FAIL);
		}

		return this;
	}

	public SearchResult_Page Verify_Learning_Business_Filter_value(String txt) {
		dynamicElementDisplayed("//div[contains(@class,'dropdown-single-value__menu-list')]//child::div[contains(@id,'react-select')]", txt);
		return this;
	}

	public SearchResult_Page Verify_Learning_Business_Filter_Selectedvalue(String txt) {
		dynamicElementDisplayed("//div[contains(@class,'dropdown-single-value__single-value')]", txt);
		return this;
	}

	public SearchResult_Page Click_Learning_Business_Filter_value(String txt) throws InterruptedException {
		try {
			driver.findElement(By.xpath("//div[text()='"+txt+"']")).click();
			logger("Verification: Value "+txt+" is selected", Status.PASS);
		} catch (Exception e) {

			e.printStackTrace();
		}
		Thread.sleep(2000);
		Actions act = new Actions(driver);
		act.sendKeys(Keys.TAB).build().perform();
		return this;
	}

	public SearchResult_Page Click_Learning_Course_Category_Filter(String txt) throws InterruptedException {
		try {
			driver.findElement(By.xpath("//div[text()='"+txt+"']")).click();
			logger("Verification: Value "+txt+" is selected", Status.PASS);
		} catch (Exception e) {

			e.printStackTrace();
		}
		Thread.sleep(2000);
		return this;
	}

	public SearchResult_Page Click_Learning_Course_Category_Filter() throws InterruptedException {
		clickWebElement(SearchResultPageConstants.learning_course_category_filter_enabled);
		Thread.sleep(1000);
		return this;
	}


	public SearchResult_Page Verify_Learning_Course_category_Filter_container(String txt) {
		dynamicElementDisplayed("((//div[contains(@class,'value-container')])[4]//child::div)[1]", txt);
		return this;
	}

	public SearchResult_Page Verify_Learning_Second_Course_category_Filter() throws InterruptedException {
		Thread.sleep(2000);
		if(SearchResultPageConstants.learning_course_category_second.isDisplayed())
		{
			logger("Verification: Second Category Filter is displayed", Status.PASS);
		}
		else
		{
			logger("Verification: Issue with Second category filter", Status.FAIL);
		}
		dynamicElementDisplayed("((//div[contains(@class,'value-container')])[5]//child::div)[1]", "Course category");
		return this;
	}

	public SearchResult_Page Verify_Learning_No_Second_Course_category_Filter() {

		List<WebElement> didyoumean = driver.findElements(By.xpath("(//div[@class='select-size-detector'][text()='Course category'])[2]"));
		if(didyoumean.size()==1)
		{
			logger("Verification: Second Course categiry filter is not displayed", Status.PASS);
		}
		else
		{
			logger("Verification: Issue with Second Course categiry filter", Status.FAIL);
		}

		return this;
	}


	public SearchResult_Page Verify_Learning_Languages_Filter() {
		verifyElementDisplayed(SearchResultPageConstants.learning_languages_filter_new);
		return this;
	}

	public SearchResult_Page Click_Learning_Languages_Filter() {
		clickWebElement(SearchResultPageConstants.learning_languages_filter_new);
		return this;
	}

	public SearchResult_Page Click_Learning_Languages_Filtervalue(String txt) throws InterruptedException {
		Thread.sleep(1000);
		dynamicElementselector("(//div[contains(@class,'dropdown-multi-values__option')]//label)[position()>1]", txt);
		return this;
	}

	public SearchResult_Page Click_Learning_Languages_Filter_arrow() throws InterruptedException {
		Thread.sleep(1000);
		SearchResultPageConstants.Multi_select_arrowIcon.click();
		return this;
	}

	public SearchResult_Page Verify_Learning_Languages_selectedvalue() {
		verifyElementDisplayed(SearchResultPageConstants.learning_languages_filter_new2);
		return this;
	}

	public SearchResult_Page Verify_Learning_Languages_Filter_alphabetic() {
		Verify_Alphabatic_Order("(//div[contains(@class,'dropdown-multi-values__option')]//label)[position()>1]");
		Learning_Language_intialvalue = driver.findElements(By.xpath("(//div[contains(@class,'dropdown-multi-values__option')]//label)[position()>1]"));
		logger("Verification: Language filter is Multiselect dropdown", Status.PASS);
		return this;
	}

	public SearchResult_Page Verify_Altered_Learning_Language_filter() throws InterruptedException {
		Thread.sleep(2000);
		SearchResultPageConstants.Multi_select_arrowIcon.click();
		Learning_Language_altervalue = driver.findElements(By.xpath("(//div[contains(@class,'dropdown-multi-values__option')]//label)[position()>1]"));

		if(Learning_Language_altervalue.equals(Learning_Language_intialvalue))
		{
			logger("Verification: Learning_Language_filter is not altered", Status.FAIL);
		}
		else
		{
			logger("Verification: Learning_Language_filter is altered", Status.PASS);	
		}
		SearchResultPageConstants.Multi_select_arrowIcon.click();
		return this;
	}

	public SearchResult_Page Verify_Learning_coursecategory_filter_selectedvalue(String text) 
	{
		if(driver.findElement(By.xpath("((//div[contains(@class,'single-value__value-container')])[3]//child::div)[1]")).getText().contains(text))
		{
			logger("Verification: "+text+" is selected value in Course category filter", Status.PASS);
		}
		else
		{
			logger("Verification: issue with selected value in Course category filter", Status.FAIL);
		}
		return this;

	}

	public SearchResult_Page Verify_PlaceHolder_search() throws InterruptedException {

		if(verifyElementNotDisplayed("//input[@placeholder='Search in results']"))

		{
			logger("Verification: Placeholder search box is not available " , Status.PASS);
			

		}

		else {

			logger("Verification: Placeholder search box is available " , Status.FAIL);
		}

		return this;
	}

	public SearchResult_Page Click_Status_Filter_Value(String txt) throws InterruptedException {
		try {
			driver.findElement(By.xpath("//div[text()='"+txt+"']")).click();
			logger("Verification: Value "+txt+" is selected", Status.PASS);
		} catch (Exception e) {

			e.printStackTrace();
		}
		Thread.sleep(2000);
		return this;
	}
	
	public SearchResult_Page Verify_Business_Filter_value_Alphaorder() {
		Verify_Alphabatic_Order("//div[contains(@class,'dropdown-single-value__menu-list')]//child::div[contains(@id,'react-select')]");
		return this;
	}
	
	public SearchResult_Page Click_Product_item1() throws InterruptedException {
		Thread.sleep(3000);
		WebElement xPath = driver.findElement(By.xpath("((//div[contains(@class,'tile__text-title')])[1])//parent::a"));
		String attribute = xPath.getAttribute("href");
		//System.out.println(attribute);
		clickWebElement(SearchResultPageConstants.product_tile_txt);
		if(driver.getCurrentUrl().contains("danfosswebexstagingcdn.azureedge.net"))
		{
			
			String replacedurl = attribute.replace("danfosswebexstagingcdn.azureedge.net", "danfoss-webex-staging.trafficmanager.net");
						
			driver.get(replacedurl);
		}
		return this;
	}
	
	public SearchResult_Page switch_To_New_Window_And_Close_IT() throws InterruptedException{
		switch_To_New_Window_And_Close_It();
		return this;
	}
	
	
	public SearchResult_Page Wait() throws InterruptedException {
		Thread.sleep(3000);
		return this;
	}
	
	
	public SearchResult_Page Click_clear_button() {
		try {
			Thread.sleep(2000);
			VerifyElementIsClickable(SearchResultPageConstants.clear_filter);
			SearchResultPageConstants.clear_filter.click();
			logger("Verification: Clear filter button is clicked", Status.PASS);
		} catch (Exception e) {
			e.printStackTrace();
			logger("Verification: unexpected error", Status.FAIL);
		}
		return this;
	}

	public SearchResult_Page Click_Learning_Business_Filter_Drives() throws InterruptedException {
		clickWebElement(SearchResultPageConstants.business_unit_filter_with_values);
		Thread.sleep(1000);
		return this;
	}
	
	public SearchResult_Page Close_Current_Window() throws InterruptedException {
		switch_To_New_Window_And_Close_IT();
		try {
			driver.close();
			logger("Current active window is closed",Status.PASS);
		} catch (Exception e) {
			logger("Current active window is not closed",Status.FAIL);
		}
		return this; 
	}
	
	public SearchResult_Page Verify_All_Countries_regions_filter_is_Disable() throws InterruptedException{
		verifyElementDisplayed(SearchResultPageConstants.all_countries_regions);
		VerifyElementColour(SearchResultPageConstants.all_countries_regions, "rgba(191, 190, 190, 1)");
		logger("Verification: All Countries/regions filter is present but disabled", Status.PASS);
		return this;
	}
	
	public SearchResult_Page Verify_Hierarchy_Level1_Filter_Is_Present(){
		verifyElementDisplayed(SearchResultPageConstants.document_level1_dd);
		return this;
	}
	
	public SearchResult_Page Verify_Hierarchy_Level2_Filter_Is_Present(){
		verifyElementDisplayed(SearchResultPageConstants.document_level2_dd);
		return this;
	}
	
	public SearchResult_Page Verify_Hierarchy_Level3_Filter_Is_Present(){
		verifyElementDisplayed(SearchResultPageConstants.document_level3_dd);
		return this;
	}
	
	public SearchResult_Page Verify_Hierarchy_Level1_Filter_Arrowdown() {
		verifyElementDisplayed(SearchResultPageConstants.hierarchy_filter_level1_arrowdown);	
		return this;
	}
	
	public SearchResult_Page Verify_Hierarchy_Level2_Filter_Arrowdown() {
		verifyElementDisplayed(SearchResultPageConstants.hierarchy_filter_level2_arrowdown);	
		return this;
	}
	
	public SearchResult_Page Verify_Hierarchy_Level3_Filter_Arrowdown() {
		verifyElementDisplayed(SearchResultPageConstants.hierarchy_filter_level3_arrowdown);	
		return this;
	}
	
	public SearchResult_Page Verify_SearchResult_Products_with_product_link() {
		try {
			int size = driver.findElements(By.xpath("((//ul[contains(@class,'tile-group  tile-group-wide  no-ktr search-results-list-items bordered-list-items ')]/li/div/a)/div[1])")).size();
			for(int i=1;i<=size;i++) {		
				String title = driver.findElement(By.xpath("((//ul[contains(@class,'tile-group  tile-group-wide  no-ktr search-results-list-items bordered-list-items ')]/li/div/a)/div[1])["+i+"]")).getText();
				logger("Product Title is present as "+title,Status.PASS);
			}
		}catch(Exception e) {
			logger("Product Title is not present",Status.FAIL);
		}
		
		return this;
	}
	
	public SearchResult_Page Verify_SearchResult_Products_with_product_image() {
		int size = driver.findElements(By.xpath("(//ul[contains(@class,'tile-group  tile-group-wide  no-ktr search-results-list-items bordered-list-items ')]/li/a/div/div/picture)/img")).size();
		
		for(int i=1;i<=size;i++) {
		WebElement image = driver.findElement(By.xpath("((//ul[contains(@class,'tile-group  tile-group-wide  no-ktr search-results-list-items bordered-list-items ')]/li/a/div/div/picture)/img)["+i+"]"));
		MoveToElement(image);
		VerifyImageIsDisplayed(image);
		}
		
		return this;
	}
	
	public SearchResult_Page Verify_SearchResult_Products_with_product_details() {
		try {
			int size = driver.findElements(By.xpath("(//ul[contains(@class,'tile-group  tile-group-wide  no-ktr search-results-list-items bordered-list-items ')]/li/div/a)/div[@class='tile__text-details']/div")).size();
			for(int i=1;i<=size;i++) {		
				String title = driver.findElement(By.xpath("((//ul[contains(@class,'tile-group  tile-group-wide  no-ktr search-results-list-items bordered-list-items ')]/li/div/a)/div[@class='tile__text-details']/div)["+i+"]")).getText();
				logger("Product Detail is present as "+title,Status.PASS);
			}
		}catch(Exception e) {
			logger("Product Detail is not present",Status.FAIL);
		}
		
		return this;
	}
	
	public SearchResult_Page Click_SearchResult_Software() {
		clickWebElement(SearchResultPageConstants.software_result1);
		return this;
	}
	
	public SearchResult_Page Copy_Current_Url_And_Open_In_New_Tab() throws InterruptedException {
		Copy_Current_Url_And_Open_In_New_Tab();
		switch_To_New_Window_And_Close_IT();
		return this;
	}
	
	public SearchResult_Page Copy_Current_Url_And_Open_In_New_Tab2() {
		copy_Current_Url_And_Open_In_New_Tab();
		return this;
	}

	public SearchResult_Page Verify_SearchResult_DownloadType_Software_Color() throws InterruptedException {
		VerifyElementColour(SearchResultPageConstants.software_result1, "rgba(226, 0, 15, 1)");
		return this;
		
	}
	
}
