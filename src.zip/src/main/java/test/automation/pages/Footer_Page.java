package test.automation.pages;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.Dimension;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.PageFactory;

import com.aventstack.extentreports.Status;

import test.automation.globalfunctionality.TestCaseInitiator;
import test.automation.pagelocators.FooterPageConstants;
import test.automation.pagelocators.HomePageconstants;

public class Footer_Page extends TestCaseInitiator{

	public Footer_Page() {
		PageFactory.initElements(driver, FooterPageConstants.class);
	}

	public  Footer_Page verify_Footer_Menu() throws InterruptedException {
		if(verifyElementDisplayed(FooterPageConstants.Ftr_Market_we_serve)&&
				verifyElementDisplayed(FooterPageConstants.Ftr_Service_support)&&
				verifyElementDisplayed(FooterPageConstants.Ftr_Our_Businesses)&&
				verifyElementDisplayed(FooterPageConstants.Ftr_About_danfoss))
		{
			logger("Verification: Footer menus are displayed", Status.PASS);

		}
		return this;

	}

	public  Footer_Page verify_Four_PrimarySections() throws InterruptedException {
		if(FooterPageConstants.Ftr_primary1_market_we_serve.isDisplayed()&&
				FooterPageConstants.Ftr_primary2_service_support.isDisplayed()&&
				FooterPageConstants.Ftr_primary3_our_businesses.isDisplayed()&&
				FooterPageConstants.Ftr_primary4_about_danfoss.isDisplayed())
		{
			logger("Verification: Four Primary list of menus are displayed", Status.PASS);

		}
		return this;

	}

	public  Footer_Page verify_backgroundcolour_Footer_primary() throws InterruptedException {

		FooterPageConstants.Ftr_primary_footer.getCssValue("background-color");
		return this;

	}

	public  Footer_Page verify_PrimarySections() throws InterruptedException {
		if(FooterPageConstants.Ftr_primary_footer.isDisplayed())
		{
			logger("Verification: Primary menus in footer are displayed", Status.PASS);

		}
		return this;

	}
	public  Footer_Page verify_SecondarySections() throws InterruptedException {
		if(FooterPageConstants.Ftr_secondary_footer.isDisplayed())
		{
			logger("Verification: Secondary menus in footer are displayed", Status.PASS);

		}
		return this;

	}

	public  Footer_Page verify_backgroundcolour_Footer_Secondary() throws InterruptedException {
		MoveToElement(FooterPageConstants.Ftr_primary_footer);
		String cssValue = FooterPageConstants.Ftr_primary_footer.getCssValue("background-color");
		if(cssValue.contains("rgba(104, 104, 104, 1)"))
		{
			logger("BackgroundColor is Matching with expected" , Status.PASS);
		}
		System.out.println(cssValue);
		return this;

	}

	public  Footer_Page verify_Siteselector() throws InterruptedException {

		verifyElementDisplayed(FooterPageConstants.Ftr_choose_region);
		return this;
	}

	public  Footer_Page Verify_Highlighted_menu() throws InterruptedException  {

		VerifyElementIsHighlighted(FooterPageConstants.Ftr_Market_we_serve);
		VerifyElementIsHighlighted(FooterPageConstants.Ftr_Service_support);
		VerifyElementIsHighlighted(FooterPageConstants.Ftr_Our_Businesses);
		VerifyElementIsHighlighted(FooterPageConstants.Ftr_About_danfoss);
		VerifyElementIsHighlighted(FooterPageConstants.Ftr_Automotive);
		VerifyElementIsHighlighted(FooterPageConstants.Ftr_buildings_commercial);
		VerifyElementIsHighlighted(FooterPageConstants.Ftr_buildings_residential);
		VerifyElementIsHighlighted(FooterPageConstants.Ftr_district_energy);
		VerifyElementIsHighlighted(FooterPageConstants.Ftr_energy_and_natural);
		VerifyElementIsHighlighted(FooterPageConstants.Ftr_food_beverage);
		VerifyElementIsHighlighted(FooterPageConstants.Ftr_industry);
		VerifyElementIsHighlighted(FooterPageConstants.Ftr_marine_offshore);
		VerifyElementIsHighlighted(FooterPageConstants.Ftr_mobile_hydraulics);
		VerifyElementIsHighlighted(FooterPageConstants.Ftr_refrigeration_airconditioning);
		VerifyElementIsHighlighted(FooterPageConstants.Ftr_water_wastewater);
		VerifyElementIsHighlighted(FooterPageConstants.Ftr_documentation);
		VerifyElementIsHighlighted(FooterPageConstants.Ftr_downloads);
		VerifyElementIsHighlighted(FooterPageConstants.Ftr_case_studies);
		VerifyElementIsHighlighted(FooterPageConstants.Ftr_fix_troubleshooting);
		VerifyElementIsHighlighted(FooterPageConstants.Ftr_contact_us);
		VerifyElementIsHighlighted(FooterPageConstants.Ftr_learning);
		//VerifyElementIsHighlighted(FooterPageConstants.Ftr_cooling);
		VerifyElementIsHighlighted(FooterPageConstants.Ftr_climate_solution);
		VerifyElementIsHighlighted(FooterPageConstants.Ftr_drives);
		VerifyElementIsHighlighted(FooterPageConstants.Ftr_editron);
		VerifyElementIsHighlighted(FooterPageConstants.Ftr_emission_monitoring);
		VerifyElementIsHighlighted(FooterPageConstants.Ftr_fire_safety);
		//VerifyElementIsHighlighted(FooterPageConstants.Ftr_heating);
		VerifyElementIsHighlighted(FooterPageConstants.Ftr_high);
		VerifyElementIsHighlighted(FooterPageConstants.Ftr_sensing_solutions);
		VerifyElementIsHighlighted(FooterPageConstants.Ftr_power_solutions);
		VerifyElementIsHighlighted(FooterPageConstants.Ftr_silicon_power);
		VerifyElementIsHighlighted(FooterPageConstants.Ftr_product_store);
		VerifyElementIsHighlighted(FooterPageConstants.Ftr_company);
		VerifyElementIsHighlighted(FooterPageConstants.Ftr_news_events);
		VerifyElementIsHighlighted(FooterPageConstants.Ftr_insights_tomorrow);
		//VerifyElementIsHighlighted(FooterPageConstants.Ftr_sustainability);
		VerifyElementIsHighlighted(FooterPageConstants.Ftr_financials);
		//VerifyElementIsHighlighted(FooterPageConstants.Ftr_careers);
		VerifyElementIsHighlighted(FooterPageConstants.Ftr_privacy);
		VerifyElementIsHighlighted(FooterPageConstants.Ftr_terms_use);
		VerifyElementIsHighlighted(FooterPageConstants.Ftr_general_information);
		VerifyElementIsHighlighted(FooterPageConstants.Ftr_Cookie);
		VerifyElementIsHighlighted(FooterPageConstants.Ftr_choose_region);

		return this;
	}


	public  Region_Selection_Page Click_RegionSelectionbutton()  {
		clickWebElement(FooterPageConstants.Ftr_choose_region);
		return new Region_Selection_Page();
	}

	public  Footer_Page Click_Verify_Market_We_Serve() throws InterruptedException  {
		clickWebElement(FooterPageConstants.Ftr_Market_we_serve);
		verifyPageTitle("Markets we serve | Danfoss");
		return this;
	}

	public  Footer_Page Click_Verify_Service_Support() throws InterruptedException  {
		scrollBottomOfPageJS();
		clickWebElement(FooterPageConstants.Ftr_Service_support);
		verifyPageTitle("Service and support - need help? | Danfoss");
		return this;

	}

	public  Footer_Page Click_Verify_Our_Business() throws InterruptedException  {
		scrollBottomOfPageJS();
		clickWebElement(FooterPageConstants.Ftr_Our_Businesses);
		verifyPageTitle("Danfoss' businesses - Engineering since 1933 - Explore innovative solutions for many markets | Danfoss");
		return this;

	}

	public  Footer_Page Click_Verify_About_Danfoss() throws InterruptedException  {
		scrollBottomOfPageJS();
		clickWebElement(FooterPageConstants.Ftr_About_danfoss);
		verifyPageTitle("About Danfoss - Engineering since 1933 - Explore innovative solutions for industry | Danfoss");
		return this;

	}

	public Footer_Page verifyPrimaryHeadersChangeSizeonScrolling() throws InterruptedException {
		Dimension size1 = HomePageconstants.primary_header.getSize();

		int height1 = size1.height;

		scrollBottomOfPageJS();
		Thread.sleep(2000);
		Dimension size2 = HomePageconstants.primary_header.getSize();

		int height2 = size2.height;

		if(height1>height2)
		{
			logger("On Scrolling down primary header size is reduced",Status.PASS);
		}else {
			logger("On Scrolling down primary header size is not reduced",Status.FAIL);
		}

		return this;
	}

	public Footer_Page verifyMenuHeadersChangeSizeonScrolling() throws InterruptedException {
		scrollTopOfPageJS();
		Thread.sleep(2000);
		Dimension size3 = HomePageconstants.menu_header.getSize();

		int height3 = size3.height;
		scrollBottomOfPageJS();
		Thread.sleep(2000);

		Dimension size4 = HomePageconstants.menu_header.getSize();

		int height4 = size4.height;
		if(height3>height4)
		{
			logger("On Scrolling down menu header size is reduced",Status.PASS);
		}else {
			logger("On Scrolling down menu header size is not reduced",Status.FAIL);
		}

		return this;
	}

	/****************** Social Media *************************/

	public  Footer_Page verify_Social_Media_title()  {
		verifyElementDisplayed(FooterPageConstants.Social_media_title);
		return this;
	}

	public  Footer_Page verify_Social_Media_section()  {
		verifyElementDisplayed(FooterPageConstants.Social_media_section);
		logger("Verfication: Social Media section displayed leftside of Newsletter button", Status.PASS);
		return this;
	}

	public  Footer_Page verify_linkedin()  {
		if(FooterPageConstants.linkedin.isDisplayed())
		{
			logger("Verification: Linkedin button is displayed", Status.PASS);
		}
		return this;
	}

	public  Footer_Page verify_Twitter()  {
		if(FooterPageConstants.twitter.isDisplayed())
		{
			logger("Verification: Twitter button is displayed", Status.PASS);
		}
		return this;
	}

	public  Footer_Page verify_Facebook()  {
		if(FooterPageConstants.facebook.isDisplayed())
		{
			logger("Verification: Facebook button is displayed", Status.PASS);
		}
		return this;
	}

	public  Footer_Page verify_Youtube() {
		if(FooterPageConstants.youtube.isDisplayed())
		{
			logger("Verification: Youtube button is displayed", Status.PASS);
		}
		return this;
	}

	public  Footer_Page click_Youtube() {
		FooterPageConstants.youtube.click();
		logger("Verification: Youtube button is clicked", Status.PASS);
		switchToWindow(1);
		String currentUrl = driver.getCurrentUrl();
		Verify_TwoString("https://www.youtube.com/user/DanfossGroup", currentUrl);
		//Verify_TwoString("https://www.youtube.com/user/DanfossGroup", currentUrl);
		return this;
	}

	///newsletter

	public  Footer_Page verify_Newsletter_Signup_button() {
		
		if(FooterPageConstants.Newsletter_signup.isDisplayed())
		{
			logger("Verification: Newsletter_signup button is displayed", Status.PASS);
		}
		return this;
	}

	public  Footer_Page verify_Newsletter_description()  {
		verifyElementDisplayed(FooterPageConstants.Keep_me_updated);
		return this;
	}

	public  Footer_Page click_Newsletter_button()  {
		clickWebElement(FooterPageConstants.Keep_me_updated);
		return this;
	}

	public  Footer_Page verify_Newsletter_form() throws InterruptedException {
		Thread.sleep(2000);
		try {
			if(FooterPageConstants.Newsletter_form_popup.isDisplayed())
			{
				logger("Verification: Newsletter_signup form pop is displayed", Status.PASS);
			}
			if(FooterPageConstants.Newsletter_signup_title.isDisplayed())
			{
				logger("Verification: Newsletter_signup title is displayed", Status.PASS);
			}
			if(FooterPageConstants.Newsletter_signup_form.isDisplayed())
			{
				logger("Verification: Newsletter_signup form body is displayed", Status.PASS);
			}
		} catch (Exception e) {
			logger("Verification: Issue in displaying Newsletter_signup form", Status.FAIL);
		}
		return this;
	}

	public Footer_Page Wait(int timeunit) throws InterruptedException {
		Thread.sleep(timeunit);
		return this;
	}
	
	public Footer_Page Click_Privacy_And_Policy(){
		clickWebElement(HomePageconstants.privacyPolicy);
		return this;
	}
	
	public Footer_Page Click_Terms_In_Footer(){
		clickWebElement(FooterPageConstants.Ftr_terms_of_use);
		return this;
	}
	
	public Footer_Page Verify_Terms_Page_Breadcrumbs(){
		verifyElementDisplayed(FooterPageConstants.Ftr_terms_breadcrums);
		return this;
	}
	
	public Footer_Page Verify_Terms_Page_Title() throws InterruptedException{
		verifyPageTitle("Terms of use");
		return this;
	}
	
	public Footer_Page Verify_Terms_Page_In_English_Language() throws InterruptedException{
		if(getText(FooterPageConstants.ftr_Terms_content).contains("Please read these terms and conditions (the “Terms”) carefully before using the Danfoss Web Site (\"Site\"). By using the Site you signify your consent to these Terms. If you do not agree to the Terms please do not use the Site. The Terms addresses your legal rights and obligations and includes important disclaimers and choice of law and forum provisions. Please read carefully. The Terms apply to all web sites of the Danfoss Group, including sites for registered users."))
		{
			logger("Verification: Terms page Content is displayed in English", Status.PASS);
		}else {
			logger("Verification: Terms page Content is not displayed in English", Status.FAIL);
		}
		return this;
	}
	
	
	public Footer_Page Verify_Privacy_And_Policy_Breadcrumbs(){
		verifyElementDisplayed(HomePageconstants.breadcreumbs);
		return this;
	}
	
	public Footer_Page Verify_Privacy_And_Policy_Page_Title() throws InterruptedException{
		verifyPageTitle("Privacy policy");
		return this;
	}
	
	public Footer_Page Verify_Privacy_And_Policy_Links(){
		verifyElementDisplayed(HomePageconstants.privacyPolicy_Click_Here1);
		verifyElementDisplayed(HomePageconstants.privacyPolicy_Click_Here2);
		return this;
	}
	
	public SearchResult_Page Click_Link2_In_Privacy_Policy() throws InterruptedException{
		clickWebElement(HomePageconstants.privacyPolicy_Click_Here2);
		verifyPageTitle("Privacy policy | Danfoss");
		switch_To_New_Window_And_Close_It();
		return new SearchResult_Page();
	}
	
	public Footer_Page Click_Link1_In_Privacy_Policy() throws InterruptedException{
		clickWebElement(HomePageconstants.privacyPolicy_Click_Here1);
		verifyPageTitle("Choose country/region/language");
		driver.navigate().back();
		return this;
	}
	
	public  Footer_Page Script_Pass_Logger(){
		logger("Script Pass Successfully",Status.PASS);
		return this;
	}	
	
	public  Footer_Page Verify_Global_Information_link_Is_Present_In_Footer(){
		verifyElementDisplayed(FooterPageConstants.Ftr_general_information);
		return this;
	}
	
	public  Region_Selection_Page Click_Globe() throws InterruptedException {
		Thread.sleep(2000);
		HomePageconstants.Region_selection_button.click();
		logger("Verification: Region_Selection Button is clicked", Status.PASS);
		return new Region_Selection_Page();
	}
	
	public Footer_Page Navigate_To_Footer() throws InterruptedException {
		scrollBottomOfPageJS();
		Thread.sleep(2000);
		return new Footer_Page();
	}
	
	public Footer_Page Click_General_Information_In_Footer(){
		clickWebElement(FooterPageConstants.Ftr_general_information);
		return this;
	}
	
	public Footer_Page Verify_Breadcrumbs_In_General_Information_Page(){
		verifyElementDisplayed(HomePageconstants.breadcreumbs);
		return this;
	}
	
	public Footer_Page Verify_Title_In_General_Information(){
		verifyElementDisplayed(HomePageconstants.general_Information_Title);
		return this;
	}
	
	public Footer_Page Verify_Title_In_General_Information_local_site(){
		verifyElementDisplayed(HomePageconstants.general_Information_Title_local);
		return this;
	}
	
	public Footer_Page Verify_Multiple_Tabs_Are_present(){
		List<WebElement> tabs = driver.findElements(By.xpath("//div[@class='tabs-list-wrapper']/ul/li"));
		int size = tabs.size();
		if(size==4||size==2) {
			logger("Verification: Multiple tabs are present", Status.PASS);
			for(int i=1;i<=size;i++) {
				driver.findElement(By.xpath("(//div[@class='tabs-list-wrapper']/ul/li)["+i+"]")).click();
				driver.findElement(By.xpath("(//div[@class='tabs-list-wrapper']/ul/li)["+i+"]")).getText();
			}
			driver.findElement(By.xpath("//div[@class='tabs-list-wrapper']/ul/li")).click();
		}
		else if(size!=0) {
			for(int i=1;i<=size;i++) {
				driver.findElement(By.xpath("(//div[@class='tabs-list-wrapper']/ul/li)["+i+"]")).click();
				driver.findElement(By.xpath("(//div[@class='tabs-list-wrapper']/ul/li)["+i+"]")).getText();
			}
			driver.findElement(By.xpath("//div[@class='tabs-list-wrapper']/ul/li")).click();
			logger("Verification: Multiple contacts are not present for this loaction", Status.PASS);
		}
		else {
			logger("Verification: Records(Contacts) not present for this loaction", Status.FAIL);
		}
		
		return this;
	}
	
	public Footer_Page Verify_Contact_Details_Are_Present_In_Each_Tab(){
		List<WebElement> tabs = driver.findElements(By.xpath("//div[@class='tabs-list-wrapper']/ul/li"));
		int size = tabs.size();
		if(size==4) {
			for(int i=1;i<2;i++) {
				driver.findElement(By.xpath("(//div[@class='tabs-list-wrapper']/ul/li)["+i+"]")).click();
				Boolean companyName = driver.findElement(By.xpath("(//div[text()='Company name'])["+i+"]")).isDisplayed();
				if(companyName == Boolean.TRUE) {
					logger("Verification: companyName is present in contact details", Status.PASS);
				}
				else {
					logger("Verification: companyName is not present in contact details", Status.FAIL);
				}
				Boolean companyName_Value = driver.findElement(By.xpath("(//div[text()='Company name']/following-sibling::div)["+i+"]")).isDisplayed();
				if(companyName_Value == Boolean.TRUE) {
					logger("Verification: companyName_Value is present as "+driver.findElement(By.xpath("(//div[text()='Company name']/following-sibling::div)["+i+"]")).getText()+" in contact details", Status.PASS);
				}
				else {
					logger("Verification: companyName_Value is not present in contact details", Status.FAIL);
				}
				Boolean address = driver.findElement(By.xpath("(//div[text()='Address'])["+i+"]")).isDisplayed();
				if(address == Boolean.TRUE) {
					logger("Verification: address is present in contact details", Status.PASS);
				}
				else {
					logger("Verification: address is not present in contact details", Status.FAIL);
				}
				Boolean address_Value = driver.findElement(By.xpath("(//div[text()='Address']/following-sibling::div)["+i+"]")).isDisplayed();
				if(address_Value == Boolean.TRUE) {
					logger("Verification: address_Value is present as "+driver.findElement(By.xpath("(//div[text()='Address']/following-sibling::div)["+i+"]")).getText()+" in contact details", Status.PASS);
				}
				else {
					logger("Verification: address_Value is not present in contact details", Status.FAIL);
				}
				Boolean email = driver.findElement(By.xpath("(//div[text()='E-mail'])["+i+"]")).isDisplayed();
				if(email == Boolean.TRUE) {
					logger("Verification: email is present in contact details", Status.PASS);
				}
				else {
					logger("Verification: email is not present in contact details", Status.FAIL);
				}
				Boolean email_Value = driver.findElement(By.xpath("(//div[text()='E-mail']/following-sibling::div)["+i+"]")).isDisplayed();
				if(email_Value == Boolean.TRUE) {
					logger("Verification: email_Value is present as "+driver.findElement(By.xpath("(//div[text()='E-mail']/following-sibling::div)["+i+"]")).getText()+" in contact details", Status.PASS);
				}
				else {
					logger("Verification: email_Value is not present in contact details", Status.FAIL);
				}
				Boolean company_Reg_No = driver.findElement(By.xpath("(//div[text()='Company Reg. No.'])["+i+"]")).isDisplayed();
				if(company_Reg_No == Boolean.TRUE) {
					logger("Verification: company_Reg_No is present in contact details", Status.PASS);
				}
				else {
					logger("Verification: company_Reg_No is not present in contact details", Status.FAIL);
				}
				Boolean company_Reg_No_Value = driver.findElement(By.xpath("(//div[text()='Company Reg. No.']/following-sibling::div)["+i+"]")).isDisplayed();
				if(company_Reg_No_Value == Boolean.TRUE) {
					logger("Verification: company_Reg_No_Value is present as "+driver.findElement(By.xpath("(//div[text()='Company Reg. No.']/following-sibling::div)["+i+"]")).getText()+" in contact details", Status.PASS);
				}
				else {
					logger("Verification: company_Reg_No_Value is not present in contact details", Status.FAIL);
				}
				Boolean company_Reg_No_VAST_GST = driver.findElement(By.xpath("(//div[text()='Company Reg. No. (VAT/GST)'])["+i+"]")).isDisplayed();
				if(company_Reg_No_VAST_GST == Boolean.TRUE) {
					logger("Verification: company_Reg_No_VAST_GST is present in contact details", Status.PASS);
				}
				else {
					logger("Verification: company_Reg_No_VAST_GST is not present in contact details", Status.FAIL);
				}
				Boolean company_Reg_No_VAST_GST_Value = driver.findElement(By.xpath("(//div[text()='Company Reg. No. (VAT/GST)']/following-sibling::div)["+i+"]")).isDisplayed();
				if(company_Reg_No_VAST_GST_Value == Boolean.TRUE) {
					logger("Verification: company_Reg_No_VAST_GST_Value is present as "+driver.findElement(By.xpath("(//div[text()='Company Reg. No. (VAT/GST)']/following-sibling::div)["+i+"]")).getText()+" in contact details", Status.PASS);
				}
				else {
					logger("Verification: company_Reg_No_VAST_GST_Value is not present in contact details", Status.FAIL);
				}
				Boolean company_Reg_No_Other = driver.findElement(By.xpath("(//div[text()='Company Reg. No. (other)'])["+i+"]")).isDisplayed();
				if(company_Reg_No_Other == Boolean.TRUE) {
					logger("Verification: company_Reg_No_Other is present in contact details", Status.PASS);
				}
				else {
					logger("Verification: company_Reg_No_Other is not present in contact details", Status.FAIL);
				}
				Boolean company_Reg_No_Other_Value = driver.findElement(By.xpath("(//div[text()='Company Reg. No. (other)']/following-sibling::div)["+i+"]")).isDisplayed();
				if(company_Reg_No_Other_Value == Boolean.TRUE) {
					logger("Verification: company_Reg_No_Other_Value is present as "+driver.findElement(By.xpath("(//div[text()='Company Reg. No. (other)']/following-sibling::div)["+i+"]")).getText()+" in contact details", Status.PASS);
				}
				else {
					logger("Verification: company_Reg_No_Other_Value is not present in contact details", Status.FAIL);
				}
			}
			driver.findElement(By.xpath("//div[@class='tabs-list-wrapper']/ul/li")).click();
		}
		else {
			logger("Verification: Multiple tabs are not present", Status.FAIL);
		}
		return this;
	}
	
	public Footer_Page Verify_The_Conatct_tab_Is_Highlight_On_Mouse_Hover() throws InterruptedException {
		List<WebElement> tabs = driver.findElements(By.xpath("//div[@class='tabs-list-wrapper']/ul/li"));
		int size = tabs.size();
		if (size == 4) {
			
			for (int i = 1; i <= 4; i++) {
				WebElement ele = driver.findElement(By.xpath("(//div[@class='tabs-list-wrapper']/ul/li)["+i+"]"));
				//VerifyElementsIsHighlighted("(//div[@class='tabs-list-wrapper']/ul/li)["+i+"]");
				VerifyElementIsHighlighted(ele);
			}
		}
		return this;
	}
	
	public Footer_Page Verify_Contact_Details_Are_Present_In_Each_Tab_Local_Site(){
		List<WebElement> tabs = driver.findElements(By.xpath("//div[@class='tabs-list-wrapper']/ul/li"));
		int size = tabs.size();
		for (int i = 1; i <= size; i++) {
			driver.findElement(By.xpath("(//div[@class='tabs-list-wrapper']/ul/li)[" + i + "]")).click();
			Boolean companyName = driver.findElement(By.xpath("(//div[text()='Company name'])[" + i + "]"))
					.isDisplayed();
			if (companyName == Boolean.TRUE) {
				logger("Verification: companyName is present in contact details", Status.PASS);
			} else {
				logger("Verification: companyName is not present in contact details", Status.FAIL);
			}
			Boolean companyName_Value = driver
					.findElement(By.xpath("(//div[text()='Company name']/following-sibling::div)[" + i + "]"))
					.isDisplayed();
			if (companyName_Value == Boolean.TRUE) {
				logger("Verification: companyName_Value is present as "
						+ driver.findElement(
								By.xpath("(//div[text()='Company name']/following-sibling::div)[" + i + "]")).getText()
						+ " in contact details", Status.PASS);
			} else {
				logger("Verification: companyName_Value is not present in contact details", Status.FAIL);
			}
			Boolean address = driver.findElement(By.xpath("(//div[text()='Address'])[" + i + "]")).isDisplayed();
			if (address == Boolean.TRUE) {
				logger("Verification: address is present in contact details", Status.PASS);
			} else {
				logger("Verification: address is not present in contact details", Status.FAIL);
			}
			Boolean address_Value = driver
					.findElement(By.xpath("(//div[text()='Address']/following-sibling::div)[" + i + "]")).isDisplayed();
			if (address_Value == Boolean.TRUE) {
				logger("Verification: address_Value is present as " + driver
						.findElement(By.xpath("(//div[text()='Address']/following-sibling::div)[" + i + "]")).getText()
						+ " in contact details", Status.PASS);
			} else {
				logger("Verification: address_Value is not present in contact details", Status.FAIL);
			}
			Boolean email = driver.findElement(By.xpath("(//div[text()='E-mail'])[" + i + "]")).isDisplayed();
			if (email == Boolean.TRUE) {
				logger("Verification: email is present in contact details", Status.PASS);
			} else {
				logger("Verification: email is not present in contact details", Status.FAIL);
			}
			Boolean email_Value = driver
					.findElement(By.xpath("(//div[text()='E-mail']/following-sibling::div)[" + i + "]")).isDisplayed();
			if (email_Value == Boolean.TRUE) {
				logger("Verification: email_Value is present as " + driver
						.findElement(By.xpath("(//div[text()='E-mail']/following-sibling::div)[" + i + "]")).getText()
						+ " in contact details", Status.PASS);
			} else {
				logger("Verification: email_Value is not present in contact details", Status.FAIL);
			}
			Boolean company_Reg_No = driver.findElement(By.xpath("(//div[text()='Company Reg. No.'])[" + i + "]"))
					.isDisplayed();
			if (company_Reg_No == Boolean.TRUE) {
				logger("Verification: company_Reg_No is present in contact details", Status.PASS);
			} else {
				logger("Verification: company_Reg_No is not present in contact details", Status.FAIL);
			}
			Boolean company_Reg_No_Value = driver
					.findElement(By.xpath("(//div[text()='Company Reg. No.']/following-sibling::div)[" + i + "]"))
					.isDisplayed();
			if (company_Reg_No_Value == Boolean.TRUE) {
				logger("Verification: company_Reg_No_Value is present as " + driver
						.findElement(By.xpath("(//div[text()='Company Reg. No.']/following-sibling::div)[" + i + "]"))
						.getText() + " in contact details", Status.PASS);
			} else {
				logger("Verification: company_Reg_No_Value is not present in contact details", Status.FAIL);
			}
			Boolean company_Reg_No_VAST_GST = driver
					.findElement(By.xpath("(//div[text()='Company Reg. No. (VAT/GST)'])[" + i + "]")).isDisplayed();
			if (company_Reg_No_VAST_GST == Boolean.TRUE) {
				logger("Verification: company_Reg_No_VAST_GST is present in contact details", Status.PASS);
			} else {
				logger("Verification: company_Reg_No_VAST_GST is not present in contact details", Status.FAIL);
			}
			Boolean company_Reg_No_VAST_GST_Value = driver
					.findElement(
							By.xpath("(//div[text()='Company Reg. No. (VAT/GST)']/following-sibling::div)[" + i + "]"))
					.isDisplayed();
			if (company_Reg_No_VAST_GST_Value == Boolean.TRUE) {
				logger("Verification: company_Reg_No_VAST_GST_Value is present as " + driver
						.findElement(By.xpath(
								"(//div[text()='Company Reg. No. (VAT/GST)']/following-sibling::div)[" + i + "]"))
						.getText() + " in contact details", Status.PASS);
			} else {
				logger("Verification: company_Reg_No_VAST_GST_Value is not present in contact details", Status.FAIL);
			}

		}
		return this;
	}
	
	public Footer_Page Verify_Page_Is_Scrollable(){
		Verify_WebPage_Is_Scrollable(FooterPageConstants.contact_GeneralInfoPage);
		return this;
	}
}

