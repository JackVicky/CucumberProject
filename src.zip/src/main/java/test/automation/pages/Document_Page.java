package test.automation.pages;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.PageFactory;

import com.aventstack.extentreports.Status;
//import com.gargoylesoftware.htmlunit.WebConsole.Logger;

import test.automation.globalfunctionality.TestCaseInitiator;
import test.automation.pagelocators.DocumentsPageconstants;
import test.automation.pagelocators.HomePageconstants;
import test.automation.pagelocators.NewsPageconstants;

public class Document_Page extends TestCaseInitiator {

	public Document_Page() {
		PageFactory.initElements(driver, DocumentsPageconstants.class);
	}


	public  Document_Page Click_Documents_Manual() {
		clickWebElement(DocumentsPageconstants.Manual_guides_link);
		return new Document_Page();
	}


	public  Document_Page Verify_Page_heading() throws InterruptedException {
		if(verifyElementDisplayed(DocumentsPageconstants.Page_heading))
		{
			logger("Verification: Page title is displayed in H1 format in top of the page", Status.PASS);
		}

		else
		{
			logger("Verification: Page title is not displayed in H1 format in top of the page", Status.FAIL);
		}
		return this;

	}


	public  Document_Page Verify_Filter_Section() throws InterruptedException {
		if(DocumentsPageconstants.filter_section.isDisplayed())
		{
			logger("Verification: Filter section is displayed", Status.PASS);
		}
		else
		{
			logger("Verification: Filter section is not displayed", Status.FAIL);
		}
		return this;
	}

	public  Document_Page Verify_Item_Count() throws InterruptedException {
		Thread.sleep(2000);
		String text = DocumentsPageconstants.numberofresult.getText();
		//String substring = text.substring(text.indexOf(':'), text.lastIndexOf(text)-1);
		logger("Information:  "+text , Status.INFO);
		return this;
	}

	public Document_Page Verify_PlaceHolder_search() throws InterruptedException {

		if(DocumentsPageconstants.Search_results.isDisplayed())

		{
			logger("Verification: Placeholder search box is available next to number of result " , Status.PASS);

		}

		else {

			logger("Verification: Placeholder search box is not available next to number of result " , Status.FAIL);
		}

		return this;
	}


	public Document_Page EnterText_PlaceHolder_search(String Text) throws InterruptedException {
		VerifyElementIsClickable(DocumentsPageconstants.Search_results);
		enterText(DocumentsPageconstants.Search_results, Text);
		DocumentsPageconstants.Search_results.sendKeys(Keys.ENTER);
		return this;
	}

	public Document_Page Verify_UpdatedURL(String Text) throws InterruptedException {

		if(driver.getCurrentUrl().contains(Text))
		{
			logger("Verification: URL is updated with search result term: " +Text, Status.PASS);
		}
		else {
			logger("Verification: URL is not updated with search result term: " +Text, Status.FAIL);
		}

		return this;
	}

	public Document_Page Verify_UpdatedURL_withoutsearchterm(String Text) throws InterruptedException {

		if(driver.getCurrentUrl().contains(Text))
		{
			logger("Verification: URL is updated with search result term: " +Text, Status.FAIL);
		}
		else {
			logger("Verification: URL is not updated with search result term: " +Text, Status.PASS);
		}

		return this;
	}

	public SearchResult_Page Enter_Zero_resulterm(String Text) throws InterruptedException {
		enterText(DocumentsPageconstants.Search_results, Text);
		DocumentsPageconstants.Search_results.sendKeys(Keys.ENTER);

		return new SearchResult_Page();
	}


	public Document_Page Verify_closebutton_insearchfield() throws InterruptedException {

		if(DocumentsPageconstants.Search_close.isDisplayed())
		{
			logger("Verification: close button is available in search field", Status.PASS);
		}
		else {
			logger("Verification: close button is not available in search field" , Status.FAIL);
		}

		return this;
	}

	public Document_Page Click_closebutton_insearchfield() throws InterruptedException {
		VerifyElementIsClickable(DocumentsPageconstants.Search_close);
		clickWebElement(DocumentsPageconstants.Search_close);
		return this;
	}
	public Document_Page Verify_text_inSearchfield(String text) throws InterruptedException {

		dynamicElementDisplayed("//input[@placeholder='Search in results']", text);

		return this;
	}

	public Document_Page Verify_disabled_filters() throws InterruptedException {

		WebElement Businessunit_filter = driver.findElement(By.xpath("(//div[contains(@class,'search-dropdown dropdown-single-value--is-disabled')]//descendant::div[contains(@class,'placeholder')])[1]"));
		String text = Businessunit_filter.getText();
		if(Businessunit_filter.isDisplayed())
		{
			logger("Verification: Filter "+text+ " is disabled", Status.PASS);
		}
		WebElement Allcountries_filter = driver.findElement(By.xpath("(//div[contains(@class,'search-dropdown dropdown-single-value--is-disabled')]//descendant::div[contains(@class,'placeholder')])[2]"));
		String text1 = Allcountries_filter.getText();
		if(Allcountries_filter.isDisplayed())
		{
			logger("Verification: Filter "+text1+ " is disabled", Status.PASS);
		}
		
		WebElement Documenttype_filter = driver.findElement(By.xpath("(//div[contains(@class,'dropdown-multi-values--is-disabled')]//div[contains(@class,'dropdown-multi-values__placeholder')])[1]"));
		String text2 = Documenttype_filter.getText();
		if(Documenttype_filter.isDisplayed())
		{
			logger("Verification: Filter "+text2+ " is disabled", Status.PASS);
		}
		WebElement Languages_filter = driver.findElement(By.xpath("(//div[contains(@class,'dropdown-multi-values--is-disabled')]//div[contains(@class,'dropdown-multi-values__placeholder')])[2]"));
		String text3 = Languages_filter.getText();
		if(Languages_filter.isDisplayed())
		{
			logger("Verification: Filter "+text3+ " is disabled", Status.PASS);
		}
		
		return this;
	}

	public Document_Page Verify_NoAutosuggestion() {

		List<WebElement> suggestions = driver.findElements(By.xpath("//div[contains(@class,'search-select__menu')]"));
		if(suggestions.size()==0)
		{
			logger("Verfication: No AutoSuggestion are displayed for Searchbox", Status.PASS);
		}
		return this; 

	}


	public Document_Page Verify_Result_list() throws InterruptedException {
		VerifyElementIsClickable(DocumentsPageconstants.List_of_result);
		if(DocumentsPageconstants.List_of_result.isDisplayed())

		{
			logger("Verification: Result list is displayed" , Status.PASS);
		}

		else {
			logger("Verification: Result list is not displayed " , Status.FAIL);
		}

		return this;
	}

	public  Document_Page Verify_clear_filter() throws InterruptedException {
		verifyElementDisplayed(DocumentsPageconstants.clear_filter);
		return this;
	}



	public  Document_Page Click_Clear_filter() throws InterruptedException {
		clickWebElement(DocumentsPageconstants.clear_filter);
		return this;
	}


	public  Document_Page Verify_Pagination() throws InterruptedException {
		if(DocumentsPageconstants.pagination.isDisplayed())
		{
			logger("Verification: Pagination are displayed", Status.PASS);
		}

		else {
			logger("Verification: Pagination are not displayed", Status.FAIL);
		}
		return this;
	}

	public  Document_Page verify_Pagetitle() throws InterruptedException {
		verifyPageTitle("Document search results");
		return this;
	}

	public  Home_Page Navigate_homepage() {
		clickWebElement(HomePageconstants.titleImage);
		return new Home_Page();
	}

	public  Document_Page Verify_Business_Filter() {
		verifyElementDisplayed(DocumentsPageconstants.Business_filter);

		return this;
	}

	public  Document_Page Verify_DocumentType_Filter() {
		verifyElementDisplayed(DocumentsPageconstants.Document_type_filter);
		return this;
	}

	public  Document_Page Verify_Language_Filter() {
		verifyElementDisplayed(DocumentsPageconstants.Language_filter);
		DocumentsPageconstants.Language_filter.click();
		if(verifyElementDisplayed(DocumentsPageconstants.Language_selected_filter))
		{
			logger("Verification: Language filter is selected by default as: "+DocumentsPageconstants.Language_selected_filter, Status.PASS);
		}
		DocumentsPageconstants.Language_filter.click();
		return this;
	}


	public  Document_Page Verify_Product_heirarchy() {
		DocumentsPageconstants.Business_filter.click();
		driver.findElement(By.xpath("//div[text()='Drives']")).click();
		verifyElementDisplayed(DocumentsPageconstants.product_group);
		verifyElementDisplayed(DocumentsPageconstants.product_series);

		return this;
	}

	public  Document_Page Verify_Filtersection_tworows() {

		if(DocumentsPageconstants.Second_row_filter_section.isDisplayed())
		{
			logger("Verification: Filter section is expanded to second row", Status.PASS);
		}
		else
		{
			logger("Verification: Filter section is not expanded to second row", Status.FAIL);
		}

		return this;
	}


	public  Document_Page Verify_Countries_Filter() {
		verifyElementDisplayed(DocumentsPageconstants.countries_filter);
		return this;
	}

	public  Document_Page Verify_Status_Filter() {
		verifyElementDisplayed(DocumentsPageconstants.Status_filter);
		DocumentsPageconstants.Status_filter.click();
		if(verifyElementDisplayed(DocumentsPageconstants.Status_selected_filter))
		{
			logger("Verification: Language filter is selected by default as: "+DocumentsPageconstants.Language_selected_filter, Status.PASS);
		}
		DocumentsPageconstants.Status_filter.click();
		return this;
	}


	public  Document_Page Click_Business_filter(String str) throws InterruptedException {
		dynamicElementselector("(//div[@class='filters-group__items-wrapper'])[3]//descendant::span[@class='filters-group__item__title']", str);
		return this;
	}

	public  Document_Page Verify_Business_filtervalue(String str) throws InterruptedException {
		dynamicElementDisplayed("(//div[@class='filters-group__items-wrapper'])[3]//descendant::span[@class='filters-group__item__title']", str);

		return this;
	}

	public  Document_Page Click_Market_filter(String str) throws InterruptedException {

		dynamicElementselector("(//div[@class='filters-group__items-wrapper'])[2]//descendant::span[@class='filters-group__item__title']", str);
		return this;
	}

	public  Document_Page Click_News_Categories_filter() throws InterruptedException {
		NewsPageconstants.News_filter.click();
		Thread.sleep(2000);
		return this;
	}


	public  Document_Page Click_News_Categories_filter(String str) throws InterruptedException {
		dynamicElementselector("(//div[@class='filters-group__items-wrapper'])[1]//descendant::span[@class='filters-group__item__title']", str);
		return this;
	}

	public  Document_Page Verify_Url(String str1) throws InterruptedException {
		Thread.sleep(1000);
		if(driver.getCurrentUrl().contains(str1))
		{
			logger("Verification: Selected Filter is updated in the URL" , Status.PASS);
		}
		else
		{
			logger("Verification: URL does not contain filters" , Status.FAIL);
		}
		return this;
	}

	public  Document_Page Verify_Url_NoFilter(String str1) throws InterruptedException {
		Thread.sleep(1000);
		if(!driver.getCurrentUrl().contains(str1))
		{
			logger("Verification: Filter are not available in updated URL" , Status.PASS);
		}
		else
		{
			logger("Verification: Filter are  available in updated URL" , Status.FAIL);
		}
		return this;
	}


	public  Document_Page Verify_No_clear_filter() throws InterruptedException {
		verifyElementNotDisplayed("//button[contains(@class,'reset-filter-button')]//descendant::span[@class='cta-content-text']");
		return this;
	}



	public  Document_Page Verify_Breadcrumbs() throws InterruptedException {
		if(NewsPageconstants.breadcrumbs1.isDisplayed() && NewsPageconstants.breadcrumbs2.isDisplayed())
		{
			logger("Verification: Breadcrumnb is displayed", Status.PASS);
		}
		else
		{
			logger("Verification: Breadcrumnb is not displayed", Status.FAIL);
		}
		return this;
	}



	public  Document_Page Verify_NewsCategories_filter() throws InterruptedException {
		verifyElementDisplayed(NewsPageconstants.News_filter);
		if(NewsPageconstants.News_filters_collapsed.isDisplayed())
		{
			logger("Verification: News Categories  filter is collapsed by default and Arrow is pointed down", Status.PASS);
		}
		else
		{
			logger("Verification: News Categories filter is not collapsed ", Status.FAIL);
		}
		return this;
	}

	public  Document_Page Verify_Market_filter() throws InterruptedException {
		verifyElementDisplayed(NewsPageconstants.Market_filter);
		if(NewsPageconstants.Market_filters_collapsed.isDisplayed())
		{
			logger("Verification: Market filter is collapsed by default and Arrow is pointed down", Status.PASS);
		}
		else
		{
			logger("Verification: Market filter is not collapsed ", Status.FAIL);
		}
		return this;
	}


	public  Document_Page Click_Market_filter() throws InterruptedException {
		driver.findElement(By.xpath("(//div[@class='filters-group__heading'])[2]//child::span")).click();
		Thread.sleep(2000);
		return this;
	}

	public  Document_Page Verify_Solutions_filter() throws InterruptedException {
		verifyElementDisplayed(NewsPageconstants.Solutions_filter);
		if(NewsPageconstants.Solutions_filters_collapsed.isDisplayed())
		{
			logger("Verification: Solutions filter is collapsed by default and Arrow is pointed down", Status.PASS);
		}
		else
		{
			logger("Verification: Solutions filter is not collapsed ", Status.FAIL);
		}
		return this;
	}

	public  Document_Page Verify_Applications_filter() throws InterruptedException {
		verifyElementDisplayed(NewsPageconstants.Application_filter);
		if(NewsPageconstants.Application_filters_collapsed.isDisplayed())
		{
			logger("Verification: Applications filter is collapsed by default and Arrow is pointed down", Status.PASS);
		}
		else
		{
			logger("Verification: Applications filter is not collapsed ", Status.FAIL);
		}
		return this;
	}



	public  Document_Page Verify_Alphaticalorder_Filteroptions() throws InterruptedException {
		logger("Below steps will check filter values in each filters are arranged in alphabatical order", Status.INFO);
		Verify_Alphabatic_Order("(//div[@class='filters-group__items-wrapper'])[1]//descendant::span[@class='filters-group__item__title']");
		Verify_Alphabatic_Order("(//div[@class='filters-group__items-wrapper'])[2]//descendant::span[@class='filters-group__item__title']");
		Verify_Alphabatic_Order("(//div[@class='filters-group__items-wrapper'])[3]//descendant::span[@class='filters-group__item__title']");
		Verify_Alphabatic_Order("(//div[@class='filters-group__items-wrapper'])[4]//descendant::span[@class='filters-group__item__title']");
		Verify_Alphabatic_Order("(//div[@class='filters-group__items-wrapper'])[5]//descendant::span[@class='filters-group__item__title']");
		return this;

	}

	public  Document_Page Verify_FilterisSelected(String str) throws InterruptedException {
		if(dynamicElementDisplayed("//span[contains(@class,'checked-true')]//following-sibling::span[@class='filters-group__item__title']", str));
		{
			logger("Verification: "+str+ " is selected", Status.PASS);

		}
		return this;
	}


	public  Document_Page Verify_Highlighted_filterValues() throws InterruptedException {
		WebElement ele = driver.findElement(By.xpath("((//div[@class='filters-group__items-wrapper'])[3]//descendant::span[@class='filters-group__item__title'])[1]"));
		VerifyElementIsHighlighted(ele);
		return this;
	}

	public  Document_Page Verify_SelectedFilter_In_Applied(String str) throws InterruptedException {

		String text = driver.findElement(By.xpath("(//div[@class='unselect-buttons-group']//descendant::span[@class='cta__content-text'])[1]")).getText();
		if(text.contains(str))

		{
			logger("Verification: "+str+ " is added in the applied filter section", Status.PASS);

			if(NewsPageconstants.Applied_filter_close.isDisplayed())
			{
				logger("Verification: "+str+ " contains close button", Status.PASS);

			}
			else {

				logger("Verification: "+str+ " not contains close button", Status.FAIL);
			}
		}
		else {

			logger("Verification: "+str+ "is not added in the applied filter section", Status.FAIL);

		}

		return this;
	}


	public  Document_Page Verify_Highlighted_AppliedFilter() throws InterruptedException {
		WebElement ele = driver.findElement(By.xpath("(//div[@class='unselect-buttons-group']//descendant::span[@class='cta__content-text'])[1]"));
		VerifyElementIsHighlighted(ele);
		return this;
	}


	public  Document_Page Deselect_Filters() throws InterruptedException {
		try {
			List<WebElement> findElementsByXPath = driver.findElements(By.xpath("//div[@class='unselect-buttons-group']//descendant::span[@class='icon icon-cancel']"));
			for (int i = 0; i < findElementsByXPath.size(); i++) {
				findElementsByXPath.get(i).click();
			}
			Thread.sleep(2000);
			loggerWithScreenshot("Verification: Filters are removed in applied filter and also it filter section", "", Status.PASS, true);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		return this;
	}

	public  Document_Page Verify_SortButton_withoptions() throws InterruptedException {
		verifyElementDisplayed(NewsPageconstants.sort_button);
		Thread.sleep(2000);
		driver.findElement(By.xpath("//select[@class='sort-select cta cta--small cta--block']")).click();
		verifyElementDisplayed(NewsPageconstants.sort_startdate_desc);
		if(NewsPageconstants.sort_startdate_desc.isDisplayed())
		{
			loggerWithScreenshot("Verification: The element Date (old first) is displayed and it is Default value", "", Status.PASS, true);
		}
		verifyElementDisplayed(NewsPageconstants.sort_title_asc);
		verifyElementDisplayed(NewsPageconstants.sort_title_desc);
		return this;
	}

	public  Document_Page Verify_items_AscendingOrder()

	{
		clickWebElement(NewsPageconstants.sort_title_asc);
		Verify_Alphabatic_Order("//div[@class='tile__text-title']");
		return this;

	}


	public  Document_Page Verify_Result_Tile() throws InterruptedException {
		if(NewsPageconstants.Item_Tile.isDisplayed())
		{
			logger("Verification: Tites are displayed", Status.PASS);
		}

		else {
			logger("Verification: Tiles are not displayed", Status.FAIL);
		}
		return this;
	}

	public  Document_Page Verify_Result_Tile_Content() throws InterruptedException {
		if(NewsPageconstants.Tile_title.isDisplayed())
		{
			logger("Verification: Tile Title is displayed", Status.PASS);

			if(NewsPageconstants.Tile_image.isDisplayed())
			{ 
				logger("Verification: Tile image is displayed", Status.PASS);


				if(NewsPageconstants.Tile_description.isDisplayed())
				{ 
					logger("Verification: Tile description is displayed", Status.PASS);


					if(NewsPageconstants.Tile_date.isDisplayed())
					{ 
						logger("Verification: Tile date is displayed", Status.PASS);

					}
				}
			}
		}

		else 
		{
			loggerWithScreenshot("Verification: Issue with tiles", "", Status.FAIL, true);
		}

		return this;
	}
	
	public  Document_Page Wait() throws InterruptedException {
		Thread.sleep(5000);
		return this;

	}


}
