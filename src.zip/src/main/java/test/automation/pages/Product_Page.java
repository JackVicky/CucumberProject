package test.automation.pages;

import org.openqa.selenium.support.PageFactory;

import test.automation.globalfunctionality.TestCaseInitiator;
import test.automation.pagelocators.ProductPageconstants;

public class Product_Page extends TestCaseInitiator {

	public Product_Page() {
		PageFactory.initElements(driver, ProductPageconstants.class);
	}

	
	
	
	
	
	
	
	
	
	
	//old product section
	public Product_Page verifyAcdrive() {
		verifyElementDisplayed(ProductPageconstants.AC_drives);
		return this;

	}

	public Product_Page verifyApplianceControls() {
		verifyElementDisplayed(ProductPageconstants.Appliance_controls);
		return this;
	}

	public Product_Page verifyBurnercomponents() {
		verifyElementDisplayed(ProductPageconstants.Burner_components);
		return this;
	}

	public Product_Page verifyCompressors() {
		verifyElementDisplayed(ProductPageconstants.Compressors);
		return this;
	}

	public Product_Page verifyCondensing_unit() {
		verifyElementDisplayed(ProductPageconstants.Condensing_unit);
		return this;
	}

	public Product_Page verifyElectronic() {
		verifyElementDisplayed(ProductPageconstants.Electronic_controls);
		//VerfiyTwoString(ProductPageconstants.Electronic_controls.getText(), "Electronic_controls");
		//String cssValue = ProductPageconstants.Electronic_controls.getCssValue("colour");
		//System.out.println(cssValue);
		return this;
	}

	public Product_Page verifyDifferentialpressurefc() {
		verifyElementDisplayed(ProductPageconstants.Differential_pressure_fc);
		return this;
	}

	public Product_Page verifyhighlightofAcdrives() throws InterruptedException {
		VerifyElementIsHighlighted(ProductPageconstants.AC_drives);
		return this;
	}

	public Product_Page verify_Close_Button() {
		verifyElementDisplayed(ProductPageconstants.Close_button);
		return this;
	}
	public Product_Page ClickcloseButton() {
		clickWebElement(ProductPageconstants.Close_button);
		return this;

	}


}
