package test.automation.pages;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.Dimension;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;
import static org.openqa.selenium.support.locators.RelativeLocator.with;

import com.aventstack.extentreports.Status;

import test.automation.pages.All_Products_Page;
import test.automation.functions.UserActions;
import test.automation.globalfunctionality.TestCaseInitiator;
import test.automation.pagelocators.HomePageconstants;
import test.automation.pagelocators.ProductPageconstants;

public class Product_Menu_Page extends TestCaseInitiator {

	public Product_Menu_Page() {
		PageFactory.initElements(driver, ProductPageconstants.class);
	}

	public Product_Menu_Page verifyAcdrive() {
		verifyElementDisplayed(ProductPageconstants.DDS_Ac_drives);
		return this;
	}

	public Product_Menu_Page verify_lowvoltage() {
		verifyElementDisplayed(ProductPageconstants.DDS_Low_voltage_drive);
		return this;
	}

	public Product_Menu_Page verifyApplianceControls() {
		verifyElementDisplayed(ProductPageconstants.Appliance_controls);
		return this;
	}

	public Product_Menu_Page verifyBurnercomponents() {
		verifyElementDisplayed(ProductPageconstants.Burner_components);
		return this;
	}

	public Product_Menu_Page verifyCompressors() {
		verifyElementDisplayed(ProductPageconstants.Compressors);
		return this;
	}

	public Product_Menu_Page verifyCondensing_unit() {
		verifyElementDisplayed(ProductPageconstants.Condensing_unit);
		return this;
	}

	public Product_Menu_Page verifyDifferential_pressure_fc() {
		verifyElementDisplayed(ProductPageconstants.Differential_pressure_fc);
		return this;
	}

	public Product_Menu_Page verifyElectronic() {
		verifyElementDisplayed(ProductPageconstants.Electronic_controls);
		return this;
	}

	public Product_Menu_Page verifyEmission_monitoring() {
		verifyElementDisplayed(ProductPageconstants.Emission_monitoring);
		return this;
	}

	public Product_Menu_Page verifyEnergy_metering() {
		verifyElementDisplayed(ProductPageconstants.Energy_metering);
		return this;
	}

	public Product_Menu_Page verifyEnergy_recovery_devices() {
		verifyElementDisplayed(ProductPageconstants.Energy_recovery_devices);
		return this;
	}

	public Product_Menu_Page verifyFilter_driers_strainers() {
		verifyElementDisplayed(ProductPageconstants.Filter_driers_strainers);
		return this;
	}

	public Product_Menu_Page verifyFire_safety() {
		verifyElementDisplayed(ProductPageconstants.Fire_safety);
		return this;
	}

	public Product_Menu_Page verifyFloor_heating_ice() {
		verifyElementDisplayed(ProductPageconstants.Floor_heating_ice);
		return this;
	}

	public Product_Menu_Page verifyHeat_exchangers() {
		verifyElementDisplayed(ProductPageconstants.Heat_exchangers);
		return this;
	}

	public Product_Menu_Page verifyMobile_electrification() {
		verifyElementDisplayed(ProductPageconstants.Mobile_electrification);
		return this;
	}

	public Product_Menu_Page verifyMotors() {
		verifyElementDisplayed(ProductPageconstants.Motors);
		return this;
	}

	public Product_Menu_Page verifyPower_modules() {
		verifyElementDisplayed(ProductPageconstants.Power_modules);
		return this;
	}

	public Product_Menu_Page verifyPower_stacks() {
		verifyElementDisplayed(ProductPageconstants.Power_stacks);
		return this;
	}

	public Product_Menu_Page verifyPumps() {
		verifyElementDisplayed(ProductPageconstants.Pumps);
		return this;
	}

	public Product_Menu_Page verifyRadiator_room_thermostats() {
		verifyElementDisplayed(ProductPageconstants.Radiator_room_thermostats);
		return this;
	}

	public Product_Menu_Page verifySensors_transmitters() {
		verifyElementDisplayed(ProductPageconstants.Sensors_transmitters);
		return this;
	}

	public Product_Menu_Page verifySight_glasses() {
		verifyElementDisplayed(ProductPageconstants.Sight_glasses);
		return this;
	}

	public Product_Menu_Page verifySmart_heating() {
		verifyElementDisplayed(ProductPageconstants.Smart_heating);
		return this;
	}

	public Product_Menu_Page verifySoft_starters() {
		verifyElementDisplayed(ProductPageconstants.Soft_starters);
		return this;
	}

	public Product_Menu_Page verifySoftware() {
		verifyElementDisplayed(ProductPageconstants.Software);
		return this;
	}

	public Product_Menu_Page verifyStations_domestic_hw() {
		verifyElementDisplayed(ProductPageconstants.Stations_domestic_hw);
		return this;
	}

	public Product_Menu_Page verifySteering() {
		verifyElementDisplayed(ProductPageconstants.Steering);
		return this;
	}

	public Product_Menu_Page verifySwitches() {
		verifyElementDisplayed(ProductPageconstants.Switches);
		return this;
	}

	public Product_Menu_Page verifyValves() {
		verifyElementDisplayed(ProductPageconstants.Valves);
		return this;
	}

	public Product_Menu_Page verify_Close_Button() {

		if (ProductPageconstants.Close_button.isDisplayed()) {
			logger("Verification: Close button is displayed", Status.PASS);
		}
		return this;
	}

	public Home_Page Click_CloseButton() {
		ProductPageconstants.Close_button.click();
		logger("Close button is clicked", Status.PASS);
		return new Home_Page();
	}

	public Product_Menu_Page verify_View_all_products() {
		verifyElementDisplayed(ProductPageconstants.View_all_products);
		return this;
	}

	public Product_Menu_Page MouseHover_ACDrives() {
		MoveToElement(ProductPageconstants.AC_drives);
		return this;
	}

	public Product_List_Page Click_ACDrives() throws InterruptedException {
		// AC drives option is depreciated

		/*
		 * clickWebElement(ProductPageconstants.DDS_Ac_drives); Thread.sleep(1000);
		 */
		return new Product_List_Page();
	}

	public Product_List_Page Click_LowVoltageDrives() throws InterruptedException {
		clickWebElement(ProductPageconstants.LowVoltage_drives);
		Thread.sleep(1000);
		return new Product_List_Page();
	}

	public Product_Category_Page Click_Lowvoltage_drive() throws InterruptedException {
		clickWebElement(ProductPageconstants.DDS_Low_voltage_drive);
		Thread.sleep(1000);
		return new Product_Category_Page();
	}

	public OLD_Product_Category_List_Page Click_View_all_products() throws InterruptedException {
		clickWebElement(ProductPageconstants.View_all_products);
		Thread.sleep(1000);
		return new OLD_Product_Category_List_Page();
	}

	public Product_Menu_Page ClickcloseButton() {
		clickWebElement(ProductPageconstants.Close_button);
		return this;

	}

	public Product_Menu_Page Verify_Alphabatic_Order() {
		List<WebElement> listOfElement = ListOfElement("xpath",
				"//a[starts-with(@href,'/en/products/')]//descendant::span[@class='item-caption']");
		List<String> list1 = new ArrayList<>();
		List<String> list2 = new ArrayList<>();
		for (WebElement webElement : listOfElement) {
			String text = webElement.getText();
			list1.add(text);
			list2.add(text);
		}

		Collections.sort(list1);
		if (list1.equals(list2)) {
			logger("Categories are sorted in alphabetical order", Status.PASS);

		} else {
			logger("Categories are Not sorted in alphabetic order", Status.FAIL);
		}
		return this;
	}

	public Home_Page Navigate_homepage() {
		clickWebElement(HomePageconstants.titleImage);
		return new Home_Page();
	}

	public Product_Menu_Page verifyAutogeneratedSegment() {
		verifyElementDisplayed(ProductPageconstants.Power_solutions_segment);
		verifyElementDisplayed(ProductPageconstants.Cooling_segment);
		verifyElementDisplayed(ProductPageconstants.Heating_segment);
		verifyElementDisplayed(ProductPageconstants.Drives_segment);
		return this;
	}

	public Product_Menu_Page verifystaticsection() {
		verifyElementDisplayed(ProductPageconstants.Static_segment);
		verifyElementDisplayed(ProductPageconstants.All_Danfoss_products);
		verifyElementDisplayed(ProductPageconstants.Howto_buy_Danfoss_Products);
		verifyElementDisplayed(ProductPageconstants.Danfoss_product_store);
		verifyElementDisplayed(ProductPageconstants.Danfoss_Documentation);
		return this;
	}

	public Product_Menu_Page verifySegments() {
		if (ProductPageconstants.Segment_columns_list.isDisplayed()) {
			logger("Verification: Segment list contains 4 columns", Status.PASS);
		} else {
			logger("Verification: issue with Segment columns", Status.FAIL);
		}

		if (ProductPageconstants.Segment_columns_header.isDisplayed()) {
			logger("Verification: Segment columns contains header", Status.PASS);
			try {
				new WebDriverWait(driver, 10)
						.until(ExpectedConditions.elementToBeClickable(ProductPageconstants.Segment_columns_header));
				logger("Verification: Segment column headers are clickable", Status.PASS);
			} catch (Exception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}

		else {
			logger("Verification: issue with Segment columns header", Status.FAIL);
		}

		if (ProductPageconstants.Segment_category_list.isDisplayed()) {
			logger("Verification: Segment columns contains categories list", Status.PASS);
		} else {
			logger("Verification: issue with Segment columns categories list", Status.FAIL);
		}
		return this;

	}

	public Product_Menu_Page verifymax11categories() {

		List<WebElement> categories = driver
				.findElements(By.xpath("(//ul[contains(@class,'truncatedProductsListItems')])[2]//descendant::a"));
		int size = categories.size();
		if (size == 11) {
			logger("Verification: Number of Categories in segment is 11", Status.PASS);
			verifyElementDisplayed(ProductPageconstants.more_products);

		}

		if (size != 11) {
			logger("Verification: Number of Categories in segment is not 11", Status.FAIL);

		}
		return this;
	}

	public Product_Menu_Page Verify_Other_business() {

		if (verifyElementDisplayed(ProductPageconstants.Other_businesses_segment)) {
			logger("Verification: other business section is part of last column", Status.PASS);
		} else {
			logger("Verification: issue with other business section", Status.FAIL);
		}

		// VerifyElementIsNotClickable(ProductPageconstants.Other_businesses_segment);
		// Vignesh -> Other business segment is clickable but there is no click event
		// present
		return this;
	}

	public Product_Menu_Page Verify_highlighteditems() throws InterruptedException {

		VerifyElementIsHighlighted(ProductPageconstants.Power_solutions_segment);
		VerifyElementIsHighlighted(ProductPageconstants.Cooling_segment);
		VerifyElementIsHighlighted(ProductPageconstants.Heating_segment);
		VerifyElementIsHighlighted(ProductPageconstants.Drives_segment);
		// more elements
		VerifyElementsIsHighlighted("//span[text()='+ more products']");
		// each category in product page
		VerifyElementsIsHighlighted("//li[contains(@class,'products-list-item')]//span");
		return this;
	}

	public Product_Menu_Page Click_Power_Solution_Segment() throws InterruptedException {
		clickWebElement(ProductPageconstants.Power_solutions_segment);
		verifyPageTitle("Power Solutions | Danfoss");
		Navigate_homepage();
		clickWebElement(HomePageconstants.Products_menu);
		return this;
	}
	
	public Product_Menu_Page Click_Power_Solution_Segment_Product_Page() throws InterruptedException {
		VerifyElementIsClickable(ProductPageconstants.Power_solutions_segment);
		clickWebElement(ProductPageconstants.Power_solutions_segment);
		verifyPageTitle("Power Solutions | Danfoss");
		return this;
	}
	
	public Product_Menu_Page Verify_Newsletter_CTA_Button_Is_Present() throws InterruptedException{
		Thread.sleep(3000);
		verifyElementDisplayed(ProductPageconstants.keepMeUpdated);
		return this;
	}
	
	public Product_Menu_Page Click_KeepMeUpdated_CTA_Button(){
		clickWebElement(ProductPageconstants.keepMeUpdated);
		return this;
	}
	
	public Product_Menu_Page Verify_Sign_Me_Up_Form_Is_Open() throws InterruptedException{
		Thread.sleep(3000);
		verifyElementDisplayed(ProductPageconstants.signMeUp_Form);
		return this;
	}
	
	public Product_Menu_Page Verify_reCaptcha_Logo_Is_Displayed() throws InterruptedException {
		WebDriverWait wait = new WebDriverWait(driver, 13000);
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//iframe[@title='reCAPTCHA']")));
		switchToFrame(ProductPageconstants.captcha_Iframe);
		Thread.sleep(5000);
		verifyElementDisplayed(ProductPageconstants.signMeUp_Form_Captcha);
		switchToParentFrame();
		return this;
	}
	
	public Product_Menu_Page Verify_Newsletter_Signup_Form_Title_Is_Displayed(){
		verifyElementDisplayed(ProductPageconstants.signMeUp_Form_Title);
		return this;
	}
	
	public Product_Menu_Page Verify_Representing_A_Business_Option_In_SignUp_Form(){
		verifyElementDisplayed(ProductPageconstants.Representing_a_business);
		return this;
	}
	
	public Product_Menu_Page Verify_Private_Person_Option_In_SignUp_Form(){
		verifyElementDisplayed(ProductPageconstants.Private_Person);
		return this;
	}
	
	public Product_Menu_Page Select_Representing_A_Business_Option(){
		clickWebElement(ProductPageconstants.Representing_a_business);
		return this;
	}
	
	public Product_Menu_Page Verify_First_Name_Is_Displayed_In_Signup_Form(){
		verifyElementDisplayed(ProductPageconstants.first_Name);
		verifyElementDisplayed(ProductPageconstants.first_Name_Star);
		return this;
	}
	
	public Product_Menu_Page Verify_Last_Name_Is_Displayed_In_Signup_Form(){
		verifyElementDisplayed(ProductPageconstants.last_Name);
		verifyElementDisplayed(ProductPageconstants.last_Name_Star);
		return this;
	}
	
	public Product_Menu_Page Verify_Company_Name_Is_Displayed_In_Signup_Form(){
		verifyElementDisplayed(ProductPageconstants.Company);
		verifyElementDisplayed(ProductPageconstants.Company_Star);
		return this;
	}
	
	public Product_Menu_Page Verify_Company_Type_Dropdown_Is_Displayed_In_Signup_Form(){
		verifyElementDisplayed(ProductPageconstants.Company_Type);
		verifyElementDisplayed(ProductPageconstants.Company_Type_Star);
		verifyElementDisplayed(ProductPageconstants.Company_Type_Dropdown);
		return this;
	}
	
	public Product_Menu_Page Verify_Department_Dropdown_Is_Displayed(){
		verifyElementDisplayed(ProductPageconstants.Department_Name);
		verifyElementDisplayed(ProductPageconstants.Department_Dropdown_Star);
		verifyElementDisplayed(ProductPageconstants.Department_Type_Dropdown);
		return this;
	}
	
	public Product_Menu_Page Verify_Function_Dropdown_Is_Displayed() {
		verifyElementDisplayed(ProductPageconstants.Function_Name);
		verifyElementDisplayed(ProductPageconstants.Function_Dropdown_Star);
		verifyElementDisplayed(ProductPageconstants.Function_Type_Dropdown);
		return this;
	}
	
	public Product_Menu_Page Verify_Email_Name_Is_Displayed() {
		verifyElementDisplayed(ProductPageconstants.Email_Name);
		verifyElementDisplayed(ProductPageconstants.Email_Star);
		return this;
	}
	
	public Product_Menu_Page Verify_Country_Region_Name_Is_Displayed() {
		verifyElementDisplayed(ProductPageconstants.Country_region_Name);
		verifyElementDisplayed(ProductPageconstants.Country_region_Dropdown_Star);
		verifyElementDisplayed(ProductPageconstants.Country_region_Type_Dropdown);
		return this;
	}
	
	public Product_Menu_Page Verify_Please_read_our_ubscription_terms_and_privacy_policy_link_is_displayed() throws InterruptedException{
		verifyElementDisplayed(ProductPageconstants.Subscription_Terms_And_Condition);
		clickWebElement(ProductPageconstants.Subscription_Terms_And_Condition);
		switch_To_New_Window_And_Close_It();
		WebDriverWait wait = new WebDriverWait(driver, 5000);
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//a[@href='/en/terms/privacy/']")));
		verifyElementDisplayed(ProductPageconstants.Privacy_Policy);
		clickWebElement(ProductPageconstants.Privacy_Policy);
		switch_To_New_Window_And_Close_It();
		return this;
	}
	
	public  Product_Menu_Page Click_Close_Sign_Me_Up_Form() throws InterruptedException{
		Thread.sleep(2000);
		clickWebElement(ProductPageconstants.close_SignMeUp_Form);
		return this;
	}
	
	public Product_Menu_Page Click_Electric_Converters_And_Machines(){
		clickWebElement(ProductPageconstants.electric_converters_machines);
		return this;
	}
	
	public Product_Menu_Page Click_Electric_Converters() throws InterruptedException{
		Thread.sleep(2000);
		clickWebElement(ProductPageconstants.electric_converters);
		return this;
	}

	public Product_Menu_Page Click_Cooling_Segment() throws InterruptedException {
		clickWebElement(ProductPageconstants.Cooling_segment);
		verifyPageTitle("Climate Solutions for cooling | Danfoss");
		Navigate_homepage();
		clickWebElement(HomePageconstants.Products_menu);
		return this;
	}

	public Product_Menu_Page Click_Heating_Segment() throws InterruptedException {
		clickWebElement(ProductPageconstants.Heating_segment);
		verifyPageTitle("Climate Solutions for heating | Danfoss");
		Navigate_homepage();
		clickWebElement(HomePageconstants.Products_menu);
		return this;
	}

	public Product_Menu_Page Click_Drives_Segment() throws InterruptedException {
		clickWebElement(ProductPageconstants.Drives_segment);
		verifyPageTitle("Drives | Danfoss");
		Navigate_homepage();
		clickWebElement(HomePageconstants.Products_menu);
		return this;
	}

	public Product_Menu_Page Click_DPS_valves() throws InterruptedException {
		clickWebElement(ProductPageconstants.DPS_valves);
		verifyPageTitle("Valves and actuators - Check out the wide portfolio for mobile hydraulics | Danfoss");
		Navigate_homepage();
		clickWebElement(HomePageconstants.Products_menu);
		return this;
	}

	public Product_Menu_Page Click_DCS_valves() throws InterruptedException {
		clickWebElement(ProductPageconstants.DCS_valves);
		verifyPageTitle("Valves | Danfoss");// Valves - For heating, cooling and mobile hydraulics | Danfoss
		Navigate_homepage();
		clickWebElement(HomePageconstants.Products_menu);
		return this;
	}

	public Product_Menu_Page Click_DHS_Burner() throws InterruptedException {
		clickWebElement(ProductPageconstants.DHS_burner_component);
		verifyPageTitle("Burner components | Oil pumps, nozzles and filters | Danfoss");
		Navigate_homepage();
		clickWebElement(HomePageconstants.Products_menu);
		return this;
	}

	public Product_Menu_Page Click_DDS_Acdrives() throws InterruptedException {
		clickWebElement(ProductPageconstants.DDS_Ac_drives);
		verifyPageTitle("AC drives | Danfoss");
		Navigate_homepage();
		clickWebElement(HomePageconstants.Products_menu);
		return this;
	}

	public Product_Menu_Page Click_Static_Danfoss_products() throws InterruptedException {
		clickWebElement(ProductPageconstants.All_Danfoss_products);
		verifyPageTitle("Products | Danfoss");
		Navigate_homepage();
		clickWebElement(HomePageconstants.Products_menu);
		return this;
	}

	public Product_Menu_Page Click_Static_Howto_buy_danfoss_products() throws InterruptedException {
		clickWebElement(ProductPageconstants.Howto_buy_Danfoss_Products);
		verifyPageTitle("Experience the Danfoss Product Store | Danfoss");// About Danfoss - Engineering since 1933 -
																			// Explore innovative solutions for industry
																			// | Danfoss
		Navigate_homepage();
		clickWebElement(HomePageconstants.Products_menu);
		return this;
	}

	public Product_Menu_Page Click_Static_Documentation() throws InterruptedException {
		clickWebElement(ProductPageconstants.Danfoss_Documentation);
		verifyPageTitle("Danfoss documentation online - Product documentation, cases | Danfoss");
		Navigate_homepage();
		clickWebElement(HomePageconstants.Products_menu);
		return this;
	}

	public Product_Menu_Page Click_Static_Product_store() throws InterruptedException {
		clickWebElement(ProductPageconstants.Danfoss_product_store);
		switchToWindow(1);
		verifyPageTitle("Danfoss Global Product Store | Homepage");
		switchToParentWindow();

		return this;
	}

	public All_Products_Page Click_All_Danfoss_products() throws InterruptedException {
		clickWebElement(ProductPageconstants.All_Danfoss_products);
		verifyPageTitle("Products | Danfoss");
		return new All_Products_Page();
	}

	public Product_Menu_Page Click_Climate_SolutionFor_Heatind_Valves() throws InterruptedException {
		clickWebElement(ProductPageconstants.climate_SolutionFor_Heating_Valves);
		return this;
	}

	public Product_Menu_Page Click_Manual_Balancing_Valves() {
		clickWebElement(ProductPageconstants.manual_Balancing_Valves);
		return this;
	}

	public Product_Menu_Page Verify_MediaComponent_Is_Present() {
		try {
			VerifyImageIsDisplayed(ProductPageconstants.media_component_video_1);
			//VerifyImageIsDisplayed(ProductPageconstants.media_component_video_2);
			logger("Verification: Product main image is displayed ", Status.PASS);
		} catch (Exception e) {
			logger("Verification: Product main image is not displayed ", Status.FAIL);
		}
		return this;
	}
	
	public Product_Menu_Page Verify_MediaComponent_With_One_Slide_Is_Present(){
		VerifyImageIsDisplayed(ProductPageconstants.media_component_video_1);
		VerifyImageIsDisplayed(ProductPageconstants.media_component_video_1_thumbnail1);
		return this;
	}
	
	public Product_Menu_Page Verify_Play_Button_Is_Present_In_Media_Image() {
		VerifyImageIsDisplayed(ProductPageconstants.media_Play);
		return this;
	}
	
	public Product_Menu_Page Verify_Play_Button_Is_Present_In_Media_Image_For_Four_Thumb() {
		try {
			VerifyImageIsDisplayed(ProductPageconstants.media_component_PlayButton_video_2);
			logger("Verfication: Play button is present in the video component",Status.PASS);
		} catch (Exception e) {
			logger("Verfication: Play button is not present in the video component",Status.FAIL);
		}
		return this;
	}
	
	public Product_Menu_Page Verify_CaptionText_Is_Not_Present(){
		try{
			VerifyImageIsDisplayed(ProductPageconstants.Main_product_no_caption);	
			logger("Verification: Product main image caption is not present", Status.PASS);
		}catch(Exception e) {
			logger("Verification: Product main image caption is present", Status.FAIL);
		}
		return this;
	}
	
	public Product_Menu_Page Navigate_To_Each_Slide_With_Video_And_Click_Play_Button(){
		try {
			clickWebElement(ProductPageconstants.media_component_video_2_Play_Button_1);
			switchToFrame(ProductPageconstants.media_component_play_1_Video_2_Frame_1);
			clickWebElement(ProductPageconstants.Video_Component_1_Play);
			Thread.sleep(2000);
			switchToParentFrame();
			logger("Verification: Video is playing... user can able to play the video", Status.PASS);
		} catch (Exception e) {
			logger("Verification: User can not able to play the video", Status.FAIL);
		}
		return this;
	}
	
	public Product_Menu_Page Click_Next_Slide(){
		clickWebElement(ProductPageconstants.next_Slide);
		return this;
	}
	
	public Product_Menu_Page Click_Play_Button_For_Second_Video_In_Media_Component(){
		try {
			switchToFrame(ProductPageconstants.media_component_play_1_Video_2_Frame_2);
			clickWebElement(ProductPageconstants.Video_Component_1_Play);
			Thread.sleep(2000);
			switchToParentFrame();
			logger("Verification: Video is playing... user can able to play the video", Status.PASS);
		} catch (Exception e) {
			logger("Verification: User can not able to play the video", Status.FAIL);
		}
		return this;
	}
	
	public Product_Menu_Page Verify_One_Thumbnail_Image_Is_Present() {
		VerifyImageIsDisplayed(ProductPageconstants.media_component_video_1_thumbImage);
		return this;
	}
	
	public Product_Menu_Page Verify_ThumbImage_Is_Highlighted(){
		try {
			VerifyImageIsDisplayed(ProductPageconstants.media_component_video_1_thumbImageBorder);
			logger("Verification: Product thumb image is highlighted", Status.PASS);
		} catch (Exception e) {
			logger("Verification: Product thumb image is not highlighted", Status.FAIL);
			e.printStackTrace();
		}
		return this;
	}
	
	public Product_Menu_Page Verify_CaptionText_Is_Present() {
		try {
			VerifyImageIsDisplayed(ProductPageconstants.media_Component_video_1_Caption);
			logger("Verification: Product media component caption is present", Status.PASS);
		} catch (Exception e) {
			logger("Verification: Product media component caption is not present", Status.FAIL);
		}
		return this;
	}

	public Product_Menu_Page Verify_Four_Thumbnail_Image_Is_Displayed() {
		try {
			for (int i = 4; i <= 7; i++) {
				WebElement thumbimage = driver
						.findElement(By.xpath("(//img[@class='gallery-picture lazyloaded'])[" + i + "]"));
				clickWebElement(thumbimage);
				Thread.sleep(1000);
				VerifyImageIsDisplayed(thumbimage);
			}
			logger("Verification: Design for media with 4 slides is displayed ", Status.PASS);
		} catch (Exception e) {
			logger("Verification: Design for media with 4 slides is not displayed ", Status.FAIL);
		}
		return this;
	}
	
	public Product_Menu_Page Verify_One_Thumbnail_Image_Is_Displayed() throws InterruptedException{
		WebElement thumbimage = driver
				.findElement(By.xpath("//div[@class='thumbnail-image-wrapper slide-with-reserved-height']"));
		clickWebElement(thumbimage);
		Thread.sleep(1000);
		VerifyImageIsDisplayed(thumbimage);
		return this;
	}
	
	public Product_Menu_Page Verify_Product_Image_Ratio(){
		VerifyImageRatio(ProductPageconstants.media_component_video_1, 386,625);
		return this;
	}
	
	public Product_Menu_Page Verify_Main_Product_Image_Ratio(){
		VerifyImageRatio(ProductPageconstants.media_component_video_2_thumbImage, 344,516);
		return this;
	}
	
	public Product_Menu_Page Verify_Caption_Text_Is_Displayed_For_Product_Image() {
		try {
			int temp=5;
			for (int i = 4; i <= 7; i++) {
				WebElement thumbimage = driver.findElement(By.xpath("(//img[@class='gallery-picture lazyloaded'])["+i+"]"));
				clickWebElement(thumbimage);
				Thread.sleep(1000);
				int j=i;
				for(j=temp-j;j<=4;) {
					 WebElement element = driver.findElement(By.xpath("(//div[@class='grid-danf-fe-rte swiper-slide-text'])["+j+"]"));
					 String productImageCaption = element.getText();
					 logger("Verification: Product caption " + productImageCaption + " is displayed ", Status.PASS);
					 temp=temp+2;
					 break;
				}
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		return this;
	}
	
	public Product_Menu_Page Verify_Grey_Border_Is_Present_Around_Image() throws InterruptedException{
		Thread.sleep(2000);
		try {
			verifyElementDisplayed(ProductPageconstants.mediaComponent_Image_Border);
			logger("Verification: Grey border is displayed for product image", Status.PASS);
		} catch (Exception e) {
			logger("Verification: Grey border is not displayed for product image", Status.FAIL);
		}
		return this;	
	}
	
	public Product_Menu_Page Verify_Grey_Border_Is_Present_Around_Media_Image() throws InterruptedException{
		Thread.sleep(2000);
		try {
			verifyElementDisplayed(ProductPageconstants.mediaComponent_Media_Image_Border);
			logger("Verification: Grey border is displayed for media image", Status.PASS);
		} catch (Exception e) {
			logger("Verification: Grey border is not displayed for media image", Status.FAIL);
		}
		return this;
	}
	
	public Product_Menu_Page Click_On_Play_Button_In_Media_Image(){
	try {
		clickWebElement(ProductPageconstants.media_Play);
		logger("Verification: media image is opned ready to play", Status.PASS);
	} catch (Exception e) {
		logger("Verification: media image is not open and ready to play", Status.FAIL);
	}
		return this;
	}
	
	public Product_Menu_Page Click_On_Video_Play_Button() {
		try {
			switchToFrame(ProductPageconstants.play_Video_Frame);
			clickWebElement(ProductPageconstants.play_Video);
			Thread.sleep(2000);
			switchToParentFrame();
			logger("Verification: Video is playing... user can able to play the video", Status.PASS);
		} catch (Exception e) {
			logger("Verification: User can not able to play the video", Status.FAIL);
		}
		return this;
	}
	
	public Product_Menu_Page Click_On_Video_Close_Button(){
		try {
			MoveToElement(ProductPageconstants.close_Video);
			clickWebElement(ProductPageconstants.close_Video);
			logger("Verification: Video is stopped", Status.PASS);
		} catch (Exception e) {
			logger("Verification: Video is not stopped", Status.FAIL);
		}
		return this;
	}
	
	public Product_Menu_Page Verify_Media_Component_With_Single_Image_Is_Present(){
		VerifyImageIsDisplayed(ProductPageconstants.single_Component);
		return this;
	}
	
	public Product_Menu_Page Verify_The_Image_Is_Scaled_With_Full_Width(){
		try {
			VerifyImageRatio(ProductPageconstants.single_Component,414,621);
			logger("The image is scaled with full width (6 columns) and is not limited by height",Status.PASS);
		} catch (Exception e) {
			logger("The image is not scaled with full width (6 columns) and is not limited by height",Status.FAIL);
		}
		return this;
	}
	
	public Product_Menu_Page Verify_CaptionText_Is_Present_For_Single_Image(){
		VerifyImageIsDisplayed(ProductPageconstants.single_Component_Caption);
		return this;
	}
	
	public Product_Menu_Page Click_The_Single_Image() {
		try {
			clickWebElement(ProductPageconstants.single_Component_Image);
			logger("Verification: Image is opened and visible",Status.PASS);
		} catch (Exception e) {
			logger("Verification: Image not is opened and visible",Status.FAIL);
		}
		return this;
	}
	
	public Product_Menu_Page Click_Close_The_Image(){
		try {
			Thread.sleep(2000);
			//switchToFrame(ProductPageconstants.single_Component_Frame);
			clickWebElement(ProductPageconstants.single_Component_Close);
			//switchToParentFrame();
			logger("Image is closed successfully",Status.PASS);
		} catch (Exception e) {
			logger("Image is not closed successfully",Status.FAIL);
		}
		return this;
	}
	
	public Product_Menu_Page Verify_Main_Image_With_Four_Thumbnails_placed() {
		int temp = 4;
		int size = driver.findElements(By.xpath("((//div[@class='swiper-wrapper'])[2]/div/div)")).size();
		try {
			if (temp == size) {
				logger("Verification: Main image is displayed with 4 thumbnail images", Status.PASS);
				for (int i = 1; i <= 4; i++) {
					WebElement element = driver
							.findElement(By.xpath("((//div[@class='swiper-wrapper'])[2]/div/div)[" + i + "]"));
					clickWebElement(element);
				}
			} else {
				logger("Verification: Main image is not displayed with 4 thumbnail images", Status.FAIL);
			}
			driver.findElement(By.xpath("((//div[@class='swiper-wrapper'])[2]/div/div)[1]")).click();
		} catch (Exception e) {
			logger("Verification: Main image is not displayed with 4 thumbnail images", Status.FAIL);
		}
		return this;
	}

	public Product_Menu_Page Verify_Product_Image_Is_Open_When_User_Doubleclick() {
		doubleClickWebElement(ProductPageconstants.manual_Balancing_Valve_MSVBD);
		return this;
	}

	public Product_Menu_Page Verify_Expand_Collapse_Component_Is_Present() {
		driver.navigate().refresh();
		try {
			MoveToElement(ProductPageconstants.ExpandCollapseComponent1);
			verifyElementDisplayed(ProductPageconstants.ExpandCollapseComponent1);
			logger("Expand and Collapse element is present", Status.PASS);
		} catch (Exception e) {
			logger("Expand and Collapse element is not present", Status.FAIL);
		}
		return this;
	}

	public Product_Menu_Page Verify_All_Items_Of_Component_Are_Shown_In_Collapsed_State() {
		try {
			verifyElementDisplayed(ProductPageconstants.EC_Component_1_Collapsed_State);
			logger("Verification: All EC compomnent is in collapsed state", Status.PASS);
		} catch (Exception e) {
			logger("Verification: All EC compomnent is not in collapsed state", Status.FAIL);
		}
		return this;
	}

	public Product_Menu_Page Verify_EC_Component_Is_Highlighted_When_Hover() throws InterruptedException {
		MoveToElement(ProductPageconstants.ExpandCollapseComponent1);
		VerifyElementIsHighlighted(ProductPageconstants.ExpandCollapseComponent1);
		return this;
	}

	public Product_Menu_Page Click_EC_Component() throws InterruptedException {
		MoveToElement(ProductPageconstants.EC_Component_1_Collapsed_State);
		clickWebElement(ProductPageconstants.EC_Component_1_Collapsed_State);
		return this;
	}

	public Product_Menu_Page Verify_Image_In_EC_Component() throws InterruptedException {
		Thread.sleep(2000);
		VerifyElementIsClickable(ProductPageconstants.EC_Component_2_Collapsed_State);
		MoveToElement(ProductPageconstants.EC_Component_2_Collapsed_State);
		clickWebElement(ProductPageconstants.EC_Component_2_Collapsed_State);
		Thread.sleep(4000);
		MoveToElement(ProductPageconstants.EC_Component_2_Expanded_Image);
		VerifyImageIsDisplayed(ProductPageconstants.EC_Component_2_Expanded_Image);
		// clickWebElement(ProductPageconstants.EC_Component_2_Expanded_State);
		return this;
	}

	public Product_Menu_Page Click_On_Video_In_EC_Component() throws InterruptedException {
		clickWebElement(ProductPageconstants.EC_Component_1_Collapsed_State);
		clickWebElement(ProductPageconstants.EC_Component_1_Video_1);
		switchToFrame(ProductPageconstants.EC_Component_1_Video_frame);
		clickJSWebElement(ProductPageconstants.EC_Component_2_Video_Play);
		Thread.sleep(3000);
		switchToParentFrame();
		MoveToElement(ProductPageconstants.EC_Component_close_video);
		clickWebElement(ProductPageconstants.EC_Component_close_video);
		return this;
	}

	public Product_Menu_Page Click_On_Video_In_EC_Component2() throws InterruptedException {
		clickWebElement(ProductPageconstants.EC_Component_2_Video);
		clickWebElement(ProductPageconstants.EC_Component_1_Video_Play);
		switchToFrame(ProductPageconstants.EC_Component_1_Video_frame);
		clickJSWebElement(ProductPageconstants.EC_Component_1_Video_Play);
		Thread.sleep(3000);
		switchToParentFrame();
		MoveToElement(ProductPageconstants.EC_Component_close_video);
		clickWebElement(ProductPageconstants.EC_Component_close_video);
		return this;
	}

	public Product_Menu_Page Verify_Arrow_Icon_Changes_The_Direction_To_The_Top() {
		try {
			verifyElementDisplayed(ProductPageconstants.EC_Component_2_Expanded_State);
			clickWebElement(ProductPageconstants.EC_Component_2_Expanded_State);
			logger("Verification: EC component arrow icon is chnaged to up(top) direction", Status.PASS);
		} catch (Exception e) {
			logger("Verification: EC component arrow icon is not chnaged to up(top) direction", Status.FAIL);
		}
		return this;
	}

	public Product_Menu_Page Zoom_Out_The_Browser() {
		JavascriptExecutor jse = (JavascriptExecutor) driver;
		jse.executeScript("document.body.style.zoom = '80%';");
		return this;
	}

	public Product_Menu_Page Verify_EC_Component_In_Collapsed_View_When_Arrow_Icon_Is_Down()
			throws InterruptedException {
		MoveToElement(ProductPageconstants.ExpandCollapseComponent1);
		clickWebElement(ProductPageconstants.ExpandCollapseComponent1);
		Thread.sleep(3000);
		try {
			if (ProductPageconstants.EC_Component_1_Video_1.isDisplayed() == false) {
				logger("Verification: EC component content is in collapsed state when arrow down", Status.PASS);
			} else {
				logger("Verification: EC component content is not in collapsed state when arrow down", Status.FAIL);
			}
		} catch (Exception e) {

		}
		return this;
	}

	public Product_Menu_Page Verify_FAQ_Component_Is_Present() {
		verifyElementDisplayed(ProductPageconstants.FAQ_Component1);
		return this;
	}

	public Product_Menu_Page Verify_FAQ_Component_Border_Colour() throws InterruptedException {
		try {
			VerifyElementColour(ProductPageconstants.FAQ_Component1_Title, "rgba(48, 48, 48, 1)");
			logger("Verification: FAQ border colour is matching with grey", Status.PASS);
		} catch (InterruptedException e) {
			logger("Verification: FAQ border colour is not matching with grey", Status.FAIL);
		}
		return this;
	}

	public Product_Menu_Page Verify_FAQ_Component_Is_HoverState_And_Highlighted_With_Red_Color()
			throws InterruptedException {
		VerifyElementColour(ProductPageconstants.FAQ_Component1_Title, "rgba(48, 48, 48, 1)");
		logger("Verification: FAQ border colour is matching with grey", Status.PASS);
		try {
			MoveToElement(ProductPageconstants.FAQ_Component1_Title);
			VerifyElementColour(ProductPageconstants.FAQ_Component1_Title, "rgba(226, 0, 15, 1)");
			logger("Verification: FAQ component is highlighted with red colour when mouse hover", Status.PASS);
		} catch (InterruptedException e) {
			logger("Verification: FAQ component is not highlighted with red colour when mouse hover", Status.FAIL);
		}
		return this;
	}

	public Product_Menu_Page Click_On_FAQ_Component_Arrow_Icon() {
		try {
			verifyElementDisplayed(ProductPageconstants.FAQ_Component1_Arrow_Down);
			clickWebElement(ProductPageconstants.FAQ_Component1_Arrow_Down);
			logger("Verification: FAQ component is opened", Status.PASS);
		} catch (Exception e) {
			logger("Verification: FAQ component is not opened", Status.FAIL);
		}
		return this;
	}

	public Product_Menu_Page Verify_FAQ_Content_Is_Present() {
		verifyElementDisplayed(ProductPageconstants.FAQ_Component1_content);
		return this;
	}

	public Product_Menu_Page Verify_FAQ_Arrow_Icon_Changes_The_Direction_To_The_Top() {
		verifyElementDisplayed(ProductPageconstants.FAQ_Component1_Arrow_Up);
		return this;
	}

	public Product_Menu_Page Verify_FAQ_Component_Is_Close_When_Clicking_On_Arrow_Up() {
		try {
			Thread.sleep(2000);
			VerifyElementIsClickable(ProductPageconstants.FAQ_Component1_Arrow_Up);
			clickWebElement(ProductPageconstants.FAQ_Component1_Arrow_Up);
			VerifyElementIsClickable(ProductPageconstants.FAQ_Component1_Arrow_Down);
			logger("Verification: FAQ component is closing when user is clicking on arrow up icon", Status.PASS);
		} catch (Exception e) {
			logger("Verification: FAQ component is not closing when user is clicking on arrow up icon", Status.FAIL);
		}
		return this;
	}

	public Product_Menu_Page Click_On_Ask_Us_Anything_FAQ() {
		clickWebElement(ProductPageconstants.FAQ_Ask_Us_Anything);
		return this;
	}

	public Product_Menu_Page Click_On_Video_Link_In_Ask_Us_Anything_FAQ() {
		scrollToWebelement(ProductPageconstants.FAQ_Ask_Us_Anything);
		clickWebElement(ProductPageconstants.FAQ_Ask_Us_Anything_Play_button);
		return this;
	}

	public Product_Menu_Page Click_On_Video_Play_Button_For_Ask_Us_Anything_FAQ() {
		try {
			switchToFrame(ProductPageconstants.play_Video_Frame_FAQ3);
			clickWebElement(ProductPageconstants.play_Video);
			Thread.sleep(2000);
			switchToParentFrame();
			WebElement close = driver.findElement(By.xpath("//div[@class='popup popup__3tY1O preview-box']"));
			MoveToElement(ProductPageconstants.close_Video);
			clickWebElement(ProductPageconstants.close_Video);
			logger("Verification: Video is playing... user can able to play the video", Status.PASS);
		} catch (Exception e) {
			logger("Verification: User can not able to play the video", Status.FAIL);
		}
		return this;
	}

	public Product_Menu_Page Click_On_Video_Play_Button_For_Metaverse_FAQ() {
		try {
			MoveToElement(ProductPageconstants.FAQ_Metaverse_Play_Button);
			clickWebElement(ProductPageconstants.FAQ_Metaverse_Play_Button);
			if (ProductPageconstants.play_Video_Frame_FAQ_Metaverse.isDisplayed() == Boolean.FALSE) {
				doubleClickWebElement(ProductPageconstants.FAQ_Metaverse_Play_Button);
			}
			switchToFrame(ProductPageconstants.play_Video_Frame_FAQ_Metaverse);
			scrollToWebelement(ProductPageconstants.play_Video);
			clickWebElement(ProductPageconstants.play_Video);
			Thread.sleep(2000);
			switchToParentFrame();
			MoveToElement(ProductPageconstants.close_Video);
			clickWebElement(ProductPageconstants.close_Video);
			logger("Verification: Video is playing... user can able to play the video", Status.PASS);
		} catch (Exception e) {
			logger("Verification: User can not able to play the video", Status.FAIL);
		}
		return this;
	}

	public Product_Menu_Page Verify_Learning_Component_Is_Present() {
		verifyElementDisplayed(ProductPageconstants.Learning_Component);
		return this;
	}

	public Product_Menu_Page Verify_The_Column_Name_Present_In_Learning_Component() {
		verifyElementDisplayed(ProductPageconstants.Learning_Component_Name);
		verifyElementDisplayed(ProductPageconstants.Learning_Component_Language);
		return this;
	}

	public Product_Menu_Page Verify_Rows_Are_Displayed_In_Collapsed_State() {
		verifyElementDisplayed(ProductPageconstants.LC_Record_Arrow);
		return this;
	}

	public Product_Menu_Page Verify_Collapsed_Rows_Are_Shown_With_White_Background() throws InterruptedException {
		VerifyElementColour(ProductPageconstants.LC_Record_Background_Colour, "rgba(104, 104, 104, 1)");
		return this;
	}

	public Product_Menu_Page Verify_Filter_Icon_Is_Present() {
		verifyElementDisplayed(ProductPageconstants.LC_Filter);
		return this;
	}

	public Product_Menu_Page Verify_Text_Within_Collapsed_Row_Is_Bold_Font() {
		verifyElementDisplayed(ProductPageconstants.LC_Row_Record_1);
		String Font_Style = ProductPageconstants.LC_Row_Record_1.getCssValue("font-weight");
		if (Font_Style.equals("700")) {
			logger("Verification: Learning Component Record Font is BOLD", Status.PASS);
		} else {
			logger("Verification: Learning Component Record Font is BOLD", Status.FAIL);
		}
		return this;
	}

	public Product_Menu_Page Verify_Arrow_Button_Is_Present_In_The_Record() {
		verifyElementDisplayed(ProductPageconstants.LC_Row_Record_Arrow);
		return this;
	}

	public Product_Menu_Page Click_On_Arrow_Down_And_Verify_Record_Expanded() throws InterruptedException {
		Thread.sleep(4000);
		clickWebElement(ProductPageconstants.LC_Row_Record_Arrow);
		try {
			verifyElementDisplayed(ProductPageconstants.LC_Row_Record_1_Description);
			logger("Verification: Record is expanded when user click arrow down icon", Status.PASS);
		} catch (Exception e) {
			logger("Verification: Record is not expanded when user click arrow down icon", Status.FAIL);
		}
		return this;
	}

	public Product_Menu_Page Verify_Expanded_Record_Background_Colour_Is_Grey() throws InterruptedException {
		VerifyElementColour(ProductPageconstants.LC_Row_Record_1_Description, "rgba(104, 104, 104, 1)");
		return this;
	}

	public Product_Menu_Page Verify_CTA_Button_Is_Present() {
		verifyElementDisplayed(ProductPageconstants.LC_CTA_Button);
		VerifyElementIsClickable(ProductPageconstants.LC_CTA_Button);
		return this;
	}

	public Product_Menu_Page Click_On_CTA_Button() {
		clickWebElement(ProductPageconstants.LC_CTA_Button);
		return this;
	}

	public Product_Menu_Page AcceptCookies() throws InterruptedException {
		if (verifyElementDisplayedForEdge(HomePageconstants.acceptcookies)) {
			clickWebElement(HomePageconstants.acceptcookies);
		} else if (VerifyElementIsClickable(HomePageconstants.acceptcookies)) {
			clickWebElement(HomePageconstants.acceptcookies);
		} else {
			logger("INFO: Accept cookie pop-up is not appear", Status.INFO);
		}
		return this;
	}

	public Product_Menu_Page switch_To_New_Window_And_Close_It_Back_To_Parent_Window() throws InterruptedException {
		switch_To_New_Window_And_Close_It();
		return this;
	}

	public Product_Menu_Page Click_On_Arrow_Uo_And_Verify_Record_Collapsed() {
		clickWebElement(ProductPageconstants.LC_Row_Record_Arrow_Up);
		return this;
	}

	public Product_Menu_Page Verify_Expanded_Record_Is_Collapsed() {
		if (ProductPageconstants.LC_Row_Record_1.isEnabled()) {
			logger("Verification: Expanded Record is Collapsed when user click on Arrow Up Icon", Status.PASS);
		} else {
			logger("Verification: Expanded Record is not Collapsed when user click on Arrow Up Icon", Status.FAIL);
		}

		return this;
	}

	public Product_Menu_Page Verify_Records_Are_Sorted_By_Accending_Order_By_Default() {
		clickWebElement(ProductPageconstants.LC_Filter);
		clickWebElement(ProductPageconstants.LC_Filter_English);
		List rec = new ArrayList<String>();
		clickWebElement(ProductPageconstants.LC_Next_Page);
		List records = driver.findElements(By.xpath("//span[@class='learning-table-body-cell-text ']"));
		for (int i = 1; i <= records.size(); i++) {
			String rec_desc = driver
					.findElement(By.xpath("(//span[@class='learning-table-body-cell-text '])[" + i + "]")).getText();
			String data = rec_desc.substring(0, 1);
			System.out.println(data);
			boolean character = data.matches("[A-Z]+");
			if (character == Boolean.FALSE) {
				if (data.contains("É")) {
					continue;
				} else {
					break;
				}
			} else {
				rec.add(data);
			}
		}
		if (isCollectionSorted(rec) == Boolean.TRUE) {
			logger("Verification: Records are sorted by default", Status.PASS);
		} else {
			logger("Verification: Records are not sorted by default", Status.FAIL);
		}
		return this;
	}

	public Product_Menu_Page Verify_Learning_Component_Filter_Option_Is_Working() {
		try {
			clickWebElement(ProductPageconstants.LC_Filter);
			logger("Verification: Filter Option is present in Learning component", Status.PASS);
		} catch (Exception e) {
			logger("Verification: Filter Option is not present in Learning component", Status.FAIL);
		}
		try {
			clickWebElement(ProductPageconstants.LC_Filter_English);
			logger("Verification: User is able to filter records based on language filter", Status.PASS);
		} catch (Exception e) {
			logger("Verification: User is not able to filter records based on language filter", Status.FAIL);
		}
		return this;
	}

	public Product_Menu_Page Click_Filter_Reset_Button() {
		try {
			clickWebElement(ProductPageconstants.LC_Filter_Reset);
			logger("Verification: Records are resetted upon clicking on reset button", Status.PASS);
		} catch (Exception e) {
			logger("Verification: Records are not resetted upon clicking on reset button", Status.FAIL);
		}
		return this;
	}

	public Product_Menu_Page Verify_Spot_Group_2Plus1_Component_Is_Presnt() {
		if (ProductPageconstants.Spot_Group_1.isDisplayed() == Boolean.TRUE) {
			logger("Verifiaction: Spot group2+1 component is displaying", Status.PASS);
		} else {
			logger("Verifiaction: Spot group2+1 component is not displaying", Status.FAIL);
		}
		return this;
	}

	public Product_Menu_Page Verify_First_Tile_Item_Is_Displayed_In_Spot_Group_1() {
		if (ProductPageconstants.Spot_Group_1_Tile1.isDisplayed() == Boolean.TRUE) {
			logger("Verifiaction: First Tile is present in Spot group2+1 component", Status.PASS);
		} else {
			logger("Verifiaction: First Tile is not present in Spot group2+1 component", Status.FAIL);
		}
		return this;
	}

	public Product_Menu_Page Verify_Description_Is_Shown_Only_For_2nd_and_3rd_Tile_In_Spot_Group() {
		verifyElementDisplayed(ProductPageconstants.Spot_Group_1_Tile2_Description);
		verifyElementDisplayed(ProductPageconstants.Spot_Group_1_Tile3_Description);
		return this;
	}

	public Product_Menu_Page Verify_Description_Is_Shown_Only_For_2nd_and_3rd_Tile_In_Spot_Group_2() {
		verifyElementDisplayed(ProductPageconstants.Spot_Group_2_Tile2_Description);
		verifyElementDisplayed(ProductPageconstants.Spot_Group_2_Tile3_Description);
		return this;
	}

	public Product_Menu_Page Verify_Exit_Icon_Is_Placed_Before_The_Title_Link_For_Exit_Icon() {
		try {
			verifyElementDisplayed(ProductPageconstants.Spot_Group_External_Link_Exit_Icon);
			logger("Verifiaction: Exit Icon is displayed for external link", Status.PASS);
		} catch (Exception e) {
			logger("Verifiaction: Exit Icon is not displayed for external link", Status.FAIL);
		}
		return this;
	}

	public Product_Menu_Page Verify_Two_CTA_Buttons_Are_Displaying_In_Spot_Group() {
		verifyElementDisplayed(ProductPageconstants.Spot_Group_1_CTA_Button_1);
		verifyElementDisplayed(ProductPageconstants.Spot_Group_1_CTA_Button_2);
		return this;
	}

	public Product_Menu_Page Verify_One_CTA_Button_Is_Displaying_In_Spot_Group_2() {
		verifyElementDisplayed(ProductPageconstants.Spot_Group_2_CTA_Button_1);
		return this;
	}

	public Product_Menu_Page Verify_First_Tile_Item_Is_Displayed_In_Spot_Group_2() {
		verifyElementDisplayed(ProductPageconstants.Spot_Group_2_Tile1);
		return this;
	}

	public Product_Menu_Page Verify_Play_Icon_Is_Displayed_On_All_Items() {
		verifyElementDisplayed(ProductPageconstants.Spot_Group_2_Play_Button);
		return this;
	}

	public Product_Menu_Page Verify_Tile_Is_Clickable_And_Hover_State_Is_Present() throws InterruptedException {
		try {
			VerifyElementIsClickable(ProductPageconstants.Spot_Group_2_Clickable_Tile);
			logger("Verifiaction: Spot Group 2+1 Tile is clickable", Status.PASS);
		} catch (Exception e) {
			logger("Verifiaction: Spot Group 2+1 Tile is clickable", Status.FAIL);
		}
		VerifyElementColour(ProductPageconstants.Spot_Group_2_Tile3, "rgba(48, 48, 48, 1)");
		try {
			MoveToElement(ProductPageconstants.Spot_Group_2_Tile3);
			VerifyElementColour(ProductPageconstants.Spot_Group_2_Tile3, "rgba(226, 0, 15, 1)");
			logger("Verifiaction: Mouse hover is working in spot group 2+1 Tile", Status.PASS);
		} catch (InterruptedException e) {
			logger("Verifiaction: Mouse hover is not working in spot group 2+1 Tile", Status.FAIL);

		}
		return this;
	}

	public Product_Menu_Page Click_On_Tile_And_Verify_User_Is_Redirect_To_Another_Page() throws InterruptedException {
		Thread.sleep(3000);
		try {
			MoveToElement(ProductPageconstants.Spot_Group_2_Clickable_Tile);
			doubleClickWebElement(ProductPageconstants.Spot_Group_2_Clickable_Tile);
			waitForPageLoad();
			// switch_To_New_Window_And_Close_It_Back_To_Parent_Window();
			if (driver.getTitle() == "Danfoss Installer App | Download free HVAC installer app | Danfoss") {
				logger("Title of the new window is " + driver.getTitle(), Status.PASS);
			} else {
				logger("Title of the new window 'Danfoss Installer App | Download free HVAC installer app | Danfoss' is not matching with expected title: "
						+ driver.getTitle(), Status.PASS);
			}
			driver.navigate().back();
			logger("Verifiaction: User is navigating to another page upon clicking on url Tile", Status.PASS);
		} catch (Exception e) {
			logger("Verifiaction: User is not navigating to another page upon clicking on url Tile", Status.FAIL);
		}
		return this;
	}

	public Product_Menu_Page Verify_User_Is_Able_To_Play_Video_From_Tile_Video_Play_Button() {
		clickWebElement(ProductPageconstants.Spot_Group_2_Play_Button);
		try {
			switchToFrame(ProductPageconstants.Spot_Group_2_Play_Button_Frame);
			clickWebElement(ProductPageconstants.play_Video);
			Thread.sleep(2000);
			switchToParentFrame();
			MoveToElement(ProductPageconstants.close_Video);
			clickWebElement(ProductPageconstants.close_Video);
			logger("Verification: Video is playing... user can able to play the video", Status.PASS);
		} catch (Exception e) {
			logger("Verification: User can not able to play the video", Status.FAIL);
		}
		return this;
	}

	public Product_Menu_Page Verify_Spot_Group_Cascade_Is_Present_On_The_Page() {
		try {
			verifyElementDisplayed(ProductPageconstants.Spot_Group_Casecade_1);
			logger("Verification: Spot Group Casecase is displaying", Status.PASS);
		} catch (Exception e) {
			logger("Verification: Spot Group Casecase is not displaying", Status.FAIL);
		}
		return this;
	}

	public Product_Menu_Page Verify_All_Tiles_Are_Shown_On_The_Page_One_By_one() {
		int size = driver.findElements(By.xpath("//div[@class='spot-cascade-content-container']")).size();
		for (int i = 1; i <= size; i++) {
			WebElement ele = driver
					.findElement(By.xpath("(//div[@class='spot-cascade-content-container'])[" + i + "]"));
			verifyElementDisplayed(ele);
		}
		return this;
	}

	public Product_Menu_Page Verify_Spot_Group_Casecade_Image_Contains_Play_Button() {
		try {
			verifyElementDisplayed(ProductPageconstants.Spot_Group_Casecade_1_Play_Button);
			logger("Verification: Spot Group Casecase Image Play button is displayed", Status.PASS);
		} catch (Exception e) {
			logger("Verification: Spot Group Casecase Image Play button is not displayed", Status.FAIL);
		}
		return this;
	}

	public Product_Menu_Page Verify_Title_Font_Size_Is_H2() {
		VerifyElementFontSize(ProductPageconstants.Spot_Group_Casecade_1_Title, "h2");
		return this;
	}

	public Product_Menu_Page Verify_Title_Font_Size_Is_H3() {
		VerifyElementFontSize(ProductPageconstants.Spot_Group_Casecade_2_Title, "h3");
		return this;
	}

	public Product_Menu_Page Verify_Title_Font_Size_Is_H4() {
		VerifyElementFontSize(ProductPageconstants.Spot_Group_Casecade_3_Title, "h4");
		return this;
	}

	public Product_Menu_Page Verify_Caption_Text_Is_Shown_Under_The_Image() {
		try {
			verifyElementDisplayed(ProductPageconstants.Spot_Group_Casecade_1_Caption);
			logger("Verification: Caption text is displayed under the image", Status.PASS);
		} catch (Exception e) {
			logger("Verification: Caption text is not displayed under the image", Status.FAIL);
		}
		return this;
	}

	public Product_Menu_Page Verify_The_Link_Button_Is_Present() {
		verifyElementDisplayed(ProductPageconstants.Spot_Group_Casecade_1_Link_Button);
		return this;
	}

	public Product_Menu_Page Verify_Exit_Icon_Is_Present_In_Button_Link() {
		MoveToElement(ProductPageconstants.Spot_Group_Casecade_4_cta_Button);
		verifyElementDisplayed(ProductPageconstants.Spot_Group_Casecade_1_Link_Button_Exit_Icon);
		return this;
	}

	public Product_Menu_Page Click_On_The_Button_Link() {
		try {
			clickWebElement(ProductPageconstants.Spot_Group_Casecade_1_Link_Button_Exit_Icon);
			switch_To_New_Window_And_Close_It_Back_To_Parent_Window();
			logger("New page is opened upon clicking on button link url", Status.PASS);
		} catch (Exception e) {
			logger("New page is not opened upon clicking on button link url", Status.FAIL);
		}
		return this;
	}

	public Product_Menu_Page Verify_User_Is_Able_To_Play_Video_From_Spot_Group_Cascade_Tile_Play_Button() {
		clickWebElement(ProductPageconstants.Spot_Group_Casecade_4_Play_Button);
		try {
			switchToFrame(ProductPageconstants.Spot_Group_Casecade_4_Play_Button_Frame);
			clickWebElement(ProductPageconstants.play_Video);
			Thread.sleep(2000);
			switchToParentFrame();
			MoveToElement(ProductPageconstants.close_Video);
			clickWebElement(ProductPageconstants.close_Video);
			logger("Verification: Video is playing... user can able to play the video", Status.PASS);
		} catch (Exception e) {
			logger("Verification: User can not able to play the video", Status.FAIL);
		}
		return this;
	}

	public Product_Menu_Page Verify_Spot_group_with_multiple_links_is_present() {
		int size = driver.findElements(By.xpath("(//div[contains(text(),'Test Automation')]/following::ul)[1]/li"))
				.size();
		for (int i = 0; i <= size; i++) {
		}
		WebElement ele = driver.findElement(
				By.xpath("(//div[contains(text(),'Test Automation')]/following::ul)[1]/li" + "[" + size + "]"));
		// MoveToElement(ele);
		verifyElementDisplayed(ele);
		return this;
	}

	public Product_Menu_Page Verify_Exit__icon_is_placed_before_the_link_title_only_for_external_link() {
		MoveToElement(ProductPageconstants.Spot_Group_MultiLink_Exit_Button);
		verifyElementDisplayed(ProductPageconstants.Spot_Group_MultiLink_Exit_Button);
		return this;
	}

	public Product_Menu_Page Verify_User_can_able_to_play_video_from_spot_grop() {
		clickWebElement(ProductPageconstants.Spot_Group_MultiLink_Video_Play_Button);
		try {
			switchToFrame(ProductPageconstants.Spot_Group_Multilink_Play_Button_Frame);
			clickWebElement(ProductPageconstants.play_Video);
			Thread.sleep(2000);
			switchToParentFrame();
			MoveToElement(ProductPageconstants.close_Video);
			clickWebElement(ProductPageconstants.close_Video);
			logger("Verification: Video is playing... user can able to play the video", Status.PASS);
		} catch (Exception e) {
			logger("Verification: User can not able to play the video", Status.FAIL);
		}

		return this;
	}

	public Product_Menu_Page Click_On_Link_And_Verify_User_Is_Naviagte_To_Different_Page() throws InterruptedException {
		clickWebElement(ProductPageconstants.Spot_Group_Multilink_External_Link);
		switch_To_New_Window_And_Close_It_Back_To_Parent_Window();
		return this;
	}

	public Product_Menu_Page Verify_Spot_Group_Multilink_Title_Is_Present() {
		verifyElementDisplayed(ProductPageconstants.Spot_Group_Multilink_Title);
		return this;
	}

	public Product_Menu_Page Verify_Spot_Group_Multilink_Description_Is_Present() {
		verifyElementDisplayed(ProductPageconstants.Spot_Group_Multilink_Description);
		return this;
	}

	public Product_Menu_Page Script_Pass_Logger() {
		logger("Script Pass Successfully", Status.PASS);
		return this;
	}

	public Product_Menu_Page Verify_Spot_group_with_single_link_is_present_on_the_page() {
		MoveToElement(ProductPageconstants.Spot_Group_SingleLink);
		verifyElementDisplayed(ProductPageconstants.Spot_Group_SingleLink);
		return this;
	}

	public Product_Menu_Page Verify_Exit_Icon_Is_Present_In_External_Link() throws InterruptedException {
		MoveToElement(ProductPageconstants.Spot_Group_SingleLink_External_Link_Icon);
		if (verifyElementDisplayed(ProductPageconstants.Spot_Group_SingleLink_External_Link_Icon) == Boolean.TRUE) {
			clickJSWebElement(ProductPageconstants.Spot_Group_SingleLink_External_Link_Icon);
		}
		switch_To_New_Window_And_Close_It_Back_To_Parent_Window();
		return this;
	}

	public Product_Menu_Page Verify_Whole_Spot_group_Image_Is_Clickable() throws InterruptedException {
		VerifyElementIsClickable(ProductPageconstants.Spot_Group_SingleLink_Image);
		return this;
	}

	public Product_Menu_Page Verify_User_Is_Redirect_To_The_Link_Specified() throws InterruptedException {
		Thread.sleep(6000);
		MoveToElement(ProductPageconstants.Spot_Group_SingleLink_Image);
		clickWebElement(ProductPageconstants.Spot_Group_SingleLink_Image);
		navigateBack();
		return this;
	}

	public Product_Menu_Page Verify_Play_Button_Is_Present_In_The_Spot_Group_Single_Link_Component() {
		verifyElementDisplayed(ProductPageconstants.Spot_Group_SingleLink_Play_Button);
		return this;
	}

	public Product_Menu_Page Verify_Title_Is_Placed_Under_The_Image() {
		verifyElementDisplayed(ProductPageconstants.Spot_Group_SingleLink_Title);
		return this;
	}

	public Product_Menu_Page Verify_User_Is_Able_To_Play_Video_From_Spot_Group_Component() {
		verifyElementDisplayed(ProductPageconstants.Spot_Group_SingleLink_Play_Button);
		clickWebElement(ProductPageconstants.Spot_Group_SingleLink_Play_Button);
		try {
			switchToFrame(ProductPageconstants.Spot_Group_Multilink_Play_Button_Frame);
			clickWebElement(ProductPageconstants.play_Video);
			Thread.sleep(2000);
			switchToParentFrame();
			MoveToElement(ProductPageconstants.close_Video);
			clickWebElement(ProductPageconstants.close_Video);
			logger("Verification: Video is playing... user can able to play the video", Status.PASS);
		} catch (Exception e) {
			logger("Verification: User can not able to play the video", Status.FAIL);
		}
		return this;
	}

	public Product_Menu_Page Verify_Component_Is_Displayed_on_the_page_without_verlapping() {
		verifyElementDisplayed(ProductPageconstants.Slider_FullBleed_Img);
		return this;
	}
	
	public Product_Menu_Page Verify_Slider_Title_Is_Present(){
		MoveToElement(ProductPageconstants.Slider_Title);
		verifyElementDisplayed(ProductPageconstants.Slider_Title);
		return this;
	}
	
	public Product_Menu_Page Verify_Slider_Description_Is_Present(){
		verifyElementDisplayed(ProductPageconstants.Slider_Description);
		MoveToElement(ProductPageconstants.Slider_Description);
		return this;
	}
	
	public Product_Menu_Page Verify_Slider_Button_Is_Present(){
		verifyElementDisplayed(ProductPageconstants.Slider_Play_Video);
		MoveToElement(ProductPageconstants.Slider_Play_Video);
		return this;
	}
	
	public Product_Menu_Page Click_Slider_Image_And_Verify_User_Is_Not_Redirect(){
		VerifyElementIsClickable(ProductPageconstants.Slider_Image);
		return this;
	}
	
	public Product_Menu_Page click_Slider_Button_And_Verify_User_can_able_to_play_video(){
		clickWebElement(ProductPageconstants.Slider_Play_Video);
		try {
			switchToFrame(ProductPageconstants.Slider_Video_Frame);
			clickWebElement(ProductPageconstants.play_Video);
			Thread.sleep(2000);
			switchToParentFrame();
			MoveToElement(ProductPageconstants.close_Video);
			clickWebElement(ProductPageconstants.close_Video);
			logger("Verification: Video is playing... user can able to play the video", Status.PASS);
		} catch (Exception e) {
			logger("Verification: User can not able to play the video", Status.FAIL);
		}
		
		return this;
	}
	
	public Product_Menu_Page Verify_Breadcrumbs_Are_Present_In_Segment_Page(){
		verifyElementDisplayed(ProductPageconstants.breadcrumbs);
		return this;
	}
	
	public Product_Menu_Page Verify_Page_Title_Is_Present(){
		verifyElementDisplayed(ProductPageconstants.pageTitle);
		return this;
	}
	public Product_Menu_Page Verify_Page_Categories_Is_Present(){
		List<WebElement> categories_list = driver.findElements(By.xpath("//div[@class='product-segments-item col-sm-6 col-md-3']"));
		
		if(categories_list.size()==11) {
			logger("Verification: Product categories are present", Status.PASS);
			for(int i=1;i<=categories_list.size();i++) {
				String category_Name = driver.findElement(By.xpath("(//div[@class='product-segments-item col-sm-6 col-md-3']//following::div/span/a/span)["+i+"]")).getText();
				logger("Verification: Product category name is presnt as "+category_Name, Status.PASS);
			}
		}else {
			logger("Verification: Product categories are expected to be "+11+" but present as "+categories_list.size(), Status.FAIL);
		}
		return this;
	}
	
	public Product_Menu_Page Verify_Page_Categories_Is_Present_DHS(){
		List<WebElement> categories_list = driver.findElements(By.xpath("//div[@class='product-segments-item col-sm-6 col-md-3']"));
		
		if(categories_list.size()==12) {
			logger("Verification: Product categories are present", Status.PASS);
			for(int i=1;i<=categories_list.size();i++) {
				String category_Name = driver.findElement(By.xpath("(//div[@class='product-segments-item col-sm-6 col-md-3']//following::div/span/a/span)["+i+"]")).getText();
				logger("Verification: Product category name is presnt as "+category_Name, Status.PASS);
			}
		}else {
			logger("Verification: Product categories are expected to be "+categories_list.size()+" but present as "+categories_list.size(), Status.FAIL);
		}
		return this;
	}
	
	public Product_Menu_Page Verify_Category_Tile_Contains_Image(){
		List<WebElement> categories_tile_img = driver.findElements(By.xpath("//div[@class='product-segments-item col-sm-6 col-md-3']/a/div/div/picture/img"));
		if(categories_tile_img.size()==11) {
			logger("Verification: Product categories tile image is present for all "+categories_tile_img.size()+" products", Status.PASS);
		}else {
			logger("Verification: Product categories tile image is not present for all "+categories_tile_img.size()+" products", Status.FAIL);
		}
		return this;
	}
	
	public Product_Menu_Page Verify_Category_Tile_Contains_Image_DHS(){
		List<WebElement> categories_tile_img = driver.findElements(By.xpath("//div[@class='product-segments-item col-sm-6 col-md-3']/a/div/div/picture/img"));
		if(categories_tile_img.size()==12) {
			logger("Verification: Product categories tile image is present for all "+categories_tile_img.size()+" products", Status.PASS);
		}else {
			logger("Verification: Product categories tile image is not present for all "+categories_tile_img.size()+" products", Status.FAIL);
		}
		return this;
	}
	
	public Product_Menu_Page Verify_Each_Product_Category_Has_subCategory_List_Exist(){
		List<WebElement> categories_list = driver.findElements(By.xpath("//div[@class='product-segments-item col-sm-6 col-md-3']"));
		List<WebElement> sub_categories_list = driver.findElements(By.xpath("//div[@class='truncatedProductsList__1zA6L product-segments-item__list']/span/a/following::ul[@class='truncatedProductsListItems__uVmpM']"));
		if(categories_list.size()==sub_categories_list.size()) {
			logger("Verification: Each product catgegory tile has a sub categories list", Status.PASS);	
			logger("Verification: Product category "+categories_list.size()+" is matching with "+sub_categories_list.size()+" sub category list", Status.PASS);	
		}else {
			logger("Verification: Each product catgegory tile has not having sub categories list", Status.FAIL);	
			logger("Verification: Product category "+categories_list.size()+" is not matching with "+sub_categories_list.size()+" sub category list", Status.FAIL);	
		}
		return this;
	}
	
	public Product_Menu_Page Verify_Category_Tile_Image_Has_Grey_Border(){
		List<WebElement> categories_tile_img_border = driver.findElements(By.xpath("//div[@class='product-segments-item col-sm-6 col-md-3']/a/div[@class='tile__image bordered']"));
		if(categories_tile_img_border.size()==11) {
			logger("Verification: Product categories tile image is present with gray border for all "+categories_tile_img_border.size()+" products", Status.PASS);
		}else {
			logger("Verification: Product categories tile image is not present with gray border for all "+categories_tile_img_border.size()+" products", Status.FAIL);
		}
		return this;
	}
	
	public Product_Menu_Page Verify_Category_Tile_Image_Has_Grey_Border_DHS(){
		List<WebElement> categories_tile_img_border = driver.findElements(By.xpath("//div[@class='product-segments-item col-sm-6 col-md-3']/a/div[@class='tile__image bordered']"));
		if(categories_tile_img_border.size()==12) {
			logger("Verification: Product categories tile image is present with gray border for all "+categories_tile_img_border.size()+" products", Status.PASS);
		}else {
			logger("Verification: Product categories tile image is not present with gray border for all "+categories_tile_img_border.size()+" products", Status.FAIL);
		}
		return this;
	}
	
	public Product_Menu_Page Verify_Sub_Category_Item_Name_Is_Highlighted_On_Mouse_Hover() throws InterruptedException{
		List<WebElement> categories_list_image_border = driver.findElements(By.xpath("//div[@class='product-segments-item col-sm-6 col-md-3']/a/div[@class='tile__image bordered']"));
		for(int i=1;i<=categories_list_image_border.size();i++) {
			WebElement category_Name = driver.findElement(By.xpath("(//div[@class='product-segments-item col-sm-6 col-md-3']/a/div[@class='tile__image bordered'])["+i+"]"));
			VerifyElementIsHighlighted(category_Name);
		}
		return this;
	}
	
	public  Product_Menu_Page Click_Climate_Solution_For_Cooling(){
		VerifyElementIsClickable(ProductPageconstants.climate_Solution_For_Cooling);
		clickWebElement(ProductPageconstants.climate_Solution_For_Cooling);
		return this;
	}
	
	public Product_Menu_Page Verify_Page_Discription_In_Product_Page(){
		verifyElementDisplayed(ProductPageconstants.product_Page_Paragraph);
		return this;
	}
	
	public Product_Menu_Page Verify_Page_Categories_Is_Present_For_DCS(){
List<WebElement> categories_list = driver.findElements(By.xpath("//div[@class='product-segments-item col-sm-6 col-md-3']"));
		
		if(categories_list.size()==11) {
			logger("Verification: Product categories are present", Status.PASS);
			for(int i=1;i<=categories_list.size();i++) {
				String category_Name = driver.findElement(By.xpath("(//div[@class='product-segments-item col-sm-6 col-md-3']//following::div/span/a/span)["+i+"]")).getText();
				logger("Verification: Product category name is presnt as "+category_Name, Status.PASS);
			}
		}else {
			logger("Verification: Product categories are expected to be "+11+" but present as "+categories_list.size(), Status.FAIL);
		}
		return this;
	}
	
	public Product_Menu_Page Verify_Category_Tile_Contains_Image_DCS(){
		List<WebElement> categories_tile_img = driver.findElements(By.xpath("//div[@class='product-segments-item col-sm-6 col-md-3']/a/div/div/picture/img"));
		if(categories_tile_img.size()==11) {
			logger("Verification: Product categories tile image is present for all "+categories_tile_img.size()+" products", Status.PASS);
		}else {
			logger("Verification: Product categories tile image is not present for all "+categories_tile_img.size()+" products", Status.FAIL);
		}
		return this;
	}
	
	public Product_Menu_Page Click_Climate_Solution_For_Heating(){
		VerifyElementIsClickable(ProductPageconstants.climate_Solution_For_Heating);
		clickWebElement(ProductPageconstants.climate_Solution_For_Heating);
		return this;
	}
	
	public Product_Menu_Page Click_Drives(){
		VerifyElementIsClickable(ProductPageconstants.drives);
		clickWebElement(ProductPageconstants.drives);
		return this;
	}
}	
