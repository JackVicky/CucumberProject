package test.automation.umbraco.pagelocators;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;

public class UmbracoPageConstants {

	public WebDriver driver;

	public UmbracoPageConstants(WebDriver driver) {
		this.driver = driver;
		PageFactory.initElements(driver, this);
	}

	@FindBy(how = How.XPATH, using = "//button[@class='btn btn-block btn-social btn-microsoft']")
	public static WebElement signIn;
	@FindBy(how = How.XPATH, using = "//a[contains(text(),'Danfoss sites')]")
	public static WebElement danfoss_Sites;
	@FindBy(how = How.XPATH, using = "//input[@id='umb-username']")
	public static WebElement Umb_Username;
	@FindBy(how = How.XPATH, using = "//input[@id='umb-passwordTwo']")
	public static WebElement Umb_Password;
	@FindBy(how = How.XPATH, using = "//button[@class='btn umb-button__button btn-success umb-button--m umb-outline']")
	public static WebElement Umb_Login;
	@FindBy(how = How.XPATH, using = "//a[contains(text(),'hu-hu')]")
	public static WebElement hu_hu_Region;
	@FindBy(how = How.XPATH, using = "//a[contains(text(),'Products')]")
	public static WebElement products;
	@FindBy(how = How.XPATH, using = "//label[contains(text(),'Title')]")
	public static WebElement title;
	@FindBy(how = How.XPATH, using = "//button[@class='umb-node-preview__action']/localize[contains(text(),'Edit')]")
	public static WebElement CTA_Edit;
	@FindBy(how = How.XPATH, using = "(//localize[contains(text(),'Remove')])[2]")
	public static WebElement CTA_Remove;
	


}
