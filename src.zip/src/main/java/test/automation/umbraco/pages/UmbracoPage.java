package test.automation.umbraco.pages;

import org.openqa.selenium.By;
import org.openqa.selenium.support.PageFactory;

import com.aventstack.extentreports.Status;

import test.automation.globalfunctionality.TestCaseInitiator;
import test.automation.umbraco.pagelocators.UmbracoPageConstants;




public class UmbracoPage extends TestCaseInitiator {

	public UmbracoPage() {
		PageFactory.initElements(driver, UmbracoPageConstants.class);
	} 

	public UmbracoPage Click_SignIn() {
		clickWebElement(UmbracoPageConstants.signIn);
		return this;
	}
	
	public UmbracoPage Enter_Password_Umbraco() {
		enterText(UmbracoPageConstants.Umb_Password, "yh2f");
		return this;
	}
	
	public UmbracoPage Click_Login_Umbraco() {
		clickWebElement(UmbracoPageConstants.Umb_Login);
		return this;
	}
	
	public UmbracoPage Click_Danfoss_sites() {
		doubleClickWebElement(UmbracoPageConstants.danfoss_Sites);
		return this;
	}
	
	public UmbracoPage Select_Hungary_Region() {
		scrollToWebelement(UmbracoPageConstants.hu_hu_Region);
		doubleClickWebElement(UmbracoPageConstants.hu_hu_Region);
		return this;
	}
	
	public UmbracoPage Verify_Product_Category_Document_Type_Is_Present(){
		verifyElementDisplayed(UmbracoPageConstants.products);
		return this;
	}
	
	public UmbracoPage Click_Product_Category(){
		MoveToElement(UmbracoPageConstants.products);
		clickWebElement(UmbracoPageConstants.products);
		return this;
	}
	
	public UmbracoPage Verify_Subtabs_In_Product_Category_Page(){
		
		int size =driver.findElements(By.xpath("//div[@class='umb-group-panel__header']")).size();
		if(size==5) {
			for(int i=1;i<size;i++) {
				String name = driver.findElement(By.xpath("(//div[@class='umb-group-panel__header'])["+i+"]")).getText();
				logger("Verification: " + name + " is present in product category page", Status.PASS);
			}
		}else {
			logger("Verification: Expected sub tabs value in product category page is not matching with actaual value of: "+size, Status.FAIL);
		}
		return this;
	}
	
	public UmbracoPage Verify_Title_Is_Present_In_Product_Category_Page(){
		verifyElementDisplayed(UmbracoPageConstants.title);
		return this;
	}
	
	public UmbracoPage Verify_CTA_Button_Is_Present_In_Product_Category_Page(){
		scrollToWebelement(UmbracoPageConstants.CTA_Edit);
		verifyElementDisplayed(UmbracoPageConstants.CTA_Edit);
		scrollToWebelement(UmbracoPageConstants.CTA_Remove);
		verifyElementDisplayed(UmbracoPageConstants.CTA_Remove);
		return this;
	}
	
}
