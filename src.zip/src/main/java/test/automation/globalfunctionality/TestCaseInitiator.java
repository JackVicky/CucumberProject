package test.automation.globalfunctionality;

import java.util.Properties;

import org.openqa.selenium.support.PageFactory;
import org.testng.annotations.AfterClass;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.AfterSuite;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.BeforeSuite;
import org.testng.annotations.Parameters;

import test.automation.functions.PropertyFileUtil;
import test.automation.functions.WebElementActions;


public class TestCaseInitiator extends WebElementActions {

	Properties PROPERTIES_RESOURCES = PropertyFileUtil
			.loadPropertiesResources("src/main/resources/PropertyFiles/Dummy_Test_Data.properties");

	public String url_stag = PROPERTIES_RESOURCES.getProperty("test.url");
	public String url = url_stag;
	
	/*
	 * Before Suite-Initiate the Reporting process for the triggered Automation run
	 */
	@BeforeSuite
	public void beforeSuite() throws Exception {
		reportInitiator();
		//MyScreenRecorder.startRecording("WebEx_Regression_Suite");
	}

	/**
	 * Initiate the Test case name and its description // @Parameters({
	 * "environment" })
	 */

	
	@Parameters({"Browser"})
	@BeforeClass
	public void beforeClass(String Browser) {
//		test.assignCategory(category);
//		test.assignAuthor(authors);
		PageFactory.initElements(driver, this);
		//selectenvironment("QA");
	
		//intitateBrowser(Browser,url_stag);//url_stag
		intitateBrowser(Browser,url);//url_stag
		//intitateBrowser("headlessbrowser", url_stag);

	}

	/**
	 * Start the Tests with its nodes specified in align to the data provided
	 */

	@BeforeMethod
	public void beforeMethod() {

		//driver.get(url_qa);

	}

	/**
	 * After executing each method close the browser
	 */
	@AfterMethod
	public void afterMethod() {

	}
	

	/**
	 * After executing each class close the browser
	 */
	@AfterClass
	public void afterClass() {
		quitBrowsers();
		
	}

	/**
	 * Formulate the reported outputs
	 * @throws Exception 
	 */
	@AfterSuite
	public void afterSuite() throws Exception {
		exitReporter();
		//MyScreenRecorder.stopRecording();
	}

	
	public void selectenvironment(String environment) {
		if (environment.contains("QA")) {
			url = PROPERTIES_RESOURCES.getProperty("productStoret4.url");
		} else if (environment.contains("UAT")) {
			System.out.println("No links available");
		}
	}

}
