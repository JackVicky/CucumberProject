package test.automation.functions;

import java.awt.AWTException;
import java.awt.Robot;
import java.awt.event.KeyEvent;
import java.time.Duration;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.concurrent.TimeUnit;
import java.util.function.Function;

import org.json.simple.JSONObject;
import org.openqa.selenium.Alert;
import org.openqa.selenium.By;
import org.openqa.selenium.InvalidElementStateException;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.NoAlertPresentException;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebDriverException;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.edge.EdgeDriver;
import org.openqa.selenium.edge.EdgeOptions;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.remote.DesiredCapabilities;
import org.openqa.selenium.remote.RemoteWebDriver;
import org.openqa.selenium.support.ui.ExpectedCondition;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.FluentWait;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.Wait;
import org.openqa.selenium.support.ui.WebDriverWait;

import com.aventstack.extentreports.Status;

import test.automation.pagelocators.ProductPageconstants;


/**
 * @author U381447
 *
 */
public class UserActions extends ExtentReporter {
		

	// ***************************************************************************************************************
	/**
	 * To initialize the required browser and open the site
	 * 
	 * @param browser
	 * @param url
	 * @throws AWTException 
	 */
	public void intitateBrowser(String browser, String url) {

		try {
			if (browser.equalsIgnoreCase("chrome")) {
				System.setProperty("webdriver.chrome.driver",
						"src/main/resources/Driver/chromedriver_version100.exe");
				Map<String, Object> preferences = new HashMap<String, Object>();
				ChromeOptions options = new ChromeOptions();

				 JSONObject jsonObject = new JSONObject();
				 preferences.put("profile.default_content_settings.geolocation", 2);

				 options.setExperimentalOption("prefs", jsonObject);
				driver = new ChromeDriver(options);

			} else if (browser.equalsIgnoreCase("firefox")) {
				System.setProperty("webdriver.gecko.driver", "src/main/resources/Driver/geckodriver_version0.30.exe");
				driver = new FirefoxDriver();
			}
			else if(browser.equalsIgnoreCase("headlessbrowser")) {
				driver = new RemoteWebDriver(DesiredCapabilities.htmlUnit());
			}
			else if(browser.equals("edge")) {
				System.setProperty("webdriver.edge.driver","src/main/resources/Driver/msedgedriver_V96.exe");
				 EdgeOptions edgeOptions = new EdgeOptions();
			        edgeOptions.addArguments("user-data-dir=C:\\Users\\u388031\\AppData\\Local\\Microsoft\\Edge\\User Data");
			        edgeOptions.addArguments("--start-maximized");
			        driver = new EdgeDriver(edgeOptions); 
			        driver.manage().deleteAllCookies();
			        
			}
			//logger("The browser launched successfully"+ browser, Status.PASS);
			driver.get(url);
			driver.manage().window().maximize();
			driver.manage().timeouts().implicitlyWait(3, TimeUnit.SECONDS);


		} catch (WebDriverException e) {
			System.err.println("WebDriverException:  "+e);
			logger("Browser not launched", Status.FAIL);
			throw new RuntimeException();
		}
	}

	/**
	 * To locate the Webelement using specified locator type
	 * 
	 * @param locatorType
	 * @param locValue
	 * @return
	 */
	public WebElement elementLocator(String locatorType, String locValue) {
		try {
			switch (locatorType) {
			case ("id"):
				return driver.findElement(By.id(locValue));
			case ("link"):
				return driver.findElement(By.linkText(locValue));
			case ("xpath"):
				return driver.findElement(By.xpath(locValue));
			case ("name"):
				return driver.findElement(By.name(locValue));
			case ("class"):
				return driver.findElement(By.className(locValue));
			case ("tag"):
				return driver.findElement(By.tagName(locValue));
			}
		} catch (NoSuchElementException e) {
			logger("The element with locator " + locatorType + " not found.", Status.FAIL);
		} catch (WebDriverException e) {
			logger("Unknown exception occured while finding " + locatorType + " with the value " + locValue, Status.FAIL);
		}
		return null;
	}

	/**
	 * To locate the list of Webelements using specified locator type
	 * 
	 * @param locatorType
	 * @param locValue
	 * @return 
	 */
	public List<WebElement> ListOfElement(String locatorType, String locValue) {
		try {
			switch (locatorType) {
			case ("id"):
				return driver.findElements(By.id(locValue));
			case ("link"):
				return driver.findElements(By.linkText(locValue));
			case ("xpath"):
				return driver.findElements(By.xpath(locValue));
			case ("name"):
				return driver.findElements(By.name(locValue));
			case ("class"):
				return driver.findElements(By.className(locValue));
			case ("tag"):
				return driver.findElements(By.tagName(locValue));
			}
		} catch (NoSuchElementException e) {
			logger("The elements with locator " + locatorType + " not found.", Status.FAIL);
		} catch (WebDriverException e) {
			logger("Unknown exception occured while finding " + locatorType + " with the value " + locValue, Status.FAIL);
		}
		return null;


	}

	public void enterText(WebElement element, String toEnter) {
		try {
			element.clear();
			element.sendKeys(toEnter);
			logger("The data: " + toEnter + " entered successfully in the field :" + element, Status.PASS);
		} catch (InvalidElementStateException e) {
			logger("The data: " + toEnter + " could not be entered in the field :" + element, Status.FAIL);
		} catch (WebDriverException e) {
			logger("Unknown exception occured while entering " + toEnter + " in the field :" + element, Status.FAIL);
		}
	}

	/**
	 * To click a webelemnt and take screen shot of a loaded page
	 * 
	 * @param element
	 */
	public void clickWithScreenshot(WebElement element) {
		String text = "";
		try {
			WebDriverWait wait = new WebDriverWait(driver, 10);
			wait.until(ExpectedConditions.elementToBeClickable(element));
			text = element.getText();
			element.click();
			loggerWithScreenshot("The element: " + text + "  is clicked.", text, Status.PASS, true);
		} catch (InvalidElementStateException e) {
			loggerWithScreenshot("The element: " + text + " could not be clicked", text, Status.FAIL, true);
		} catch (WebDriverException e) {
			loggerWithScreenshot("Unknown exception occured while clicking in the field :", text, Status.FAIL, true);
		}
	}



	/**
	 * To click a webelement in the page
	 * 
	 * @param element
	 */
	public void clickWebElement(WebElement element) {
		String text = "";
		try {
			WebDriverWait wait = new WebDriverWait(driver, 20);
			wait.until(ExpectedConditions.elementToBeClickable(element));
			text = element.getText();
			//System.out.println("text: "+text);
			//System.out.println("element: "+element);
			
			if (driver instanceof JavascriptExecutor) { ((JavascriptExecutor)driver).
			executeScript("arguments[0].style.border='3px solid red'", element); }
			Thread.sleep(1000); 
			element.click();
			logger("The element: " + text + " is clicked", Status.PASS);
		} catch (InvalidElementStateException e) {
			logger("The element click intercepted" + text + " Other element would receive the click", Status.FAIL);
		} catch (Exception e) {
				logger("Unknown exception occured while clicking in the field :", Status.FAIL);
				e.printStackTrace();
					
		}
	}
	
	/**
	 * To Double click a webelement in the page
	 * 
	 * @param element
	 */
	public void doubleClickWebElement(WebElement element) {
		String text = "";
		try {
			WebDriverWait wait = new WebDriverWait(driver, 20);
			wait.until(ExpectedConditions.elementToBeClickable(element));
			text = element.getText();
			
			if (driver instanceof JavascriptExecutor) { ((JavascriptExecutor)driver).
			executeScript("arguments[0].style.border='3px solid red'", element); }
			Thread.sleep(1000); 
			Actions act = new Actions(driver);
			act.doubleClick(element).perform();
			logger("The element: " + text + " is clicked", Status.PASS);
		} catch (InvalidElementStateException e) {
			logger("The element: " + text + " could not be clicked", Status.FAIL);
		} catch (Exception e) {
				logger("Unknown exception occured while clicking in the field :", Status.FAIL);
				e.printStackTrace();
					
		}
	}

	/**
	 * To click a webelement with argument text in the page
	 * 
	 * @param element
	 */
	public void clickWebElementWithValue(String str) {
		String text = "";
		try {
			WebElement element = driver.findElement(By.xpath("//span[contains(text(),'"+str+"')]"));
			WebDriverWait wait = new WebDriverWait(driver, 20);
			wait.until(ExpectedConditions.elementToBeClickable(element));
			text = element.getText();
			//System.out.println("text: "+text);
			//System.out.println("element: "+element);
			
			if (driver instanceof JavascriptExecutor) { ((JavascriptExecutor)driver).
			executeScript("arguments[0].style.border='3px solid red'", element); }
			Thread.sleep(1000); 
			element.click();
			logger("The element: " + text + " is clicked", Status.PASS);
		} catch (InvalidElementStateException e) {
			logger("The element: " + text + " could not be clicked", Status.FAIL);
		} catch (Exception e) {
			
				logger("Unknown exception occured while clicking in the field :", Status.FAIL);
				e.printStackTrace();
					
		}
	}

	/**
	 * To click a webelement in the page using JS
	 * 
	 * @param element
	 */
	public void clickJSWebElement(WebElement element) {

		try {

			JavascriptExecutor executor = (JavascriptExecutor) driver;
			executor.executeScript("arguments[0].focus();", element);
			executor.executeScript("arguments[0].click();", element);
			logger("The element " + element.getText() + " is clicked using JS", Status.PASS);

		} catch (NoSuchElementException e) {
			logger("The element " + element.getText() + " is not clicked", Status.FAIL);

		} catch (Exception e) {

			logger("The element " + element.getText() + " is not clicked", Status.FAIL);

		}
	}

	/**
	 * wait for the next time to happen implicitly
	 * 
	 * @param waitTime
	 */
	public void implicitWaiting(int waitTime) {
		try {
			driver.manage().timeouts().implicitlyWait(waitTime, TimeUnit.SECONDS);
			logger("Make the runner wait for " + waitTime, Status.PASS);
		} catch (Exception e) {
			logger("Unexpected error occured in Browser", Status.FAIL);
		}
	}

	/**
	 * get the text value of a particular web element
	 * 
	 * @param element
	 * @return
	 */
	public String getText(WebElement element) {
		String bReturn = "";
		try {
			bReturn = element.getText();
		} catch (WebDriverException e) {
			logger("The element: " + element + " could not be found.", Status.FAIL);
		}
		return bReturn;
	}

	/**
	 * get the title of the loaded page
	 * 
	 * @return
	 */
	public String getPageTitle() {
		String bReturn = "";
		try {
			bReturn = driver.getTitle();
			logger("Title of page is " + bReturn + " ", Status.PASS);
		} catch (WebDriverException e) {
			logger("Unknown Exception Occured While fetching Title", Status.FAIL);
		}
		return bReturn;
	}

	/**
	 * get the attribute value of the speicifed web element
	 * 
	 * @param ele
	 * @param attribute
	 * @return
	 */
	public String getAttribute(WebElement ele, String attribute) {
		String bReturn = "";
		try {
			bReturn = ele.getAttribute(attribute);
		} catch (WebDriverException e) {
			logger("The element: " + ele + " could not be found.", Status.FAIL);
		}
		return bReturn;
	}

	/**
	 * Dropdown value selector using the available text as a reference
	 * 
	 * @param element
	 * @param value
	 */
	public void selectDropDownByText(WebElement element, String value) {
		try {
			new Select(element).selectByVisibleText(value);
			logger("The dropdown is selected with text " + value, Status.PASS);
		} catch (WebDriverException e) {
			logger("The element: " + element + " could not be found.", Status.FAIL);
		}

	}

	/**
	 * Dropdown value selector with index
	 * 
	 * @param element
	 * @param index
	 */
	public void selectDropDownByIndex(WebElement element, int index) {
		try {
			new Select(element).selectByIndex(index);
			logger("The dropdown is selected with index " + index, Status.PASS);
		} catch (WebDriverException e) {
			logger("The element: " + element + " could not be found.", Status.FAIL);
		}

	}

	/**
	 * Dropdown value selector with index
	 * 
	 * @param element
	 * @param index
	 */
	public void selectDropDownByValue(WebElement element, String value) {
		try {
			new Select(element).selectByValue(value);
			logger("The dropdown is selected with  " + value, Status.PASS);
		} catch (WebDriverException e) {
			logger("The value : " + value + " could not be found.", Status.FAIL);
		}

	}

	/**
	 * Accept the pop up if any in the page
	 * 
	 */
	public void alertAcceptor() {
		String text = "";
		try {
			Alert alert = driver.switchTo().alert();
			text = alert.getText();
			alert.accept();
			logger("The alert " + text + " is accepted.", Status.PASS);
		} catch (NoAlertPresentException e) {
			logger("There is no alert present.", Status.FAIL);
		} catch (WebDriverException e) {
			logger("WebDriverException : " + e.getMessage(), Status.FAIL);
		}
	}

	/**
	 * Dismiss the pop up if any in the page
	 * 
	 */
	public void alertDismiss() {
		String text = "";
		try {
			Alert alert = driver.switchTo().alert();
			text = alert.getText();
			alert.dismiss();
			logger("The alert " + text + " is dismissed.", Status.PASS);
		} catch (NoAlertPresentException e) {
			logger("There is no alert present.", Status.FAIL);
		} catch (WebDriverException e) {
			logger("WebDriverException : " + e.getMessage(), Status.FAIL);
		}

	}

	/**
	 * get the alert message in the pop up window of a loaded page
	 * 
	 * @return
	 */
	public String getAlertText() {
		String text = "";
		try {
			Alert alert = driver.switchTo().alert();
			text = alert.getText();
			logger("Text available in alert: " + text + " ", Status.PASS);
		} catch (NoAlertPresentException e) {
			logger("There is no alert present.", Status.FAIL);
		} catch (WebDriverException e) {
			logger("WebDriverException : " + e.getMessage(), Status.FAIL);
		}
		return text;
	}

	/**
	 * Enter text in alert box in the loaded page
	 * 
	 * @return
	 */
	public String enterTextInAlert(String str) {
		String text = "";
		try {
			Alert alert = driver.switchTo().alert();
			alert.sendKeys(str);
			logger("Text Entered in alert: " + str + " ", Status.PASS);
		} catch (NoAlertPresentException e) {
			logger("There is no alert present.", Status.FAIL);
		} catch (WebDriverException e) {
			logger("WebDriverException : " + e.getMessage(), Status.FAIL);
		}
		return text;
	}



	/**
	 * Close the current browser opened
	 * 
	 */
	public void closeBrowser() {
		try {
			driver.close();
			logger("The browser is closed", Status.PASS);
		} catch (Exception e) {
			logger("The browser could not be closed", Status.FAIL);
		}
	}

	/**
	 * Close all the browsers opened with Automation Tests
	 * 
	 */
	public void quitBrowsers() {
		try {
			driver.quit();
			logger("The opened browsers are closed", Status.PASS);
		} catch (Exception e) {
			logger("Unexpected error occured in Browser", Status.FAIL);
		}
	}

	/**
	 * Scrolling to bottom of the page using JS
	 */
	public void scrollBottomOfPageJS() {
		try {
			JavascriptExecutor executor = (JavascriptExecutor) driver;
			executor.executeScript("window.scrollTo(0, document.body.scrollHeight)");

		} catch (Exception e) {

			logger("Unexpected error occured in while scrolling buttomof the page", Status.FAIL);

		}

	}

	/**
	 * Scrolling to Top of the page using JS
	 */
	public void scrollTopOfPageJS() {
		try {

			((JavascriptExecutor) driver)
		    .executeScript("window.scrollTo(0, -document.body.scrollHeight)"); 

		} catch (Exception e) {

			logger("Unexpected error occured in while scrolling buttomof the page", Status.FAIL);

		}

	}

	/*
	 * Method to select a dropdown value if Select tag is not present
	 */
	public void DropdownValueSelector(List<WebElement> dropdownlistXpath, String ExcelValuetobePassed) {

		for (int i = 0; i < dropdownlistXpath.size(); i++)

		{
			WebElement selection = dropdownlistXpath.get(i);
			String dataValue = selection.getText();
			if (dataValue.equals(ExcelValuetobePassed)) {
				selection.click();
				break;
			}
		}
	}

	/** Select a particular radio button with the available option
	 * @param driver
	 * @param ElementToSearch
	 */
	public void selectRadioButton(String radioButtonList, String ElementToSearch)
	{
		List<WebElement> listRadioButtons = driver.findElements(By.xpath(radioButtonList));
		Iterator<WebElement> listLoop = listRadioButtons.iterator();

		while (listLoop.hasNext())
		{
			WebElement radioElement = listLoop.next();

			if (radioElement.getText().equalsIgnoreCase(ElementToSearch) && !(radioElement.isSelected()))
			{
				clickJSWebElement(radioElement);
			}
		}
	}

	/** Select a common choice with all available dropdowns in a page
	 * @param driver
	 * @param xpathElement
	 * @param itemToSelect
	 */
	public static void selectDropdownForAllElements( String dropDownList,Map data)
	{
		List<WebElement> listDropDown = driver.findElements(By.xpath(dropDownList));

		for(int i=1;i<=listDropDown.size();i++) {
			if(listDropDown.get(i) != null) {
				Select drpDown = new Select(listDropDown.get(i));
				drpDown.selectByVisibleText(data.get(("DropDownvalue")+i).toString());

			}
		}
	}

	/**
	 * Method to move control to particular element
	 * 
	 * @param ele
	 */
	public void MoveToElement(WebElement ele) {

		Actions act1 = new Actions(driver);
		try {
			act1.moveToElement(ele).build().perform();

		} catch (Exception e) {

			loggerWithScreenshot("Unable to move the element: " + ele + " ", " ", Status.FAIL, true);
		}
	}

	/**
	 * Method to get the color the element
	 * 
	 * @param ele
	 * @return
	 */
	public String GetColorofElement(WebElement ele) {

		String bReturn = "";
		try {
			bReturn = ele.getCssValue("colour");
		} catch (WebDriverException e) {
			loggerWithScreenshot("unknown exception happened while getting color of the element: " + ele + "", " ",
					Status.FAIL, true);
		}
		return bReturn;

	}

	public void Perform_Zoom_In() { 
		JavascriptExecutor executor = (JavascriptExecutor)driver;
		executor.executeScript("document.body.style.zoom = '1.55'");

	}

	public void Perform_Zoom_Out() { 
		JavascriptExecutor executor = (JavascriptExecutor)driver;
		executor.executeScript("document.body.style.zoom = '1'");

	}
	
	public String NavigateTo(String str) {

		String bReturn = "";
		try {
			driver.navigate().to(str);
		} catch (WebDriverException e) {
			loggerWithScreenshot("unable to naviagte to url: " + str + "", " ",
					Status.FAIL, true);
		}
		return bReturn;

	}
	
	public void TurnOnGeolocation() throws Exception {
		Robot r = new Robot();
		r.keyPress(KeyEvent.VK_TAB);
		r.keyRelease(KeyEvent.VK_TAB);
		r.keyPress(KeyEvent.VK_TAB);
		r.keyRelease(KeyEvent.VK_TAB);
		r.keyPress(KeyEvent.VK_ENTER);
		r.keyRelease(KeyEvent.VK_ENTER);
	}
	

	public void TurnOffGeolocation() throws Exception {
		Robot r = new Robot();
		r.keyPress(KeyEvent.VK_TAB);
		r.keyRelease(KeyEvent.VK_TAB);
		r.keyPress(KeyEvent.VK_TAB);
		r.keyRelease(KeyEvent.VK_TAB);
		r.keyPress(KeyEvent.VK_TAB);
		r.keyRelease(KeyEvent.VK_TAB);
		r.keyPress(KeyEvent.VK_ENTER);
		r.keyRelease(KeyEvent.VK_ENTER);
	}
	
	public void switch_To_New_Window_And_Close_It() throws InterruptedException{
		String winHandleBefore = driver.getWindowHandle();
		for(String winHandle : driver.getWindowHandles()){
		    driver.switchTo().window(winHandle);
		}
		logger("Title of the new window is "+driver.getTitle(),Status.PASS);
		Thread.sleep(2000);
		driver.close();
		driver.switchTo().window(winHandleBefore);
	}
	
	public void switch_To_New_Window(){
		String winHandleBefore = driver.getWindowHandle();
		
		for(String winHandle : driver.getWindowHandles()){
		    driver.switchTo().window(winHandle);
		}
		logger("Title of the new window is "+driver.getTitle(),Status.PASS);
		
	}
	
	public void VerifyElementColour(WebElement ele, String Expcolour) throws InterruptedException {
		Thread.sleep(1000);
		String actcolour = ele.getCssValue("color");
		if (actcolour.equalsIgnoreCase(Expcolour)) {
			logger("Verification: Expected color is macthing with the actual colour of webelement: " +actcolour+" "+ ele.getText(),
					Status.PASS);
		} else {
			logger("Verification: Expected color is not macthing with the actual colour of webelement: "
					+ actcolour, Status.FAIL);
		}
	}
	
	public void VerifyElementFontSize(WebElement ele, String expectedtagname) {
		//String actfont_size = ele.getCssValue("font-size");
		String acttagname = ele.getTagName();
		if(acttagname.equalsIgnoreCase(expectedtagname)) {
			logger("Verification: Expected font size "+expectedtagname+" is macthing with the actual font size "+acttagname+" of the webelement: "+ele.getText(),
					Status.PASS);
		}else {
			logger("Verification: Expected font size "+expectedtagname+" is not macthing with the actual font size "+acttagname+" of the webelement: "+ele.getText(),
					Status.FAIL);
		}
	}
	
	public WebDriver ProfileLogin(WebDriver driver) throws AWTException {
		driver.findElement(By.xpath("//*[text()='Sign in']")).click();
		Robot bot = new Robot();
		bot.keyPress(KeyEvent.VK_ENTER);
		return driver;
	}
	
	  public void scrollToWebelement(WebElement element) { 
		  try{
			  	Thread.sleep(2000);
				JavascriptExecutor js = (JavascriptExecutor) driver;  
				js.executeScript("arguments[0].scrollIntoView();", element);
				logger("scroll bar scrolled to the WebElement",Status.PASS);
			}catch(Exception e) {
				logger("Unable to scroll to the Element",Status.INFO);
			}  
	  }
	  
	  public void waitForPageLoad() {

		    Wait<WebDriver> wait = new WebDriverWait(driver,30);
		    wait.until(new ExpectedCondition<Boolean>() {
		    	 public Boolean apply(WebDriver wdriver) {
	                    return ((JavascriptExecutor) driver).executeScript(
	                        "return document.readyState"
	                    ).equals("complete");
		            
		        }
		    });
	  }
	  
	  public boolean isCollectionSorted(List list) {
		    List copy = new ArrayList(list);
		    Collections.sort(copy);
		    return copy.equals(list);
		}
	  
	  public boolean isElementPresent(By locatorKey) {
		    try {
		        driver.findElement(locatorKey);
		        return true;
		    } catch (org.openqa.selenium.NoSuchElementException e) {
		        return false;
		    }
		}
	  
	  public void waitForJSAndJquery(){
		  waitUntilJSReady();
		  waitUntilJQueryReady();
		  }
	  
		public void waitUntilJSReady() {
			WebDriverWait wait = new WebDriverWait(driver,3000);
			wait.until((ExpectedCondition<Boolean>) driver -> {
				try {
					return ((JavascriptExecutor) driver).executeScript("return document.readyState").toString()
							.equals("complete");
				} catch (WebDriverException e) {
					return false;
				}
			});
		}
		
		public void waitUntilJQueryReady() {
			WebDriverWait wait = new WebDriverWait(driver, 3000);
			Boolean jQueryDefined = (Boolean) driver.executeScript("return typeof jQuery != 'undefined'");
			if (jQueryDefined) {
				wait.until((ExpectedCondition<Boolean>) driver -> {
					try {
						return (Boolean) ((JavascriptExecutor) driver).executeScript("return jQuery.active==0");
					} catch (WebDriverException e) {
						return false;
					}
				});
			}
		}
		
		public void ClearCookieCache() throws InterruptedException{
			driver.manage().deleteAllCookies();
			/*
			 * driver.get("chrome://settings/clearBrowserData"); Thread.sleep(2000);
			 * driver.switchTo().activeElement();
			 * driver.findElement(By.cssSelector("#clearBrowsingDataConfirm")).click();
			 * Thread.sleep(2000); driver.close();
			 */
		}
		
		public void Verify_WebPage_Is_Scrollable(WebElement ele){
			String scroll_Height = ele.getAttribute("scrollHeight");
			String offset_Height = ele.getAttribute("offsetHeight");
			int scrollHeight = Integer.parseInt(scroll_Height);
			int offsetHeight = Integer.parseInt(offset_Height);
			if(scrollHeight>250) {
				logger("Verification: WebPage is scrollable",Status.PASS);
			}else {
				logger("Verification: WebPage is not scrollable",Status.FAIL);
			}
		}
		
		public boolean fluentWait(int waitTimeout, int pollingEvery, WebElement captcha_Iframe) {
			Wait<WebDriver> wait = new FluentWait<WebDriver>(driver)
					.withTimeout(Duration.ofSeconds(waitTimeout))
		            .pollingEvery(Duration.ofSeconds(pollingEvery))
		            .ignoring(NoSuchElementException.class);
			WebElement ele = wait.until(ExpectedConditions.visibilityOf(captcha_Iframe));
			return true;
		}
}
