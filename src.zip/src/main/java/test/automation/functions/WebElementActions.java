package test.automation.functions;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;

import com.aventstack.extentreports.Status;

import test.automation.pagelocators.HomePageconstants;

/**
 * @author U381447
 *
 */
public class WebElementActions extends PageActions {


	/**
	 * Method to click the xpath with dynamic values
	 * 
	 * @param ele
	 * @return
	 */
	public WebElement dynamicElementCreator(String element, String replaceFor, String toReplaceWith) {

		WebElement selectProduct = null ;
		try {
			selectProduct = driver.findElement(By.xpath(element.replace(replaceFor, toReplaceWith )));
		} catch (Exception e) {
			loggerWithScreenshot("unknown exception happened while selecting the webelement " + selectProduct,selectProduct+"error",
					Status.FAIL, true);
		}
		return selectProduct;

	}


	public void SelectAnyMenu(WebElement ele) {

		if (verifyElementDisplayed(HomePageconstants.Selectedmenu)) {
			logger("Element is highlighted and underlined" , Status.PASS);
		}

		if (verifyElementDisplayed(HomePageconstants.Selectedarrow)) {
			logger("Arrow Icon is rotated upward and highlighted" , Status.PASS);
		}
	}


	/**Method to click dynamic elements is xpath list and using element text
	 * @param xpath
	 * @param expectedelement_text
	 */
	public void dynamicElementselector(String xpath, String expected_element_text) {
		try {
			List<WebElement> dynamiclst = driver.findElements(By.xpath(xpath));

			for (int i = 0; i<dynamiclst.size(); i++) {

				String text = dynamiclst.get(i).getText();

				if(text.equalsIgnoreCase(expected_element_text))
				{
					dynamiclst.get(i).click();
					logger("Element "+expected_element_text+ " is clicked",
							Status.PASS);
					break;
				}
			}
		} catch (Exception e) {
			e.printStackTrace();
			loggerWithScreenshot("Element "+expected_element_text+ "is Notclicked","", Status.FAIL, true);
		}
	}
	
	/**Method to click dynamic elements is xpath list and using element text
	 * @param xpath
	 * @param expectedelement_text
	 */
	public boolean dynamicElementDisplayed(String xpath, String expected_element_text) {
		try {
			List<WebElement> dynamiclst = driver.findElements(By.xpath(xpath));

			for (int i = 0; i<dynamiclst.size(); i++) {

				String text = dynamiclst.get(i).getText();

				if (text.equalsIgnoreCase(expected_element_text)) {

					logger("Element " + expected_element_text + " is displayed", Status.PASS);

					return true;

				} /*
					 * else { logger("Element " + expected_element_text + " is not displayed",
					 * Status.FAIL); }
					 */

			}
		} catch (Exception e) {
			e.printStackTrace();
			loggerWithScreenshot("Element "+expected_element_text+ "is not displayed","", Status.FAIL, true);
		}
		return false;
		
	}
	/**
	 * Method to specify the row and column number to the xpath selection
	 * 
	 * @param ele
	 * @return
	 *//*
	 * public WebElement specifyRowandColumnInXpath(String ele, int rownum, int
	 * colnum) { System.out.println("ele" + ele);
	 * 
	 * WebElement updatedEle = null; try { ele.replace("tr[?]",
	 * "tr["+Integer.toString(rownum)+"]").replace("td[?]","tr["+
	 * Integer.toString(colnum)+"]"); updatedEle =
	 * driver.findElement(By.xpath(ele)); System.out.println("updatedEle " + ele); }
	 * catch (WebDriverException e) { loggerWithScreenshot("xpath " + ele +
	 * " cant be replaced with the row and colomn numbers", " ", "Fail", true); }
	 * return updatedEle;
	 * 
	 * }
	 */



}
