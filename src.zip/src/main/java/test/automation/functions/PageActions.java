package test.automation.functions;

import java.util.ArrayList;
import java.util.List;
import java.util.Set;

import org.apache.commons.lang3.StringUtils;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.NoSuchFrameException;
import org.openqa.selenium.NoSuchWindowException;
import org.openqa.selenium.WebDriverException;
import org.openqa.selenium.WebElement;
import org.testng.Assert;

import com.aventstack.extentreports.Status;

import test.automation.pagelocators.Uniqueconstants;




public class PageActions extends Assertions {

	/**
	 * Toggle between the available window using its index as ref.
	 * 
	 * @param index
	 */
	public void switchToWindow(int index) {
		try {
			Set<String> allWindowHandles = driver.getWindowHandles();
			List<String> allHandles = new ArrayList<>();
			allHandles.addAll(allWindowHandles);
			driver.switchTo().window(allHandles.get(index));
		} catch (NoSuchWindowException e) {
			logger("The driver could not move to the given window by index " + index, Status.PASS);
		} catch (WebDriverException e) {
			logger("WebDriverException : " + e.getMessage(), Status.FAIL);
		}
	}

	/**
	 * Swtich to parent window
	 * 
	 * @param index
	 */
	public void switchToParentWindow() {
		try {
			driver.close();
			Set<String> allWindowHandles = driver.getWindowHandles();
			List<String> allHandles = new ArrayList<>();
			allHandles.addAll(allWindowHandles);
			driver.switchTo().window(allHandles.get(0));
		} catch (NoSuchWindowException e) {
			logger("The driver could not move to the Parent window ", Status.PASS);
		} catch (WebDriverException e) {
			logger("WebDriverException : " + e.getMessage(), Status.FAIL);
		}
	}

	/**
	 * Toggle between available frames in the loaded page based on element
	 * 
	 * @param element
	 */
	public void switchToFrame(WebElement element) {
		try {
			driver.switchTo().frame(element);
			logger("switch In to the Frame " + element, Status.PASS);
		} catch (NoSuchFrameException e) {
			logger("WebDriverException : " + e.getMessage(), Status.FAIL);
		} catch (WebDriverException e) {
			logger("WebDriverException : " + e.getMessage(), Status.INFO);
		}
	}

	public void switchToParentFrame() {
		try {
			driver.switchTo().parentFrame();
			logger("Navigate back to parent frame", Status.PASS);
		} catch (NoSuchFrameException e) {
			logger("WebDriverException : " + e.getMessage(), Status.FAIL);
		} catch (WebDriverException e) {
			logger("WebDriverException : " + e.getMessage(), Status.FAIL);
		}
	}

	/**
	 * Toggle between available frames in the loaded page based on index
	 * 
	 * @param element
	 */
	public void switchToFrameByIndex(int num) {
		try {
			driver.switchTo().frame(num);
			logger("switch in to the Frame ", Status.PASS);
		} catch (NoSuchFrameException e) {
			logger("WebDriverException : " + e.getMessage(), Status.FAIL);
		} catch (WebDriverException e) {
			logger("WebDriverException : " + e.getMessage(), Status.FAIL);
		}
	}

	/**
	 * Navigate back in Loaded page
	 * 
	 * @param element
	 */
	public void navigateBack() {
		try {
			driver.navigate().back();
			logger("Back Navigation performed ", Status.PASS);
		} catch (Exception e) {
			logger("Back Navigation not performed : " + e.getMessage(), Status.FAIL);
		}
	}

	/**
	 * Navigate Forward in Loaded page
	 * 
	 * @param element
	 */
	public void navigateForward() {
		try {
			driver.navigate().forward();
			logger("Forward Navigation performed ", Status.PASS);
		} catch (Exception e) {
			logger("Forward Navigation not performed : " + e.getMessage(), Status.FAIL);
		}
	}

	/**
	 * Navigate Forward in Loaded page
	 * 
	 * @param element
	 */
	public void pageRefresh() {
		try {
			driver.navigate().refresh();
			logger("Refresh performed on the page ", Status.PASS);
		} catch (Exception e) {
			logger("Refresh not performed on the page : " + e.getMessage(), Status.FAIL);
		}
	}

	/**
	 * Getting the current browser
	 * 
	 * @return
	 */
	public String getCurrentBrowser() {
		String browserName = "Empty";
		try {
			String browserName1 = driver.getCapabilities().getBrowserName().toString();
			logger("Current Browser name is " + browserName1, Status.PASS);
			browserName1 = browserName;
		} catch (Exception e) {
			logger("Current Browser name is " + e.getMessage(), Status.FAIL);
		}
		return browserName;
	}

	/**
	 * Ensure the element is not found in the Page
	 * 
	 * @return
	 */
	public void ensureNotFound(WebElement element, String message) {

		try {
			Assert.assertTrue(element != null, message);

		} catch (Exception e) {
			logger("Load page error" + e.getMessage(), Status.FAIL);
		}

	}

	/**
	 * Checks no error message is found in the Page
	 * 
	 */
	public void VerifyNoErrorInPage() {

		if (Uniqueconstants.errorCode != null || Uniqueconstants.errorPage != null) {
			loggerWithScreenshot("Error Message found in the Page", "Error Page", Status.PASS, true);

		} else if ((Uniqueconstants.errorMessages != null
				&& StringUtils.isNotBlank(Uniqueconstants.errorMessages.getText()))) {
			String message = Uniqueconstants.errorMessages.getText();
			loggerWithScreenshot("Message found in page:" + driver.getCurrentUrl() + "\n" + message, "Error Page",
					Status.FAIL, true);

		}
	}
	
	 public void openLinkInNewTab(String url) {
	        try {
	            ((JavascriptExecutor)driver).executeScript("window.open()");
	            Thread.sleep(1000);
	            for(String windowHandle:driver.getWindowHandles()) {
	                driver.switchTo().window(windowHandle);
	            }
	            Thread.sleep(1000);
	            driver.get(url);
	            logger("Navigated to " + url + " in the new tab", Status.INFO);
	           // test.log(Status.INFO, "Navigated to " + url + " in the new tab");
	            Thread.sleep(1000);
	        }
	        catch(InterruptedException e) {
	            e.printStackTrace();
	        }
	    }
	 public void Turnoff_Locationservice() {

			driver.get("chrome://settings/content/location?search=location");
			WebElement root1 = driver.findElement(By.xpath("//settings-ui"));
			WebElement shadowRoot1 = expandRootElement(root1);
			WebElement root3 = shadowRoot1.findElement(By.cssSelector("settings-main[id=main]"));
			WebElement shadowRoot3 = expandRootElement(root3);
			WebElement root4 = shadowRoot3.findElement(By.cssSelector("settings-basic-page[role=main"));
			WebElement shadowRoot4 = expandRootElement(root4);
			WebElement root6= shadowRoot4.findElement(By.cssSelector("settings-privacy-page:not([style])"));
			WebElement shadowRoot6 = expandRootElement(root6);
			WebElement root9 = shadowRoot6.findElement(By.cssSelector("category-default-setting[toggle-off-label=Blocked]"));
			WebElement shadowRoot9 = expandRootElement(root9);
			WebElement root10 = shadowRoot9.findElement(By.cssSelector("settings-toggle-button[id=toggle]"));
			WebElement shadowRoot10 = expandRootElement(root10);
			WebElement root11 = shadowRoot10.findElement(By.cssSelector("cr-toggle[id=control]"));
			WebElement shadowRoot11 = expandRootElement(root11);
			WebElement Locationbutton = shadowRoot11.findElement(By.cssSelector("span[id=knob]"));
			clickWebElement(Locationbutton);
		}
	 
	 public WebElement expandRootElement(WebElement element) {
			WebElement ele = (WebElement) ((JavascriptExecutor) driver)
					.executeScript("return arguments[0].shadowRoot",element);
			return ele;
		}
	 
		public void copy_Current_Url_And_Open_In_New_Tab() {
			String current_Url = driver.getCurrentUrl();
			((JavascriptExecutor) driver).executeScript("window.open()");
			ArrayList<String> tabs = new ArrayList<String>(driver.getWindowHandles());
			driver.switchTo().window(tabs.get(1));
			driver.get(current_Url);
		}
}
