package test.automation.functions;

import java.awt.*;
import java.awt.event.*;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;


public abstract class MouseEvents extends PageActions {
	
	void Mouse() 
    { 
    } 
  
    public static void main(String[] args) 
    { 
       
        JFrame f = new JFrame("MouseListener"); 
      
        f.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE); 
  
        
        JPanel p = new JPanel(); 
  
       
        Component label1 = new JLabel("no event  "); 
  
        Component label2 = new JLabel("no event  "); 
  
        Component label3 = new JLabel("no event  "); 
  
  
       
        p.add(label1); 
        p.add(label2); 
        p.add(label3); 
  
        
        f.add(p); 
  
    } 
  
    @SuppressWarnings("null")
	public void mousePressed(MouseEvent e) 
    { 
        JLabel label1 = null;
		label1.setText("Mouse Pressed"); 
    } 
  
    @SuppressWarnings("null")
	public void mouseReleased(MouseEvent e) 
    { 
        JLabel label1 = null;
		label1.setText("Mouse Released"); 
    } 

    @SuppressWarnings("null")
	public void mouseExited(MouseEvent e) 
    { 
        JLabel label2 = null;
		label2.setText("Mouse Exited"); 
    } 
    @SuppressWarnings("null")
	public void mouseEntered(MouseEvent e) 
    { 

        JLabel label2 = null;
		label2.setText("Mouse Entered"); 
    } 
    @SuppressWarnings("null")
	public void mouseClicked(MouseEvent e) 
    { 

        JLabel label3 = null;
		label3.setText("Mouse Clicked"); 
    } 
}
