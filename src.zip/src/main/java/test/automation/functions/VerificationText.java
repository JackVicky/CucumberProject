package test.automation.functions;

import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;

import org.apache.poi.xssf.usermodel.XSSFCell;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

public class VerificationText  {

	private static XSSFWorkbook wb;
	private static XSSFSheet xssfSheet;

	public static String getDataForRequiredLanguage(String language, String keys, String sheetName) {
		try {
			xssfSheet = readExcel(sheetName);
		} catch (IOException e) {
			//logger(e.getMessage(), Status.FAIL);	
		}
		int columnIndex = 0;
		try {
			columnIndex = getXIndexOfRequiredLanguage(language, sheetName);
		} catch (IOException e) {
			//logger(e.getMessage(), Status.FAIL);	
		}
		int rowIndex = 0;
		try {
			rowIndex = getYIndexOfRequiredKey(keys, sheetName);
		} catch (IOException e) {

			//logger(e.getMessage(), Status.FAIL);		


		}
		return xssfSheet.getRow(rowIndex).getCell(columnIndex).toString();
	}

	public static XSSFSheet readExcel(String sheetName) throws IOException {
		// Define Input Stream for desired file
		InputStream fs = new FileInputStream("./data" + "\\Translations.xlsx");
		wb = new XSSFWorkbook(fs);
		XSSFSheet xssfSheet = wb.getSheet(sheetName);
		return xssfSheet;
	}

	public static int getXIndexOfRequiredLanguage(String language, String sheetName) throws IOException {
		int xIndexOfRequiredLanguage = 1;
		xssfSheet = readExcel(sheetName);
		int numOfcolumns = xssfSheet.getRow(0).getPhysicalNumberOfCells();
		for (int i = 1; i <= numOfcolumns; i++) {
			XSSFCell columnCell = xssfSheet.getRow(0).getCell(i);
			String columnName = columnCell.getRichStringCellValue().toString();
			if (columnName.toLowerCase().contains(language.toLowerCase())) {
				xIndexOfRequiredLanguage = i;
				break;
			}
		}
		return xIndexOfRequiredLanguage;
	}

	public static int getYIndexOfRequiredKey(String keys, String sheetName) throws IOException {
		int yIndexOfRequiredKey = 0;
		xssfSheet = readExcel(sheetName);
		int numOfRows = xssfSheet.getPhysicalNumberOfRows();
		for (int i = 0; i <= numOfRows; i++) {
			XSSFCell rowCell = xssfSheet.getRow(i).getCell(0);
			String rowName = rowCell.getRichStringCellValue().toString();
			if (rowName.contains(keys)) {
				yIndexOfRequiredKey = i;
				break;
			}
		}
		return yIndexOfRequiredKey;
	}
}
