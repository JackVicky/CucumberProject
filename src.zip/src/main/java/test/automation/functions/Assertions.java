package test.automation.functions;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.NoAlertPresentException;
import org.openqa.selenium.WebDriverException;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;

import com.aventstack.extentreports.Status;

import test.automation.pagelocators.ProductPageconstants;
import test.automation.pages.Product_Menu_Page;

public class Assertions extends UserActions {

	/**
	 * Verify title of the page is as expected
	 * 
	 * @param title
	 * @return
	 * @throws InterruptedException 
	 */
	public boolean verifyPageTitle(String title) throws InterruptedException {
		boolean bReturn = false;
		try {
			Thread.sleep(2000);
			if (getPageTitle().trim().contains(title)) {
				logger("Verification: The title of the page matches with the value : " + title, Status.PASS);
				bReturn = true;
			} else {
				logger("Verification: The title of the page: " + driver.getTitle() + " did not match with the value : "
						+ title, Status.FAIL);
			}
		} catch (WebDriverException e) {
			logger("Verification: Unknown exception occured while verifying the title", Status.FAIL);
		}
		return bReturn;
	}

	/**
	 * Verify the text of the web element is same as expected
	 * 
	 * @param element
	 * @param expectedText
	 */
	public void verifyTextMatch(WebElement element, String expectedText) {
		try {
			if (getText(element).equals(expectedText)) {
				logger("Verification: The text: " + getText(element) + " matches with the value :" + expectedText,
						Status.PASS);
			} else {
				logger("Verification: The text " + getText(element) + " doesn't matches the actual " + expectedText,
						Status.FAIL);
			}
		} catch (WebDriverException e) {
			logger("Verification: Unknown exception occured while verifying the Text", Status.FAIL);
		}

	}

	/**
	 * Verify the text of the web element is partially same as expected
	 * 
	 * @param element
	 * @param expectedText
	 */
	public void verifyPartialText(WebElement element, String expectedText) {
		try {
			if (getText(element).contains(expectedText)) {
				logger("Verification: The expected text contains the actual " + expectedText, Status.PASS);
			} else {
				logger("Verification: The expected text doesn't contain the actual " + expectedText, Status.FAIL);
			}
		} catch (WebDriverException e) {
			logger("Verification: Unknown exception occured while verifying the Text", Status.FAIL);
		}
	}

	/**
	 * Verify the attribute value of a web element is exactly as expected
	 * 
	 * @param element
	 * @param attribute
	 * @param value
	 */
	public void verifyExactAttribute(WebElement element, String attribute, String value) {
		try {
			if (getAttribute(element, attribute).equals(value)) {
				logger("Verification: The expected attribute :" + attribute + " value matches the actual " + value,
						Status.PASS);
			} else {
				logger("Verification: The expected attribute :" + attribute + " value does not matches the actual "
						+ value, Status.FAIL);
			}
		} catch (WebDriverException e) {
			logger("Verification: Unknown exception occured while verifying the Attribute Text", Status.FAIL);
		}

	}

	/**
	 * Verify the text of the web element is partially as expected
	 * 
	 * @param element
	 * @param attribute
	 * @param value
	 */
	public void verifyPartialAttribute(WebElement element, String attribute, String value) {
		try {
			if (getAttribute(element, attribute).contains(value)) {
				logger("Verification: The expected attribute :" + attribute + " value contains the actual " + value,
						Status.PASS);
			} else {
				logger("Verification: The expected attribute :" + attribute + " value does not contains the actual "
						+ value, Status.FAIL);
			}
		} catch (WebDriverException e) {
			logger("Verification: Unknown exception occured while verifying the Attribute Text", Status.FAIL);
		}
	}

	/**
	 * Verify the webelement is selected in the loaded page
	 * 
	 * @param element
	 * @return
	 */
	public boolean verifyElementSelected(WebElement element) {
		try {
			if (element.isSelected()) {
				String text = " ";
				text = element.getText();
				logger("Verification: The element " + text + " is selected", Status.PASS);
			} else {
				logger("Verification: The element " + element + " is not selected", Status.FAIL);
			}
		} catch (WebDriverException e) {
			logger("Verification: WebDriverException : " + e.getMessage(), Status.FAIL);
		}
		return element.isSelected();
	}

	/**
	 * Verify the webelement is displayed in the loaded page
	 * 
	 * @param findElementByXPath
	 * @return
	 */
	public boolean verifyElementDisplayed(WebElement findElementByXPath) {
		try {
			if (findElementByXPath.isDisplayed()) {
				String text = " ";
				text = findElementByXPath.getText();
				logger("Verification: The element " + text + " is visible", Status.PASS);
			} else {
				logger("Verification: The element " + findElementByXPath + " is not visible", Status.FAIL);
			}
		} catch (WebDriverException e) {
			logger("Verification: WebDriverException : " + e.getMessage(), Status.FAIL);
		}
		return findElementByXPath.isDisplayed();
	}


	/**
	 * Verify the webelement is not displayed in the loaded page
	 * 
	 * @param element
	 * @return
	 */
	public boolean verifyElementNotDisplayed(String xpath) {


		List<WebElement> findElementsByXPath = driver.findElements(By.xpath(xpath));
		try {
			if (findElementsByXPath.size()==0) {

				logger("Verification: The element is not visible", Status.PASS);
				return true;
			}
		} catch (Exception e) {
			logger("Verification: Exception Occured : " + e.getMessage(), Status.FAIL);
			return false;
		}
		return false;
		

	}

	/**
	 * Verify the webelement is enabled in the loaded page
	 * 
	 * @param element
	 * @return
	 */
	public boolean verifyElementEnabled(WebElement element) {
		if (element.isEnabled()) {
			String text = " ";
			text = element.getText();
			logger("Verification: The element " + text + "is enabled", Status.PASS);
		} else {
			logger("Verification: The element " + element + "is not enabled", Status.FAIL);
		}
		return (element.isEnabled());
	}

	/**
	 * Verify Alert is present in the loaded page
	 * 
	 * @return
	 */
	public boolean verifyAlertPresent() {
		try {
			driver.switchTo().alert();
			logger("Verification: Alert is available", Status.PASS);
			return true;
		} // try
		catch (NoAlertPresentException Ex) {
			logger("Verification: Alert is not available", Status.FAIL);
			return false;
		} // catch
	}

	/**
	 * Verify frame is present in the loaded page
	 * 
	 * @param element
	 * @return
	 */
	public boolean verifyFramePresent(WebElement element) {
		try {
			driver.switchTo().frame(element);
			logger("Verification: Frame is available with the element " + element + "", Status.PASS);
			return true;
		} // try
		catch (NoAlertPresentException Ex) {
			logger("Verification: Frame is not available with the element " + element + "", Status.FAIL);
			return false;
		} // catch
	}

	/**
	 * Verify Two string are matching on comparison
	 * 
	 * @param Expstr
	 * @param Actstr
	 * @return
	 */
	public void Verify_TwoString(String Expstr, String Actstr) {

		try {
			Assert.assertEquals(Actstr, Expstr);
			logger("Verification: Both the strings are Matching - " + Expstr + " ", Status.PASS);
		} catch (AssertionError e) {
			loggerWithScreenshot(e.getMessage(), Expstr, Status.FAIL, true);

		}

	}

	/**
	 * Verify Two Numbers are matching on comparison
	 * 
	 * @param Expstr
	 * @param Actstr
	 * @return
	 */
	public void Verify_TwoString(int Expnmbr, int Actnbr) {

		try {
			Assert.assertEquals(Actnbr, Expnmbr);
			logger("Verification: Both the strings are Matching - " + Expnmbr + " ", Status.PASS);
		} catch (AssertionError e) {
			loggerWithScreenshot(e.getMessage(), "  ", Status.FAIL, true);

		}

	}

	/**
	 * Verify the web element is not empty without any text value
	 * 
	 * @param element
	 * @return
	 */
	public boolean verifyTextPresent(WebElement element) {
		String text = " ";
		try {
			if (element.isDisplayed()) {

				text = element.getText();
				Assert.assertTrue(!text.isEmpty());
				logger("Verification: The element " + text + " is visible", Status.PASS);
			} else {
				logger("Verification: The element " + element + " is not visible", Status.FAIL);
			}
		} catch (WebDriverException e) {
			logger("Verification: WebDriverException : " + e.getMessage(), Status.FAIL);
		}
		return !text.isEmpty();
	}

	/**
	 * Verify the web element is not empty without any text value
	 * 
	 * @param element
	 * @return
	 * @throws InterruptedException 
	 */
	public boolean VerifyElementIsHighlighted(WebElement element) throws InterruptedException
	{
		Thread.sleep(3000);
		String cssValue1 = element.getCssValue("color");
		Actions actions = new Actions(driver);
		actions.moveToElement(element).build().perform();
		String cssValue2 = element.getCssValue("background-color");
		String text = element.getText();
		if(!cssValue1.contentEquals(cssValue2))
		{
			logger("Verification: Element "+text+" is Highlighted", Status.PASS);
			return true;

		} else {

			logger("Verification: Element "+text+" is not Highlighted", Status.FAIL);
			return false;
		}
		
	}

	public boolean VerifyElementIsNotHighlighted(WebElement element)
	{
		String cssValue1 = element.getCssValue("color");
		Actions actions = new Actions(driver);
		actions.moveToElement(element).build().perform();
		String cssValue2 = element.getCssValue("color");
		String text = element.getText();
		if(!cssValue1.contentEquals(cssValue2))
		{
			logger("Verification: Element "+text+" is Highlighted", Status.FAIL);
			return true;

		} else {

			logger("Verification: Element "+text+" is not Highlighted", Status.PASS);
			return false;
		}
	}
	/**
	 * Verify the web elements is not empty without any text value
	 * 
	 * @param element
	 * @return
	 */
	public boolean VerifyElementsIsHighlighted(String Xpath)
	{
		List<WebElement> findElementsByXPath = driver.findElements(By.xpath(Xpath));
		for (WebElement webElement : findElementsByXPath) {

			String cssValue1 = webElement.getCssValue("color");
			Actions actions = new Actions(driver);
			actions.moveToElement(webElement).build().perform();
			String cssValue2 = webElement.getCssValue("color");
			String text = webElement.getText();
			if(!cssValue1.contentEquals(cssValue2))
			{
				logger("Verification: Element "+text+" is Highlighted", Status.PASS);


			} else {

				logger("Verification: Element "+text+" is not Highlighted", Status.FAIL);

			}
		}
		return true;
	}


	/**
	 * Verify the web element is clickable
	 * 
	 * @param element
	 * @return
	 */

	public boolean VerifyElementIsClickable(String Xpath)
	{
		try {
			new WebDriverWait(driver, 15).until(ExpectedConditions.elementToBeClickable(By.xpath(Xpath)));
			logger("Verification: Element is clickable", Status.PASS);
			return true;
		}
		catch(Exception e) {
			logger("Verification: Element is not clickable", Status.FAIL);
			return false;
		}


	}

	/**
	 * Verify the web element is clickable
	 * 
	 * @param element
	 * @return
	 */

	public boolean VerifyElementIsClickable(WebElement element)
	{
		try {
			new WebDriverWait(driver, 15).until(ExpectedConditions.elementToBeClickable(element));
			logger("Verification: Element "+element.getText()+" is clickable", Status.PASS);
			return true;
		}
		catch(Exception e) {
			logger("Verification: Element "+element.getText()+" is not clickable", Status.FAIL);
			return false;
		}
	}
	
	public boolean VerifyElementIsClickableForAlert(WebElement element)
	{
		try {
			new WebDriverWait(driver, 15).until(ExpectedConditions.elementToBeClickable(element));
			logger("Verification: Element "+element.getText()+" is clickable", Status.PASS);
			return true;
		}
		catch(Exception e) {
			logger("Information: Cookie pop-up"+element.getText()+" is not present", Status.INFO);
			return false;
		}
	}

	/**
	 * Verify the web element is not clickable
	 * @param element
	 * @return
	 */

	public boolean VerifyElementIsNotClickable(WebElement element)
	{
		try {
			new WebDriverWait(driver, 5).until(ExpectedConditions.elementToBeClickable(element));
			logger("Verification: Element "+element.getText()+ " is clickable", Status.FAIL);
			return true;
		}
		catch(Exception e) {
			logger("Verification: Element "+element.getText()+" is not clickable", Status.PASS);
			return false;
		}


	}


	/** Method to verify ELements are arranged in Alphabatical Order
	 * @return
	 */
	public void Verify_Alphabatic_Order(String Xpath) {
		List<WebElement> listOfElement = ListOfElement("xpath","Xpath");
		List<String> list1 = new ArrayList<>();
		List<String> list2 = new ArrayList<>();
		for (WebElement webElement : listOfElement) {
			String text = webElement.getText();
			list1.add(text);
			list2.add(text);
		}

		Collections.sort(list1);
		if(list1.equals(list2))
		{
			logger("Expected Elements are sorted in alphabetical order" , Status.PASS);

		} else {
			logger("Expected Elements are Not sorted in alphabetic order", Status.FAIL);
		}

	}
	
	public void Verify_NotinAlphabatic_Order(String Xpath) {
		List<WebElement> listOfElement = ListOfElement("xpath",Xpath);
		List<String> list1 = new ArrayList<>();
		List<String> list2 = new ArrayList<>();
		for (WebElement webElement : listOfElement) {
			String text = webElement.getText();
			list1.add(text);
			list2.add(text);
		}
		
		Collections.sort(list1);
		
		if(list1.equals(list2))
		{
			logger("Expected Elements are sorted in alphabetical order" , Status.FAIL);

		} else {
			logger("Expected Elements are not sorted in alphabetic order", Status.PASS);
		}

	}
	
	/**
	 * Verify the number of web element present with the same locators 
	 * @param element
	 * @return
	 */

	public boolean VerifyTheSizeOfTheLocator(By element)
	{
		try {
			int size = driver.findElements(element).size();
			logger("Verification: Size of the webelement is "+size, Status.PASS);
			return true;
		}
		catch(Exception e) {
			logger("Unable to find the size of the passed locator", Status.FAIL);
			return false;
		}


	}
	
	/**
	 * Verify the image is displayed or not in web page 
	 * @param element
	 * @return
	 */
	public boolean VerifyImageIsDisplayed(WebElement image) {
		try {
			Object result = ((JavascriptExecutor) driver).executeScript("return arguments[0].complete && "
					+ "typeof arguments[0].naturalWidth != \"undefined\" && " + "arguments[0].naturalWidth > 0", image);

			boolean loaded = false;
			if (result instanceof Boolean) {
				loaded = (Boolean) result;
				if (loaded == true) {
					logger("Verification: Product image "+image.getText()+" is displayed " + image.getAttribute("alt"), Status.PASS);
				} else {
					logger("Verification: Product image "+image.getText()+" is not displayed ", Status.INFO);
				}
			}
			
			return true;
		} catch (Exception e) {
			logger("Verification: WebDriverException : " + e.getMessage(), Status.FAIL);
			return false;
		}
	}
	
	public boolean verifyElementDisplayedForEdge(WebElement findElementByXPath) {
		try {
			if (findElementByXPath.isDisplayed()) {
				String text = " ";
				text = findElementByXPath.getText();
				logger("Verification: The element " + text + " is visible", Status.PASS);
			} else {
				logger("Verification: Cookie Pop-up is not open for Edge Browser ", Status.INFO);
			}
		} catch (WebDriverException e) {
			logger("Verification: WebDriverException : " + e.getMessage(), Status.FAIL);
		}
		return findElementByXPath.isDisplayed();
	}
	
	public void VerifyImageRatio(WebElement element, int expectedHight, int expectedWidth){
		int width= element.getSize().getWidth();
	    int hight= element.getSize().getHeight();
	    System.out.println(width+" W ----H "+hight);
	    try {
			Assert.assertEquals(width, expectedWidth, "Assertion failed for product image width comparison");
			logger("Verification: Product image ratio width is matching with the expected value: "+width, Status.PASS);
		} catch (Exception e) {
			logger("Verification: Product image ratio width is not matching with the expected value: "+width, Status.FAIL);
		}
	    try {
			Assert.assertEquals(hight, expectedHight, "Assertion failed for product image height comparison");
			logger("Verification: Product image ratio hight is matching with the expected value: "+hight, Status.PASS);
		} catch (Exception e) {
			logger("Verification: Product image ratio hight is not matching with the expected value: "+hight, Status.FAIL);
		}
	}
	
	public void ZoomBrowserScreen(String size){
		JavascriptExecutor jse = (JavascriptExecutor)driver;
		jse.executeScript("document.body.style.zoom = '"+size+"';");
	}
	
	public Assertions Script_Pass_Logger(){
		logger("Script Pass Successfully",Status.PASS);
		return this;
	}
	
	public boolean VerifyElementIsClickableForPipeline(WebElement element)
	{
		try {
			new WebDriverWait(driver, 30).until(ExpectedConditions.elementToBeClickable(element));
			logger("Verification: Element "+element.getText()+" is clickable", Status.PASS);
			return true;
		}
		catch(Exception e) {
			logger("Verification: Element "+element.getText()+" is not clickable", Status.FAIL);
			return false;
		}
	}
}
