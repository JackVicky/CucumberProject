
package test.automation.functions;
import java.io.File;
import java.io.IOException;
import java.text.*;
import java.util.Calendar;
import java.util.Date;

import org.apache.commons.io.FileUtils;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.WebDriverException;
import org.openqa.selenium.remote.RemoteWebDriver;

import com.aventstack.extentreports.ExtentReports;
import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.MediaEntityBuilder;
//import com.aventstack.extentreports.MediaEntityModelProvider;
import com.aventstack.extentreports.Status;
import com.aventstack.extentreports.model.Media;
//import com.aventstack.extentreports.reporter.ExtentHtmlReporter;
import com.aventstack.extentreports.reporter.ExtentSparkReporter;
import com.aventstack.extentreports.reporter.configuration.Theme;


public abstract class ExtentReporter {


	//public static ExtentHtmlReporter html;
	public static ExtentReports extent;
	public static ExtentTest test, suiteTest;
	public String testCaseName, testNodes, testDescription, category, authors;
	String timeStamp = new SimpleDateFormat("MM-dd-yyyy_HH_mm_ss").format(Calendar.getInstance().getTime());
	// declare global variables
		public static RemoteWebDriver driver;
	/*
	 * To Initiate the extent report for the class run and to generate the report
	 */
	public void reportInitiator() {
		//html = new ExtentHtmlReporter("./reports/Automation_Extent_Summary "+timeStamp+".html");
		//html.setAppendExisting(false);
		ExtentSparkReporter spark = new ExtentSparkReporter("./reports/Automation_Extent_Summary "+timeStamp+".html");
		spark.config().setTheme(Theme.DARK);
		spark.config().setDocumentTitle("Test Automation");
		spark.config().setReportName("Test Regression Test");
		extent = new ExtentReports();
		extent.attachReporter(spark);
	}


	/*
	 * Method to initiate before suite for Test case name and its description
	 */
	public ExtentTest suiteInitiator(String testCaseName, String testDescription) {
		suiteTest = extent.createTest(testCaseName, testDescription).assignAuthor("Vignesh Selvam").assignDevice("chrome");
		return suiteTest;
	}


	/*
	 * Method to initiate the nodes available in the Automation run to categorize
	 * the test cases
	 */
	public ExtentTest testNodeInitiator(String testNodes) {
		test = suiteTest.createNode(testNodes);
		return test;
	}

	//protected abstract String takeScreenshot(String name);
	
	/**
	 * Take the Screenshot and save it with ref to the method name and timestamp
	 *
	 */
	public  String takeScreenshot(String name) {
		// Open the current date and time
		String timestamp = new SimpleDateFormat("yyyy_MM_dd__hh_mm_ss").format(new Date());
		String filename = name + "_" + timestamp;
		try {
			FileUtils.copyFile(driver.getScreenshotAs(OutputType.FILE),
					new File("./reports/images/" + filename + ".jpg"));
		} catch (WebDriverException e) {
			System.out.println("The browser has been closed.");
		} catch (IOException e) {
			System.out.println("The snapshot could not be taken");
		}
		return filename;
	}
	/*
	 * Method helps in logging the different step result like Pass,Fail,Info,Error
	 * with Screenshot for the same
	 */
	public void loggerWithScreenshot(String desc, String name, Status info, boolean bSnap) {
		// MediaEntityModelProvider img = null;
		Media img = null;
		if (bSnap && !info.equals(Status.INFO)) {

			// long snapNumber = 100000L; // snapNumber = takeScreenshot();
			String filename = takeScreenshot(name);
			img = MediaEntityBuilder.createScreenCaptureFromPath("./../reports/images/" + filename + ".jpg").build();
		}
		if (info.equals(Status.PASS)) {
			test.pass(desc, img);
			System.out.println("Pass: " + desc);
		} else if (info.equals(Status.FAIL)) {
			test.fail(desc, img);
			System.out.println("Fail: " + desc);
		} else if (info.equals(Status.WARNING)) {
			test.warning(desc, img);
			System.out.println("Warning: " + desc);
		} else if (info.equals(Status.INFO)) {
			test.info(desc);
			System.out.println("Info: " + desc);
		}

	}

	/*
	 * Method helps in logging the different step result like Pass,Fail,Info,Error
	 * without Screenshot for the same
	 */
	public  void logger(String desc, Status info) {
		loggerWithScreenshot(desc, "",info, false);
	}

	/*
	 * Close and exit reporting
	 */
	public void exitReporter() {
		extent.flush();
	}

}
