package test.automation.functions;

import java.io.File;
import java.io.FileInputStream;
import java.io.InputStream;
import java.util.Properties;

public class PropertyFileUtil {

	static public Properties resource = null;

	static public Properties loadPropertiesResources(String fileName) {
		resource = new Properties();
		try {
			File file=new File(fileName);//"./testdata/"+fileName	
			InputStream data_input = new FileInputStream(file);
			resource.load(data_input);
		} catch (Exception e) {
			System.out.println("Error:Not found properties file"+ fileName);
			e.printStackTrace();
		}

		return resource;
	}

}
