package test.automation.globalfunctionality;

import java.util.Properties;

import org.openqa.selenium.support.PageFactory;
import org.testng.annotations.AfterClass;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.AfterSuite;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.BeforeSuite;

import test.automation.functions.PropertyFileUtil;
import test.automation.functions.WebElementActions;


public class TestCaseInitiator extends WebElementActions {

	Properties PROPERTIES_RESOURCES_WebEx = PropertyFileUtil
			.loadPropertiesResources("/testdata_Webex.properties");

	//public static String url;
	//public String userName = PROPERTIES_RESOURCES_ProductStore.getProperty("qaUserName");
	//public String password = PROPERTIES_RESOURCES_ProductStore.getProperty("qaPassword");
	//public String productStoret4 = PROPERTIES_RESOURCES_ProductStore.getProperty("productStoret4.url");
	public String url_qa = PROPERTIES_RESOURCES_WebEx.getProperty("Webxqa.url");
	public String url_stag = PROPERTIES_RESOURCES_WebEx.getProperty("WebxStag.url");
	public String url_stag_u = PROPERTIES_RESOURCES_WebEx.getProperty("Umbraco_Stag.url");
	public String url_int = PROPERTIES_RESOURCES_WebEx.getProperty("Webxint.url");
	//public String workBookName = "Login", dataSheetName;
	

	/*
	 * Before Suite-Initiate the Reporting process for the triggered Automation run
	 */
	@BeforeSuite
	public void beforeSuite() {
		reportInitiator();

	}

	/**
	 * Initiate the Test case name and its description // @Parameters({
	 * "environment" })
	 */

	@BeforeClass
	public void beforeClass() {
//		test.assignCategory(category);
//		test.assignAuthor(authors);
		PageFactory.initElements(driver, this);
		//selectenvironment("QA");
	
		intitateBrowser("chrome",url_stag);

	}

	/**
	 * Start the Tests with its nodes specified in align to the data provided
	 */

	@BeforeMethod
	public void beforeMethod() {

		//driver.get(url_qa);

	}

	/**
	 * After executing each method close the browser
	 */
	@AfterMethod
	public void afterMethod() {

	}
	

	/**
	 * After executing each class close the browser
	 */
	@AfterClass
	public void afterClass() {
		quitBrowsers();
		
	}

	/**
	 * Formulate the reported outputs
	 */
	@AfterSuite
	public void afterSuite() {
		exitReporter();

	}

	
	public void selectenvironment(String environment) {
		if (environment.contains("QA")) {
			url_qa = PROPERTIES_RESOURCES_WebEx.getProperty("productStoret4.url");
		} else if (environment.contains("UAT")) {
			System.out.println("No links available");
		}
	}

}
